<!DOCTYPE html>
<html>
<head>
  <title>
    news
  </title>
  <style type="text/css">
    .divimages{
      float: left;
      display: block;
    }
    .uploadingsub {
    margin-top: 10px;
    height: 30px;
    border-radius: 7px;
    border: 1px solid #CECECE;
    box-shadow: 1px 1px 4px gray;
}.uploadinginset {
    border: 1px solid rgb(228, 207, 207);
    background-color: rgb(242, 242, 242);
}
.uploadingbox {
    width: 300px;
    height: 100px;
    padding: 14px;
    border: 2px solid #E3E0E0;
    border-radius: 12px;

}
.deletebox {
    width: 130px;
    height: 35px;
    border: 1px solid #CBCBCB;
    border-radius: 10px;
    background-color: #DD1538;
    color: #FCFCFC;
    text-align: center;
    font-size: 19px;
    display: block;
    margin-left: 155px !important;
}
.viewbox {
    width: 130px;
    height: 35px;
    border: 1px solid rgb(203, 203, 203);
    border-radius: 10px;
    background-color: rgb(46, 118, 243);
    color: rgb(252, 252, 252);
    text-align: center;
    font-size: 19px;
    float: left;
    display: block;
}
.wholebox {
    width: 300px;
    height: auto;
    padding: 5px;
    border: 2px solid rgb(222, 221, 221);
    display: block;
    float: left;
}
.imgname {
    width: 100%;
    height: auto;
    padding: 2px;
    color: #142D9C;
}
  </style>
  <meta   charset="utf-8" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
<body>
  <div>
    Images upload
  </div>
<div class="container">
  <form action="test.php" class="uploadingbox" method="post" enctype="multipart/form-data">
    <input type="file" name="fileToUpload" class="uploadinginset" id="fileToUpload">
    <input type="submit" class="uploadingsub" value="Upload Image" name="submit">
  </form>
</div>

<div class="container" style="max-width: 1000px !important;">
           <?php
            
            $files = glob("uploads/*.*");
            foreach ($files as $file) {
              ?>
<div class="wholebox">
  <div class="imgname">
    <?php echo $file; ?>
  </div>
  <img src="<?php echo $file; ?>" class="img-responsive" alt="Cinque Terre" width="100%" height="336px">
  <a href="<?php echo $file; ?>">
    <div class="viewbox">
      View
    </div>
  </a>
  <form method="post">
    <input type="hidden" name="delete_file" value="<?php echo $file; ?>">
    <input type="submit" class="deletebox" name="" value="Delete">
  </form>
<?php  
if (array_key_exists('delete_file', $_POST)) {
  $filename = $_POST['delete_file'];
  if (file_exists($filename)) {
    unlink($filename);
    ?>

  
    
    File <?php echo $filename; ?>  has been deleted
 
    <?php 
  } else {
     ?>
    
    Could not delete <?php echo $filename; ?> .file does not exist
    <?php
  }
}?> 
</div>

 
         <?php    
            }
            
            ?>
           
            

</div>
<?php
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
/*if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}*/
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?> 

<!-- ============================================================================== -->

   


</body>
</html>







 