<!-- footer part -->

	<div class="row footerrows">
    <div class="col-sm-4 first-footer-text">
      <h3>
        <span class="glyphicon glyphicon-map-marker"></span>သင္တန္းတည္ေနရာ 
      </h3>
      <div class="">
         သဒၶမၼေဇာတိကာရုံ ဘုန္းေတာ္ႀကီးသင္ ပညာေရးေက်ာင္း ၊ ကြမ္းၿခံကုန္းေက်းရြာ ၊ သန္လ်င္ၿမိဳ႕နယ္ ၊ ရန္ကုန္တုိင္းေဒသႀကီး။
      </div>
    </div>
    <div class="col-sm-4 second-footer-text">
      <h3> <span class="glyphicon glyphicon-globe"></span>ဆက္သြယ္ရန္</h3>
      <div class="footer-11">
        <span class="glyphicon glyphicon-earphone"></span>ဖုန္း - ၀၉ ၄၂၅၀၂၇၅၃၅, ၀၉၄၄၁၅၃၇၄၉၅
      </div>
      <div class="footer-12">
        <span class="glyphicon glyphicon-envelope"></span>
         Email - <a href="https://www.google.com/gmail/" class="tremail">angelbreeze10@gmail.com</a>
      </div>
      <div class="footer-13">
        <span class="facebook">f</span> 
          
            facebook - <a class="fbname" href="https://www.facebook.com/%E1%80%95%E1%80%8A%E1%80%AC%E1%80%9B%E1%80%84%E1%80%B9%E1%80%81%E1%80%BC%E1%80%84%E1%80%B9-%E1%80%80%E1%80%BC%E1%80%94%E1%80%B9%E1%80%95%E1%80%BA%E1%80%B4%E1%80%90%E1%80%AC%E1%80%9E%E1%80%84%E1%80%B9%E1%80%90%E1%80%94%E1%80%B9%E1%80%B8-897365117083377/">ပညာရင္ခြင္ ကြန္ျပဴတာသင္တန္း</a>
      </div>
    </div>
    <div class="col-sm-4 thirt-footer-text">
      <h3><span class="glyphicon glyphicon-th-list"></span>Link Menu</h3>
      <div class="footer-21">
       <a href="http://localhost/compnyk"> Home</a>
      </div>
      <div class="footer-22">
        <a href="http://localhost/compnyk/comment.php">အၾကံျပဳ ခၽက္</a>
      </div>
      <div class="footer-23">
        <a href="http://localhost/compnyk/register.php">စာရင္းသြင္းျခင္း</a>
      </div>
      <div class="footer-24">
        <a href="http://localhost/compnyk/about.php">About us</a>
      </div>
      
    </div>
  </div>
<!--  footer part end -->
