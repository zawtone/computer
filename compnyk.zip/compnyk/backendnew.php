<?php

	error_reporting( ~E_NOTICE ); // avoid notice
	
	require_once 'connection.php';
	require_once 'database.php';
	$new = $database->newsread();
	session_start();

$database = new Database(); $id = $_SESSION['id'];
$gi = $database->get_fullname($id);
if (!$database->get_session()){
 header("location:login.php");
}
	
	if(isset($_GET['delete_id']))
	{
		// select image from db to delete
		$stmt_select = $connection->prepare('SELECT img FROM newstbl WHERE neid =:id');
		$stmt_select->execute(array(':id'=>$_GET['delete_id']));
		$imgRow=$stmt_select->fetch(PDO::FETCH_ASSOC);
		unlink("user_images/".$imgRow['img']);
		
		// it will delete an actual record from db
		$stmt_delete = $connection->prepare('DELETE FROM newstbl WHERE neid =:id');
		$stmt_delete->bindParam(':id',$_GET['delete_id']);
		$stmt_delete->execute();
		
		header("Location: servicescom.php");
	}
	if(isset($_POST['btnsave']))
	{
		$dfn = $_POST['dfn'];
		$mini = $_POST['mini'];
		$whole = $_POST['whole'];
		$onet = $_POST['onet'];
		$twot = $_POST['twot'];
		$threet = $_POST['threet'];
		$fourt = $_POST['fourt'];
		$fivet = $_POST['fivet'];
		$sixt = $_POST['sixt'];
		$modid = $_POST['modid'];
		$newmod = $_POST['newmod'];// user email
		
		$imgFile = $_FILES['test']['name'];
		$tmp_dir = $_FILES['test']['tmp_name'];
		$imgSize = $_FILES['test']['size'];

		$imgFileone = $_FILES['onep']['name'];
		$tmp_dirone = $_FILES['onep']['tmp_name'];
		$imgSizeone = $_FILES['onep']['size'];

		$imgFiletwo = $_FILES['twop']['name'];
		$tmp_dirtwo = $_FILES['twop']['tmp_name'];
		$imgSizetwo = $_FILES['twop']['size'];

		$imgFilethree = $_FILES['threep']['name'];
		$tmp_dirthree = $_FILES['threep']['tmp_name'];
		$imgSizethree = $_FILES['threep']['size'];

		$imgFilefour = $_FILES['fourp']['name'];
		$tmp_dirfour = $_FILES['fourp']['tmp_name'];
		$imgSizefour = $_FILES['fourp']['size'];

		$imgFilefive = $_FILES['fivep']['name'];
		$tmp_dirfive = $_FILES['fivep']['tmp_name'];
		$imgSizefive = $_FILES['fivep']['size'];

		$imgFilesix = $_FILES['sixp']['name'];
		$tmp_dirsix = $_FILES['sixp']['tmp_name'];
		$imgSizesix = $_FILES['sixp']['size'];


		
		if(empty($dfn)){
			$errMSG = "Please Enter services option.";
		}
		if(empty($mini)){
			$errMSG = "Please Enter mini information.";
		}
		else if(empty($whole)){
			$errMSG = "Please Enter Information.";
		}
		else if(empty($onet)){
			$errMSG = "Please Enter caption of img.";
		}
		else if(empty($twot)){
			$errMSG = "Please Enter caption of img.";
		}
		else if(empty($threet)){
			$errMSG = "Please Enter caption of img.";
		}
		else if(empty($fourt)){
			$errMSG = "Please Enter caption of img.";
		}
		else if(empty($fivet)){
			$errMSG = "Please Enter caption of img.";
		}
		else if(empty($sixt)){
			$errMSG = "Please Enter caption of img.";
		}
		else if(empty($modid)){
			$errMSG = "Please Enter Your model id.";
		}
		else if(empty($newmod)){
			$errMSG = "Please Enter Your new mode chouse.";
		}
		else if(empty($imgFileone)){
			$errMSG = "Please Select Image file.";
		}
		else {
			$upload_dirone = 'user_images/'; // upload directory
	
			$imgExtone = strtolower(pathinfo($imgFileone,PATHINFO_EXTENSION)); // get image extension
		
			// valid image extensions
			$valid_extensionsone = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
		
			// rename uploading image
			$imgone = rand(1000,1000000).".".$imgExtone;
				
			// allow valid image file formats
			if(in_array($imgExtone, $valid_extensionsone)){			
				// Check file size '5MB'
				if($imgSizeone < 5000000)				{
					move_uploaded_file($tmp_dirone,$upload_dirone.$imgone);
				}
				else{
					$errMSG = "Sorry, your file is too large.";
				}
			}
			else{
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
			}
		}

			if(empty($imgFiletwo)){
			$errMSG = "Please Select Image file.";
		}
		else 
			{
			$upload_dirtwo = 'user_images/'; // upload directory
	
			$imgExttwo = strtolower(pathinfo($imgFiletwo,PATHINFO_EXTENSION)); // get image extension
		
			// valid image extensions
			$valid_extensionstwo = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
		
			// rename uploading image
			$imgtwo = rand(1000,1000000).".".$imgExttwo;
				
			// allow valid image file formats
			if(in_array($imgExttwo, $valid_extensionstwo)){			
				// Check file size '5MB'
				if($imgSizetwo < 5000000)				{
					move_uploaded_file($tmp_dirtwo,$upload_dirtwo.$imgtwo);
				}
				else{
					$errMSG = "Sorry, your file is too large.";
				}
			}
			else{
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
			}
		}
			if(empty($imgFilethree)){
			$errMSG = "Please Select Image file.";
		}
		else 
			{
			$upload_dirthree = 'user_images/'; // upload directory
	
			$imgExtthree = strtolower(pathinfo($imgFilethree,PATHINFO_EXTENSION)); // get image extension
		
			// valid image extensions
			$valid_extensionsthree = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
		
			// rename uploading image
			$imgthree = rand(1000,1000000).".".$imgExtthree;
				
			// allow valid image file formats
			if(in_array($imgExtthree, $valid_extensionsthree)){			
				// Check file size '5MB'
				if($imgSizethree < 5000000)				{
					move_uploaded_file($tmp_dirthree,$upload_dirthree.$imgthree);
				}
				else{
					$errMSG = "Sorry, your file is too large.";
				}
			}
			else{
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
			}
		}
			if(empty($imgFilefour)){
			$errMSG = "Please Select Image file.";
		}
		else 
			{
			$upload_dirfour = 'user_images/'; // upload directory
	
			$imgExtfour = strtolower(pathinfo($imgFilefour,PATHINFO_EXTENSION)); // get image extension
		
			// valid image extensions
			$valid_extensionsfour = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
		
			// rename uploading image
			$imgfour = rand(1000,1000000).".".$imgExtfour;
				
			// allow valid image file formats
			if(in_array($imgExtfour, $valid_extensionsfour)){			
				// Check file size '5MB'
				if($imgSizefour < 5000000)				{
					move_uploaded_file($tmp_dirfour,$upload_dirfour.$imgfour);
				}
				else{
					$errMSG = "Sorry, your file is too large.";
				}
			}
			else{
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
			}
		}
			if(empty($imgFilefive)){
			$errMSG = "Please Select Image file.";
		}
		else 
			{
			$upload_dirfive = 'user_images/'; // upload directory
	
			$imgExtfive = strtolower(pathinfo($imgFilefive,PATHINFO_EXTENSION)); // get image extension
		
			// valid image extensions
			$valid_extensionsfive = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
		
			// rename uploading image
			$imgfive = rand(1000,1000000).".".$imgExtfive;
				
			// allow valid image file formats
			if(in_array($imgExtfive, $valid_extensionsfive)){			
				// Check file size '5MB'
				if($imgSizefive < 5000000)				{
					move_uploaded_file($tmp_dirfive,$upload_dirfive.$imgfive);
				}
				else{
					$errMSG = "Sorry, your file is too large.";
				}
			}
			else{
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
			}
		}
			if(empty($imgFilesix)){
			$errMSG = "Please Select Image file.";
		}
		else 
			{
			$upload_dirsix = 'user_images/'; // upload directory
	
			$imgExtsix = strtolower(pathinfo($imgFilesix,PATHINFO_EXTENSION)); // get image extension
		
			// valid image extensions
			$valid_extensionssix = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
		
			// rename uploading image
			$imgsix = rand(1000,1000000).".".$imgExtsix;
				
			// allow valid image file formats
			if(in_array($imgExtsix, $valid_extensionssix)){			
				// Check file size '5MB'
				if($imgSizesix < 5000000)				{
					move_uploaded_file($tmp_dirsix,$upload_dirsix.$imgsix);
				}
				else{
					$errMSG = "Sorry, your file is too large.";
				}
			}
			else{
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
			}
		}
		if(empty($imgFile)){
			$errMSG = "Please Select Image file.";
		}
		else
		{
			$upload_dir = 'user_images/'; // upload directory
	
			$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
		
			// valid image extensions
			$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
		
			// rename uploading image
			$img = rand(1000,1000000).".".$imgExt;
				
			// allow valid image file formats
			if(in_array($imgExt, $valid_extensions)){			
				// Check file size '5MB'
				if($imgSize < 5000000)				{
					move_uploaded_file($tmp_dir,$upload_dir.$img);
				}
				else{
					$errMSG = "Sorry, your file is too large.";
				}
			}
			else{
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
			}
		}
		
		
		
		// if no error occured, continue ....
		if(!isset($errMSG))
		{
			$stmt = $connection->prepare('INSERT INTO newstbl(dfn,mini,whole,test,onet,onep,twot,twop,threet,threep,fourt,fourp,fivet,fivep,sixt,sixp,modid,newmod) VALUES(:dfn, :mini, :whole, :test, :onet, :onep, :twot, :twop, :threet, :threep, :fourt, :fourp, :fivet, :fivep, :sixt, :sixp, :modid, :newmod)');
			$stmt->bindParam(':dfn',$dfn);
			$stmt->bindParam(':mini',$mini);
			$stmt->bindParam(':whole',$whole);
			$stmt->bindParam(':test',$test);
			$stmt->bindParam(':onet',$onet);
			$stmt->bindParam(':onep',$onep);
			$stmt->bindParam(':twop',$twop);
			$stmt->bindParam(':twot',$twot);
			$stmt->bindParam(':threet',$threet);
			$stmt->bindParam(':threep',$threep);
			$stmt->bindParam(':fourt',$fourt);
			$stmt->bindParam(':fourp',$fourp);
			$stmt->bindParam(':fivet',$fivet);
			$stmt->bindParam(':fivep',$fivep);
			$stmt->bindParam(':sixt',$sixt);
			$stmt->bindParam(':sixp',$sixp);
			$stmt->bindParam(':modid',$modid);
			$stmt->bindParam(':newmod',$newmod);

			if($stmt->execute())
			{
				$successMSG = "new record succesfully inserted ...";
				 // redirects image view page after 5 seconds.
				
			}
			else
			{
				$errMSG = "error while inserting....";
			}
		}
	}
?>


<!DOCTYPE html>
<html>
<head>
	<title>backend</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" href="css/backend.css">
<script>
$(document).ready(function(){
	$("#slideshow").hide(0000);
    $("#slidebtn").click(function(){
        $("#slideshow").slideToggle(800);
    });
});
function cho(){
		var a=document.getElementById('choose').value;
		document.getElementById('responed').innerHTML="your selected :"+a;

		}
</script>
</head>
<body>
	<?php include 'backendmods.php'; ?>
	
		<div class="container paddingch">
			<?php
	if(isset($errMSG)){
			?>
            <div class="alert alert-danger">
            	<span class="glyphicon glyphicon-info-sign"></span> <strong><?php echo $errMSG; ?></strong>
            </div>
            <?php
	}
	else if(isset($successMSG)){
		?>
        <div class="alert alert-success">
              <strong><span class="glyphicon glyphicon-info-sign"></span> <?php echo $successMSG; ?></strong>
        </div>
        <?php
	}
	?>  
			<h1>Student Registeration !</h1>
			<form  method="post" enctype="multipart/form-data"  class="form-horizontal">
				<div class="form-group">
			      <label for="email">Date of news(also text eg(full mooom of---))</label>
			      <input name="dfn" type="text" class="form-control" value="<?php echo $dfn; ?>"  >
			    </div>
			    <div class="form-group">
			      <label for="email">for read more text:</label>
			      <input name="mini" type="text" class="form-control" value="<?php echo $mini; ?>"  >
			    </div>
			    <div class="form-group">
			      <label for="pwd">full text</label>
			      <textarea class="form-control commentss"  name="whole" placeholder="comment here" rows="5" ><?php echo $whole; ?></textarea><br>
			    </div>

			    <div class="form-group">
			      <label for="pwd"><!-- read more photo(Selete images) -->
			      	Selete Photo
			      </label>
			     <input class="input-group" type="file" name="test" accept="image/*" />
			      
					
			      
			    </div>
			    <!-- one -->
			    <div class="panel panel-default">
				    <div class="panel-heading">
				    	<div class="form-group">
					      <label for="pwd" style="color: black;">image discation</label>
					      <input name="onet" type="text" class="form-control " value="<?php echo $onet; ?>">
					    </div>
				    </div>
				    <div class="panel-body">
				    	<div class="form-group">
					      <label for="pwd"  style="color: black;">Selete images</label>
					      
					      <input class="input-group" type="file" name="onep" accept="image/*" />
					    </div>
				    </div>
				  </div>

				  <!-- one -->
			    <div class="panel panel-default">
				    <div class="panel-heading">
				    	<div class="form-group">
					      <label for="pwd"  style="color: black;">image discation</label>
					      <input name="twot" type="text" class="form-control" value="<?php echo $twot; ?>">
					    </div>
				    </div>
				    <div class="panel-body">
				    	<div class="form-group">
					      <label for="pwd"  style="color: black;">Selete images</label>
					      
					      <input class="input-group" type="file" name="twop" accept="image/*" />
					    </div>
				    </div>
				  </div>

				  <!-- one -->
			    <div class="panel panel-default">
				    <div class="panel-heading">
				    	<div class="form-group">
					      <label for="pwd"  style="color: black;">image discation</label>
					      <input name="threet" type="text" class="form-control" value="<?php echo $threet; ?>">
					    </div>
				    </div>
				    <div class="panel-body">
				    	<div class="form-group">
					      <label for="pwd"  style="color: black;">Selete images</label>
					     
					      <input class="input-group" type="file" name="threep" accept="image/*" />
					    </div>
				    </div>
				  </div>

				  <!-- one -->
			    <div class="panel panel-default">
				    <div class="panel-heading">
				    	<div class="form-group">
					      <label for="pwd" style="color: black;">image discation</label>
					      <input name="fourt" type="text" class="form-control" value="<?php echo $fourt; ?>">
					    </div>
				    </div>
				    <div class="panel-body">
				    	<div class="form-group">
					      <label for="pwd" style="color: black;">Selete images</label>
					      
					      <input class="input-group" type="file" name="fourp" accept="image/*" />
					    </div>
				    </div>
				  </div>

				  <!-- one -->
			    <div class="panel panel-default">
				    <div class="panel-heading">
				    	<div class="form-group">
					      <label for="pwd" style="color: black;">image discation</label>
					      <input name="fivet" type="text" class="form-control" value="<?php echo $fivet; ?>">
					    </div>
				    </div>
				    <div class="panel-body">
				    	<div class="form-group">
					      <label for="pwd" style="color: black;">Selete images</label>
					      
					      <input class="input-group" type="file" name="fivep" accept="image/*" />
					    </div>
				    </div>
				  </div>

				  <!-- one -->
			    <div class="panel panel-default">
				    <div class="panel-heading">
				    	<div class="form-group">
					      <label for="pwd" style="color: black;">image discation</label>
					      <input name="sixt" type="text" class="form-control" value="<?php echo $sixt; ?>">
					    </div>
				    </div>
				    <div class="panel-body">
				    	<div class="form-group">
					      <label for="pwd" style="color: black;">Selete images</label>
					      
					      <input class="input-group" type="file" name="sixp" accept="image/*" />
							</select>
					    </div>
				    </div>
				  </div>


			    <div class="form-group">
			      <label for="pwd">plz put number not same </label>
			      <input name="modid" type="text" class="form-control" value="<?php echo $modid; ?>">
			    </div>
			    
			    <select class="form-control"  name="newmod">
				    <option value="<?php echo $proid; ?>"><?php echo $proid; ?></option>
					<option value="visibility:hidden">No New mode</option>
					<option value="visibility:visible">New mode</option>
				
				</select>
			    <button type="submit" name="btnsave" class="btn btn-primary buttton" >Submit</button>
			</form>

		
		</div>

		
  

<div class="container">
  <h2 style="color: white;">Registration result</h2>
  <!-- <p>Contextual classes can be used to color table rows or table cells. The classes that can be used are: .active, .success, .info, .warning, and .danger.</p> --> <div class="table-responsive"> 
  <table class="table">
    <thead>
      <tr class="whiteforth">
      	<th>no#</th>
        <th>id#</th>
        <th>Date of news</th>
        <th>read more text</th>
        <th>full text</th>
        <th>read more photo</th>
        <th>photo1 text</th>
        <th>photo1</th>

        <th>photo2 text</th>
        <th>photo2</th>

        <th>photo3 text</th>
        <th>photo3</th>

        <th>photo4 text</th>
        <th>photo4</th>

        <th>photo5 text</th>
        <th>photo5</th>

        <th>photo6 text</th>
        <th>photo6</th>
        
        <th>mordel id</th>
        <th>mode new</th>
        <th>edit</th>
        <th>delete</th>

      </tr>
    </thead>

    <tbody>
 				<?php 
 				$x=0;
                    while($a = mysqli_fetch_assoc($new)){ 
                     $x=$x + 1;   
                ?>

      <tr class="success">
      	<td><?php echo $x; ?></td>
      	<td><?php echo $a['neid']?></td>
        <td><?php echo $a['dfn']?></td>
        <td><?php echo $a['mini']?></td>
        <td><?php echo $a['whole']?></td>
        <td><?php echo $a['test']?></td>

        <td><?php echo $a['onet']?></td>
        <td><?php echo $a['onep']?></td>

        <td><?php echo $a['twot']?></td>
        <td><?php echo $a['twop']?></td>

        <td><?php echo $a['threet']?></td>
        <td><?php echo $a['threep']?></td>

        <td><?php echo $a['fourt']?></td>
        <td><?php echo $a['fourp']?></td>

        <td><?php echo $a['fivet']?></td>
        <td><?php echo $a['fivep']?></td>

        <td><?php echo $a['sixt']?></td>
        <td><?php echo $a['sixp']?></td>
        
        <td><?php echo $a['modid']?></td>
        <td><?php echo $a['newmod']?></td>
        <td>
        	<?php 
                        $g = '1QwiYiip123Foho';
                        if($g == $gi['idname']){
                          ?>                  
                          <a href="editnew.php?neid=<?php echo $a['neid']; ?>"><button class="btn btn-primary" type="button">edit</button></a>
                          <?php
                        }else{
                          ?>  
                          <p style="color: red;"> 
                            you con't edit
                          </p>
                        
                        <?php
                      }
                      ?>
        </td>
        <td>
        	<?php 
                        $g = '1QwiYiip123Foho';
                        if($g == $gi['idname']){
                          ?>                  
                          <a href="deletenews.php?neid=<?php echo $a['neid']; ?>"><button class="btn btn-danger" type="button">Delete</button></a>
                          <?php
                        }else{
                          ?>  
                          <p style="color: red;"> 
                            you con't delete
                          </p>
                        
                        <?php
                      }
                      ?>
        </td>
        
      </tr>
      			  <?php 
      			  
                      }
                  ?>

    </tbody>


  </table>
</div>
</div>
</body>
</html>