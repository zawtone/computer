<?php

class Database{
	
	private $connection;

	function __construct()
	{
		$this->connect_db();
	}

	public function connect_db(){
		$this->connection = mysqli_connect('localhost', 'root', '', 'compnyk');
		if(mysqli_connect_error()){
			die("Database Connection Failed" . mysqli_connect_error() . mysqli_connect_errno());
		}
	}





	public function create($name,$fname,$dofb,$nrcno,$edu,$occ,$computer,$phone,$address,$batches,$batches1,$section,$price,$photo){
		$sql = "INSERT INTO `register` (name, fname, dofb, nrcno, edu, occ, computer, phone, address, batches, batches1, section, price, photo) VALUES ('$name', '$fname', '$dofb', '$nrcno', '$edu', '$occ', '$computer', '$phone', '$address', '$batches', '$batches1', '$section', '$price, '$photo')";
		$res = mysqli_query($this->connection, $sql);
		if($res){
	 		return true;
		}else{
			return false;
		}
	}


	/*news*/
	public function newscreate($dfn,$mini,$whole,$test,$onet,$onep,$twot,$twop,$threet,$threep,$fourt,$fourp,$fivet,$fivep,$sixt,$sixp,$modid,$newmod){
		$sql = "INSERT INTO `newstbl` (dfn, mini, whole, test, onet, onep, twot, twop, threet, threep, fourt, fourp, fivet, fivep, sixt, sixp, modid, newmod) VALUES ('$dfn', '$mini', '$whole', '$test', '$onet', '$onep', '$twot', '$twop', '$threet', '$threep', '$fourt', '$fourp', '$fivet', '$fivep', '$sixt', '$sixp', '$modid', '$newmod')";
		$ress = mysqli_query($this->connection, $sql);
		if($ress){
	 		return true;
		}else{
			return false;
		}
	}

	/*computer service inset*/
	public function comcreate($serimg,$prjid,$imfor,$percen,$fin,$modelid,$redate,$findate){
		$sql = "INSERT INTO `comservice` (serimg, prjid, imfor, percen, fin, modelid, redate, findate) VALUES ('$serimg', '$prjid', '$imfor', '$percen', '$fin', '$modelid', '$redate', ',$findate')";
		$ress = mysqli_query($this->connection, $sql);
		if($ress){
	 		return true;
		}else{
			return false;
		}
	}

	/*expenses*/
	public function expencreate($exdate,$exitem,$exunit,$examount){
		$sql = "INSERT INTO `expenses` (exdate, exitem, exunit, examount) VALUES ('$exdate', '$exitem', '$exunit', '$examount')";
		$ress = mysqli_query($this->connection, $sql);
		if($ress){
	 		return true;
		}else{
			return false;
		}
	}

	/*login adim*/
	public function loigncreate($lname,$pass,$idname){
		$sql = "INSERT INTO `login` (lname, pass, idname) VALUES ('$lname', '$pass', '$idname')";
		$ress = mysqli_query($this->connection, $sql);
		if($ress){
	 		return true;
		}else{
			return false;
		}
	}



	/*comment*/
	public function ccreate($cname,$comment){
		$sql = "INSERT INTO `comment` (cname, comment) VALUES ('$cname', '$comment')";
		$res = mysqli_query($this->connection, $sql);
		if($res){
	 		return true;
		}else{
			return false;
		}
	}

	
	
	/*end*/


	/*comment read*/
	public function cread($cid=null){
		$sql = 'SELECT * FROM comment ORDER BY cid DESC';
		if($cid){ $sql .= " WHERE cid=$cid";}
 		$res = mysqli_query($this->connection, $sql);
 		return $res;
	}

	public function creaded($cid=null){
		$sql = "SELECT * FROM `comment`";
		if($cid){ $sql .= " WHERE cid=$cid";}
 		$res = mysqli_query($this->connection, $sql);
 		return $res;
	}


	
	public function caread($id=null){
		$sql = "SELECT * FROM `tblproduct`";
		if($id){ $sql .= " WHERE id=$id";}
 		$res = mysqli_query($this->connection, $sql);
 		return $res;
	}

	/*register read*/
	public function read($rid=null){
		$sql = "SELECT * FROM `register`";
		if($rid){ $sql .= " WHERE rid=$rid";}
 		$res = mysqli_query($this->connection, $sql);
 		return $res;
	}


	/*news read*/
	public function newsread($neid=null){
		$sql = 'SELECT * FROM newstbl ORDER BY neid DESC';
		if($neid){ $sql .= " WHERE neid=$neid";}
 		$res = mysqli_query($this->connection, $sql);
 		return $res;
	}

	public function newsreaded($neid=null){
		$sql = "SELECT * FROM `newstbl`";
		if($neid){ $sql .= " WHERE neid=$neid";}
 		$res = mysqli_query($this->connection, $sql);
 		return $res;
	}

	/*compuer sercide read*/
	public function comread($serid=null){
		$sql = "SELECT * FROM `comservice`";
		if($serid){ $sql .= " WHERE serid=$serid";}
 		$res = mysqli_query($this->connection, $sql);
 		return $res;
	}

	/*compuer sercide read new*/
	public function servicesread($id=null){
		$sql = "SELECT * FROM `services`";
		if($id){ $sql .= " WHERE id=$id";}
 		$res = mysqli_query($this->connection, $sql);
 		return $res;
	}

	/*expenses*/
	public function expenread($exid=null){
		$sql = "SELECT * FROM `expenses`";
		if($exid){ $sql .= " WHERE exid=$exid";}
 		$res = mysqli_query($this->connection, $sql);
 		return $res;
	}

	/*login admin*/
	public function loginread($id=null){
		$sql = "SELECT * FROM `login`";
		if($id){ $sql .= " WHERE id=$id";}
 		$res = mysqli_query($this->connection, $sql);
 		return $res;
	}


	/*register update*/
	public function update($name,$fname,$dofb,$nrcno,$edu,$occ,$computer,$phone,$address,$batches,$batches1,$section,$price,$photo, $rid){
		$sql = "UPDATE `register` SET name='$name', fname='$fname', dofb='$dofb', nrcno='$nrcno', edu='$edu', occ='$occ', computer='$computer', phone='$phone', address='$address', batches='$batches', batches1='$batches1', section='$section', price='$price', photo='$photo' WHERE rid=$rid";
		$res = mysqli_query($this->connection, $sql);
		if($res){
			return true;
		}else{
			return false;
		}
	}


	/*comment update*/
	public function cupdate($cname,$comment, $cid){
		$sql = "UPDATE `comment` SET cname='$cname', comment='$comment' WHERE cid=$cid";
		$res = mysqli_query($this->connection, $sql);
		if($res){
			return true;
		}else{
			return false;
		}
	}



	/*update news*/

	public function newsupdate($dfn,$mini,$whole,$test,$onet,$onep,$twot,$twop,$threet,$threep,$fourt,$fourp,$fivet,$fivep,$sixt,$sixp,$modid,$newmod, $neid){
		$sql = "UPDATE `newstbl` SET dfn='dfn', mini='$mini', whole='$whole', test='$test', onet='$onet', onep='$onep', twot='$twot', twop='$twop', threet='$threet', threep='$threep', fourt='$fourt', fourp='$fourp', fivet='$fivet, fivep'='$fivep', sixt='$sixt', sixp='$sixp', modid='$modid', newmod='$newmod' WHERE neid=$neid";
		$res = mysqli_query($this->connection, $sql);
		if($res){
			return true;
		}else{
			return false;
		}
	}



	/*commet reply*/
	public function rupdate($reply, $cid){
		$sql = "UPDATE `comment` SET reply='$reply' WHERE cid=$cid";
		$res = mysqli_query($this->connection, $sql);
		if($res){
			return true;
		}else{
			return false;
		}
	}
	/*end*/

	/*update computer service*/
	
	public function comupdate($serimg,$prjid,$imfor,$percen,$fin,$modelid,$redate,$findate, $serid){
		$sql = "UPDATE `comservice` SET serimg='$serimg', prjid='$prjid', imfor='$imfor', percen='$percen', fin='$fin', modelid='$modelid', redate='$redate', findate='$findate', serid='$serid' WHERE serid=$serid";
		$res = mysqli_query($this->connection, $sql);
		if($res){
			return true;
		}else{
			return false;
		}
	}

	/*update expenses*/
	public function expenupdate($exdate,$exitem,$exunit,$examount, $exid){
		$sql = "UPDATE `expenses` SET exdate='$exdate', exitem='$exitem', exunit='$exunit', examount='$examount', exid='$exid' WHERE exid=$exid";
		$res = mysqli_query($this->connection, $sql);
		if($res){
			return true;
		}else{
			return false;
		}
	}

	/*login admin*/
	public function loginupdate($lname,$pass,$idname, $id){
		$sql = "UPDATE `login` SET lname='$lname', pass='$pass', idname='$idname', id='$id' WHERE id=$id";
		$res = mysqli_query($this->connection, $sql);
		if($res){
			return true;
		}else{
			return false;
		}
	}


	public function delete($rid){
		$sql = "DELETE FROM `register` WHERE rid=$rid";
 		$res = mysqli_query($this->connection, $sql);
 		if($res){
 			return true;
 		}else{
 			return false;
 		}
	}


	public function deletec($cid){
		$sql = "DELETE FROM `comment` WHERE cid=$cid";
 		$res = mysqli_query($this->connection, $sql);
 		if($res){
 			return true;
 		}else{
 			return false;
 		}
	}

	/*news delete*/
	public function deletenews($neid){
		$sql = "DELETE FROM `newstbl` WHERE neid=$neid";
 		$res = mysqli_query($this->connection, $sql);
 		if($res){
 			return true;
 		}else{
 			return false;
 		}
	}


	/*computer service*/
	public function comdelete($serid){
		$sql = "DELETE FROM `comservice` WHERE serid=$serid";
 		$res = mysqli_query($this->connection, $sql);
 		if($res){
 			return true;
 		}else{
 			return false;
 		}
	}

	/*expenses*/
	public function expendelete($exid){
		$sql = "DELETE FROM `expenses` WHERE exid=$exid";
 		$res = mysqli_query($this->connection, $sql);
 		if($res){
 			return true;
 		}else{
 			return false;
 		}
	}


	/*login delete*/
	public function logindelete($id){
		$sql = "DELETE FROM `login` WHERE id=$id";
 		$res = mysqli_query($this->connection, $sql);
 		if($res){
 			return true;
 		}else{
 			return false;
 		}
	}





	public function sanitize($var){
		$return = mysqli_real_escape_string($this->connection, $var);
		return $return;
	}

	/*val*/
	
	public function login($lname, $pass){
 
           

	            $sql2="SELECT id FROM login WHERE lname='$lname' and pass='$pass'";

	 

	            //checking if the username is available in the table

	            $result = mysqli_query($this->connection,$sql2);

	            $user_data = mysqli_fetch_array($result);

	            $count_row = $result->num_rows;

	 

	            if ($count_row == 1) {

	                // this login var will use for the session thing

	                $_SESSION['login'] = true;

	                $_SESSION['id'] = $user_data['id'];

	                return true;

	            }

	            else{

	                return false;

	            }

	        }

	 

	         /*** for showing the username or fullname ***/

	        public function get_fullname($id){

	            $sql2="SELECT idname FROM login WHERE id = $id";

	             $result = mysqli_query($this->connection,$sql2);

	            $user_data = mysqli_fetch_array($result);

	            /*$res = $user_data['lname'];*/
	            return $user_data;
	        }

	        

	 

	        /*** starting the session ***/

	        public function get_session(){

	            return $_SESSION['id'];

	        }
	       
      /*val end*/ 


      /*val*/
	
	public function register($batches, $batches1){
 
           

	            $sql2="SELECT rid FROM register WHERE batches='$batches' and batches1='$batches1'";

	 

	            //checking if the username is available in the table

	            $result = mysqli_query($this->connection,$sql2);

	            $user_data = mysqli_fetch_array($result);

	            $count_row = $result->num_rows;

	 

	            if ($count_row == 1) {

	                // this login var will use for the session thing

	                $_SESSION['register'] = true;

	                $_SESSION['rid'] = $user_data['rid'];

	                return true;

	            }

	            else{

	                return false;

	            }

	        }

	 

	         /*** for showing the username or fullname ***/

	        public function sget_fullname($rid){

	            $sql2="SELECT section FROM register WHERE rid = $rid";

	             $result = mysqli_query($this->connection,$sql2);

	            $user_data = mysqli_fetch_array($result);

	            echo $user_data['section'];
	        }

	         /*** for showing the username or fullname ***/

	        public function ssget_fullname($rid){

	            $sql2="SELECT name FROM register WHERE rid = $rid";

	             $result = mysqli_query($this->connection,$sql2);

	            $user_data = mysqli_fetch_array($result);

	            echo $user_data['name'];
	        }

	         /*** for showing the username or fullname ***/

	        public function sssget_fullname($rid){

	            $sql2="SELECT batches FROM register WHERE rid = $rid";

	             $result = mysqli_query($this->connection,$sql2);

	            $user_data = mysqli_fetch_array($result);

	            echo $user_data['batches'];
	            
	        }

	        

	 

	        /*** starting the session ***/

	        public function sget_session(){

	            return $_SESSION['rid'];

	        }
	       
      /*val end*/ 



      

     
}


$database = new Database();

?>