<?php

	
		error_reporting( ~E_NOTICE ); // avoid notice
		require_once 'connection.php';
	
	if(isset($_GET['edit_id']) && !empty($_GET['edit_id']))
	{
		$id = $_GET['edit_id'];
		$stmt_edit = $connection->prepare('SELECT serv, infor, proid, modid, img, redate, findate, fin, per, phone FROM services WHERE id =:id');
		$stmt_edit->execute(array(':id'=>$id));
		$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
		extract($edit_row);
	}
	else
	{
		header("Location: servicescom.php");
	}
	
	
	
	if(isset($_POST['btn_save_updates']))
	{
		$serv = $_POST['serv'];
		$infor = $_POST['infor'];// user name
		$proid = $_POST['proid'];
		$modid = $_POST['modid'];
		$redate = $_POST['redate'];
		$findate = $_POST['findate'];
		$fin = $_POST['fin'];
		$per = $_POST['per'];
		$phone = $_POST['phone'];
			
		$imgFile = $_FILES['img']['name'];
		$tmp_dir = $_FILES['img']['tmp_name'];
		$imgSize = $_FILES['img']['size'];
					
		if($imgFile)
		{
			$upload_dir = 'user_images/'; // upload directory	
			$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
			$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
			$userpic = rand(1000,1000000).".".$imgExt;
			if(in_array($imgExt, $valid_extensions))
			{			
				if($imgSize < 5000000)
				{
					unlink($upload_dir.$edit_row['img']);
					move_uploaded_file($tmp_dir,$upload_dir.$userpic);
				}
				else
				{
					$errMSG = "Sorry, your file is too large it should be less then 5MB";
				}
			}
			else
			{
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
			}	
		}
		else
		{
			// if no image selected the old image remain as it is.
			$userpic = $edit_row['img']; // old image from database
		}	
						
		
		// if no error occured, continue ....
		if(!isset($errMSG))
		{
			$stmt = $connection->prepare('UPDATE services
									     SET serv=:serv,
									     	 infor=:infor,
									     	 proid=:proid,
									     	 modid=:modid,
									     	 img=:img,
									     	 redate=:redate,
									     	 findate=:findate,
									     	 fin=:fin,
										     per=:per,
										     phone=:phone
								       WHERE id=:id');
			
			$stmt->bindParam(':serv',$serv);
			$stmt->bindParam(':infor',$infor);
			$stmt->bindParam(':proid',$proid);
			$stmt->bindParam(':modid',$modid);
			$stmt->bindParam(':img',$userpic);
			$stmt->bindParam(':redate',$redate);
			$stmt->bindParam(':findate',$findate);
			$stmt->bindParam(':fin',$fin);
			$stmt->bindParam(':per',$per);
			$stmt->bindParam(':phone',$phone);
			$stmt->bindParam(':id',$id);
				
			if($stmt->execute()){
				
				?>
                <script>
				alert('Successfully Updated ...');
				window.location.href='servicescom.php';
				</script>
                <?php
				
			}
			else{
				$errMSG = "Sorry Data Could Not Updated !";
			}
		
		}
		
						
	}
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Upload, Insert, Update, Delete an Image using PHP MySQL - Coding Cage</title>

<link rel="stylesheet" href="css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="css/bootstrap-theme.min.css">

<!-- custom stylesheet -->


<!-- Latest compiled and minified JavaScript -->
<script src="js/bootstrap.min.js"></script>

<script src="jquery-1.11.3-jquery.min.js"></script>
</head>
<body>




<div class="container">


	

<div class="clearfix"></div>

<form method="post" enctype="multipart/form-data" class="form-horizontal" >
	
    
    <?php
	if(isset($errMSG)){
		?>
        <div class="alert alert-danger">
          <span class="glyphicon glyphicon-info-sign"></span> &nbsp; <?php echo $errMSG; ?>
        </div>
        <?php
	}
	?>
   
    
	<table class="table table-bordered table-responsive">
	<tr>
    	<td><label class="control-label">Services options.</label></td>
        <td><select name="serv" class="form-control">
        <option value="<?php echo $serv; ?>"><?php echo $serv; ?></option>
        <option value="PCL">PC and Laptop</option>
        <option value="PRI">Printer</option>
        <option value="NET">Network</option>
        <option value="WEB">Web Developing</option>
      
      </select></td>
    </tr>
    <tr>
    	<td><label class="control-label">information.</label></td>
        <td><textarea class="form-control"  name="infor" placeholder="Items" rows="5"><?php echo $infor; ?></textarea></td>
    </tr>
     <tr>
    	<td><label class="control-label">Produt id.</label></td>
        <td><input class="form-control" type="text" name="proid" value="<?php echo $proid; ?>"  /></td>
    </tr>
    <tr>
    	<td><label class="control-label">Phone no.</label></td>
        <td><input class="form-control" type="text" name="phone" value="<?php echo $phone; ?>"  /></td>
    </tr>

    
    <tr>
    	<td><label class="control-label">Photo.</label></td>
        <td>
        	<p><img src="user_images/<?php echo $img; ?>" height="100" width="100" /></p>
        	<input class="input-group" type="file" name="img" accept="image/*" />
        </td>
    </tr>
    <tr>
    	<td><label class="control-label">reseive date.</label></td>
        <td><input class="form-control" type="text" name="redate" value="<?php echo $redate; ?>"  /></td>
    </tr>
    <tr>
    	<td><label class="control-label">finish date.</label></td>
        <td><input class="form-control" type="text" name="findate" value="<?php echo $findate; ?>"  /></td>
    </tr>
    <tr>
    	<td><label class="control-label">Finish or not.</label></td>
        <td><input class="form-control" type="text" name="fin" value="<?php echo $fin; ?>"  /></td>
    </tr>
    <tr>
    	<td><label class="control-label">percentage.</label></td>
    	
		  
		
        <td><input class="form-control" type="text" name="per" value="<?php echo $per; ?>"  /></td>
    </tr>
    <tr>
    	<td><label class="control-label">Model id.</label></td>
        <td><input class="form-control" type="text" name="modid" value="<?php echo $modid; ?>"  /></td>
    </tr>
   
    <tr>
        <td colspan="2"><button type="submit" name="btn_save_updates" class="btn btn-default">
        <span class="glyphicon glyphicon-save"></span> Update
        </button>
        
        <a class="btn btn-default" href="servicescom.php"> <span class="glyphicon glyphicon-backward"></span> cancel </a>
        
        </td>
    </tr>
    
    </table>
    
</form>




</div>
</body>
</html>