<?php
require_once('database.php');

$res_admin = $database->cread();
$res_admins = $database->cread();



session_start();

$database = new Database(); $id = $_SESSION['id'];
$gi = $database->get_fullname($id);
if (!$database->get_session()){
 header("location:index.php");
}





?>

<!DOCTYPE html>
<html>
<head>
	<title>backend</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/backend.css">
<script>
$(document).ready(function(){
	$("#slideshow").hide(0000);
    $("#slidebtn").click(function(){
        $("#slideshow").slideToggle(800);
    });
});
</script>
</head>
<body>
	<?php include 'backendmods.php'; ?>
<!-- nenu -->
		
		<div class="container paddingch">

			<h2 class="headerback">message box</h2>

			<!-- to edit and remove messages -->
			<?php $x=0;
			while($a = mysqli_fetch_assoc($res_admin)){  
				$x=$x+1;  
				?>
				<div class="panel panel-info">
					<div class="panel-heading"><span class="badge"><?php echo $x;?></span><?php echo $a['cname']?></div>
					<div class="panel-body"><?php echo $a['comment']?></div>
					<div class="panel-body"style="color: gray;">reply :<br> <br><?php echo $a['reply']?></div>
					<hr>
					<ul class="pager">
						<li>
							<?php 
                        $g = '1QwiYiip123Foho';
                        if($g == $gi['idname']){
                          ?>                  
                          <a style="float: right; margin-right: 10px;" href="deletec.php?cid=<?php echo $a['cid']; ?>">Delete</a>
                          <?php
                        }else{
                          ?>  
                          <p style="color: red; float: right; margin-right: 10px;"> 
                            you con't delete
                          </p>
                        
                        <?php
                      }
                      ?>
						</li>
						<li>
						<?php 
                        $g = '1QwiYiip123Foho';
                        if($g == $gi['idname']){
                          ?>                  
                          <a style="float: right; margin-right: 10px;" href="editc.php?cid=<?php echo $a['cid']; ?>">Edit</a>
                          <?php
                        }else{
                          ?>  
                          <p style="color: red; float: right; margin-right: 10px;"> 
                            you con't edit
                          </p>
                        
                        <?php
                      }
                      ?></li>
					</ul>














					<div class="container">
						<!-- Trigger the modal with a button -->


						

						<?php 
                        $g = '1QwiYiip123Foho';
                        if($g == $gi['idname']){
                          ?>                  
                          <a href="commentreply.php?cid=<?php echo $a['cid']; ?>"><button  type="button" class="btn btn-info btn-lg"  style="margin-right: auto !important;
						display: block;
						margin-left: auto;
						margin-bottom: 10px;"> To reply </button></a>
                          <?php
                        }else{
                          ?>  
                          <p style="color: red; text-align: center;"> 
                            you con't reply
                          </p>
                        
                        <?php
                      }
                      ?>

					</div>















				</div>


				<!-- reply -->



				<?php 
			}
			?> 










		</div>


		<!-- Modal -->
		<div class="modal fade" id="myModal" role="dialog">
			<div class="modal-dialog">

				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Modal Header</h4>
					</div>
					<div class="modal-body">

					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>

			</div>
		</div>

	
	
</body>
</html>