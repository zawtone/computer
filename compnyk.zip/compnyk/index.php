<!DOCTYPE html>
<html>
<head>
	<title>forcomputer</title>
  <meta   charset="utf-8" />
  
  <link rel="shortcut icon" href="http://localhost/compnyk/pics/logopnyk.jpg">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/subject.css">
  <link rel="stylesheet" type="text/css" href="css/news.css">
  <link rel="stylesheet" type="text/css" href="css/width320.css">
  <link rel="stylesheet" type="text/css" href="css/query768.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	
<!-- window -->
	<script src="js/window.js"></script>
<!---- start-smoth-scrolling---->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<!---- start-smoth-scrolling---->
<style type="text/css">
	.actives{
		border-bottom: 3px solid #00FFB7 !important;
	}
	.actives1{
		border-bottom: 0 !important;
	}
	.actives2{
		border-bottom: 0 !important;
	}
	.actives4{
		border-bottom: 0 !important;
	}
	.actives5{
		border-bottom: 0 !important;
	}
</style>
</head>
<body >
	<!-- for the whole -->
<div class="thewhole">
<div><!-- nav and croudel -->
	<?php
		include("nav.php");
	?>
	<?php
		include("crousel.php");
	?>
</div><!-- nav and croudle end -->

<!-- inner content -->
	<?php
		include("news.php");
	?>
	<?php
		include("subject.php");
	?>
	<?php
		include("subjectmod.php");
	?>
<!-- content end -->


<div class="footer_part "><!-- footer -->
	<?php
		include("footer.php");
	?>
</div>
	
<div class="pbzmh">
  power by zmh.
  
        
        <a href="#" class="topup" id="toTop" style="display: block;"> <span class="glyphicon glyphicon-menu-up  forupdownmenu" id="toTopHover" style="opacity: 1;"> </span></a> 
        
      
</div>
</div><!-- thewhole end -->
<script type="text/javascript">
            $(document).ready(function() {
              
             /* var defaults = {
                  containerID: 'toTop', // fading element id
                containerHoverID: 'toTopHover', // fading element hover id
                scrollSpeed: 1200,
                easingType: 'linear' 
              };*/
              
              
              $().UItoTop({ easingType: 'easeOutQuart' });
              
            });
          </script>
</body>
</html>