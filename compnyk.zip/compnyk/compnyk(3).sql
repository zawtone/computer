-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2019 at 10:25 AM
-- Server version: 5.6.17-log
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `compnyk`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(225) NOT NULL,
  `comment` varchar(2000) NOT NULL,
  `reply` varchar(2000) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`cid`, `cname`, `comment`, `reply`) VALUES
(5, 'zaw', 'A', 'ashdjkjk/'),
(6, 'Name', '', ''),
(7, 'Name', 'sdfasf', '');

-- --------------------------------------------------------

--
-- Table structure for table `comservice`
--

CREATE TABLE IF NOT EXISTS `comservice` (
  `serid` int(11) NOT NULL AUTO_INCREMENT,
  `serimg` varchar(225) NOT NULL,
  `prjid` varchar(11) NOT NULL,
  `imfor` varchar(225) NOT NULL,
  `percen` varchar(11) NOT NULL,
  `fin` varchar(22) NOT NULL,
  `modelid` varchar(11) NOT NULL,
  `redate` varchar(11) NOT NULL,
  `findate` varchar(11) NOT NULL,
  PRIMARY KEY (`serid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `comservice`
--

INSERT INTO `comservice` (`serid`, `serimg`, `prjid`, `imfor`, `percen`, `fin`, `modelid`, `redate`, `findate`) VALUES
(2, 'uploads/Screenshot from 2018-09-11 00-48-29.png', '1erwe234sd', 'asdfasdf', '12', 'visibility:hidden', '1', '11-3-2019', 'sdf'),
(3, 'uploads/Screenshot from 2018-09-11 00-48-29.png', 'asdfrwes3', 'agh asdf as  agh asdf as  agh asdf as  agh asdf as  agh asdf as  agh asdf as  agh asdf as  agh asdf as  agh asdf as  agh asdf as  agh asdf as  agh asdf as  agh asdf as  agh asdf as  agh asdf as  agh asdf as  agh asdf as  agh ', '33%%', 'visibility:hidden', '2', '112344', ''),
(4, 'uploads/Screenshot from 2018-09-11 00-48-29.png', '1134sgd', 'a sfdgdhf djgkh lj;iuytrefv cbnm,a sfdgdhf djgkh lj;iuytrefv cbnm,a sfdgdhf djgkh lj;iuytrefv cbnm,a sfdgdhf djgkh lj;iuytrefv cbnm,a sfdgdhf djgkh lj;iuytrefv cbnm,a sfdgdhf djgkh lj;iuytrefv cbnm,', '100%', 'visibility:hidden', '4', 'asdf', 'asdf'),
(5, 'uploads/pnyk (3).jpg', 'asd', 'asdfasdfasddfasdfasdfasdf', '11', 'visibility:visible', '555', 'hi', ',121212'),
(6, 'uploads/pnyk (6).jpg', '12345678', '', '99', 'visibility:hidden', '12345', '123456', ',1234567');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE IF NOT EXISTS `expenses` (
  `exid` int(22) NOT NULL AUTO_INCREMENT,
  `exdate` varchar(22) NOT NULL,
  `exitem` varchar(1000) NOT NULL,
  `exunit` varchar(22) NOT NULL,
  `examount` varchar(33) NOT NULL,
  PRIMARY KEY (`exid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`exid`, `exdate`, `exitem`, `exunit`, `examount`) VALUES
(2, '12', '1asdadfasadsfdghjgkhlj;k''l\r\n;'';lk''j;hgkjfhdsafghkjhlj;k;l''', '12', '13245'),
(3, '1231234', 'ASGDHFGJKHLJ;KLLJJGHJHGFD', '1', '1234354');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lname` varchar(225) NOT NULL,
  `pass` varchar(225) NOT NULL,
  `idname` varchar(22) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `lname`, `pass`, `idname`) VALUES
(2, 'admin', 'admin', '1QwiYiip123Foho'),
(4, 'zaq', 'zaq', ''),
(5, 'zaw', 'zaww', '1QwiYiip123Foho');

-- --------------------------------------------------------

--
-- Table structure for table `newstbl`
--

CREATE TABLE IF NOT EXISTS `newstbl` (
  `neid` int(11) NOT NULL AUTO_INCREMENT,
  `dfn` varchar(225) NOT NULL,
  `mini` varchar(225) NOT NULL,
  `whole` varchar(2000) NOT NULL,
  `test` varchar(225) NOT NULL,
  `onet` varchar(225) NOT NULL,
  `onep` varchar(225) NOT NULL,
  `twot` varchar(225) NOT NULL,
  `twop` varchar(225) NOT NULL,
  `threet` varchar(225) NOT NULL,
  `threep` varchar(225) NOT NULL,
  `fourt` varchar(225) NOT NULL,
  `fourp` varchar(225) NOT NULL,
  `fivet` varchar(225) NOT NULL,
  `fivep` varchar(225) NOT NULL,
  `sixt` varchar(225) NOT NULL,
  `sixp` varchar(225) NOT NULL,
  `modid` varchar(11) NOT NULL,
  `newmod` varchar(100) NOT NULL,
  PRIMARY KEY (`neid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `newstbl`
--

INSERT INTO `newstbl` (`neid`, `dfn`, `mini`, `whole`, `test`, `onet`, `onep`, `twot`, `twop`, `threet`, `threep`, `fourt`, `fourp`, `fivet`, `fivep`, `sixt`, `sixp`, `modid`, `newmod`) VALUES
(13, '12242', 'hihih', 'hihihihi', 'pics/basic.jpg', 'hi', 'pics/basic.jpg', 'hi', 'pics/basic.jpg', 'hi', 'pics/basic.jpg', 'hi', 'pics/basic.jpg', 'hi', 'pics/basic.jpg', 'hi', 'pics/basic.jpg', '121', 'ho');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(225) NOT NULL,
  `fname` varchar(225) NOT NULL,
  `dofb` varchar(222) NOT NULL,
  `nrcno` varchar(22) NOT NULL,
  `edu` varchar(225) NOT NULL,
  `occ` varchar(225) NOT NULL,
  `computer` varchar(225) NOT NULL,
  `phone` varchar(22) NOT NULL,
  `address` text NOT NULL,
  `batches` varchar(225) NOT NULL,
  `batches1` varchar(225) NOT NULL,
  `section` varchar(20) NOT NULL,
  `price` varchar(50) NOT NULL,
  `photo` varchar(11) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`rid`, `name`, `fname`, `dofb`, `nrcno`, `edu`, `occ`, `computer`, `phone`, `address`, `batches`, `batches1`, `section`, `price`, `photo`) VALUES
(14, 'zaw myo htut', 'u kan', '', 'no', 'first year(geology)', 'no', 'yes', '09769349441', '', '55', '12', 'A', '1500', 'Yes'),
(24, 'asdf', '', '', '', '', '', '', '12345678', '', '12', '12', 'A', '123456', ''),
(26, 'qqqqq', '', '', '', '', '', '', '123', '', '', '', 'A', '1234567', ''),
(27, 'wwww', '', '', '', '', '', '', '12345', '', '11', '', 'E', '123456', ''),
(28, 'wwwwwer', '', '', '', '', '', '', '12345', '', '11', '', 'A', '12345', ''),
(32, 'hnin', 'tnt', '782001', 'no', 'np', 'no', 'no', '00', '', '0', '', 'A', '100', ''),
(34, 'zaw', 'uk', '3202001', 'no', 'no', 'no', 'n', '12', 'asdfsdf', '123', '123', 'D', '123234', ''),
(35, 'han', '-', '123', 'no', 'no', 'no', 'no', '123', 'asdf', '123', '123', 'B', '123', ''),
(36, 'teacher', '-', '1324', 'no', 'no', 'no', 'no', '123', 'asdf', '123', '123', 'C', '123', ''),
(37, '12', '124', '24', '123', '12', '134', '1234', '1234', '134', '1234', '123', 'E', '123121', '');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE IF NOT EXISTS `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serv` varchar(100) NOT NULL,
  `infor` text NOT NULL,
  `proid` varchar(100) NOT NULL,
  `modid` int(11) NOT NULL,
  `img` varchar(100) NOT NULL,
  `redate` varchar(100) NOT NULL,
  `findate` varchar(100) NOT NULL,
  `fin` varchar(100) NOT NULL,
  `per` int(11) NOT NULL,
  `phone` int(15) NOT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `infor` (`infor`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `serv`, `infor`, `proid`, `modid`, `img`, `redate`, `findate`, `fin`, `per`, `phone`) VALUES
(4, 'WEB', 'sasdf', '123', 123, '692843.jpg', '12', '123', '123', 12, 0),
(6, 'NET', 'mm', 'compnyk-eeee', 122, '216726.jpeg', '32323', '123', 'qwe', 56, 0),
(7, 'PRI', 'show', 'wer', 1212, '852108.jpeg', '121', '123', '123', 12, 0),
(8, 'PCL', 'adsf', '12', 12, '448337.jpeg', '12', '12', '12', 44, 0),
(10, 'NET', 'asd', 'asf', 123, '920368.jpg', '4235435476', '1123', '123', 1, 0),
(11, 'NET', 'asd', 'asf', 123, '1640.jpg', '4235435476', '1123', '123', 99, 0),
(12, 'NET', 'asd', 'asf', 123, '244226.jpeg', '4235435476', '1123', '123', 99, 12312),
(13, 'PRI', 'wert', 'wrt', 123, '436447.jpg', '124', '134', '231', 11, 12345678);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
