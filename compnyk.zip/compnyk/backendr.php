<?php
require_once('database.php');

$registermain = $database->read();
session_start();
$database = new Database(); $id = $_SESSION['id'];
$gi = $database->get_fullname($id);
if (!$database->get_session()){
 header("location:login.php");
}





if(isset($_POST) & !empty($_POST)){
 $name = $database->sanitize($_POST['name']);
 $fname = $database->sanitize($_POST['fname']);
 $dofb = $database->sanitize($_POST['dofb']);
 $nrcno = $database->sanitize($_POST['nrcno']);
 $edu = $database->sanitize($_POST['edu']);
 $occ = $database->sanitize($_POST['occ']);
 $computer = $database->sanitize($_POST['computer']);
 $phone = $database->sanitize($_POST['phone']);
 $address = $database->sanitize($_POST['address']);
 $batches = $database->sanitize($_POST['batches']);
 $batches1 = $database->sanitize($_POST['batches1']);
 $section = $database->sanitize($_POST['section']);
 $price = $database->sanitize($_POST['price']);
 $photo = $database->sanitize($_POST['photo']);

 $res = $database->create($name,$fname,$dofb,$nrcno,$edu,$occ,$computer,$phone,$address,$batches,$batches1,$section,$price,$photo);
 if($res){
  header("location:backendr.php");
}else{
  echo "failed to insert data";
}
}





?>

<!DOCTYPE html>
<html>
<head>
	<title>backend</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/backend.css">
  <script>
    $(document).ready(function(){
     $("#slideshow").hide(0000);
     $("#slidebtn").click(function(){
      $("#slideshow").slideToggle(800);
    });
   });
 </script>
</head>
<body >
	<?php include 'backendmods.php'; ?>
	
  <div class="container paddingch">

    <h2 class="headerback">Student Registeration !</h2>
    <form role="form" method="post" class="bgform">
      <table class="table table-bordered table-responsive">
     <tr>
       <td> <label for="email">NAME:</label></td>
       <td><input name="name" type="text" class="form-control"  ></td>
     </tr>
     <tr>
       <td><label for="pwd">FATHER NAME:</label></td>
      <td> <input name="fname" type="text" class="form-control"></td>
     </tr>
     <tr>
       <td><label for="pwd">DATE OF BIRTH:</label></td>
      <td> <input name="dofb" type="number" class="form-control"></td>
     </tr>
     <tr>
     <td>  <label for="pwd">NRC NO:</label></td>
      <td> <input name="nrcno" type="text" class="form-control" ></td>
     </tr>
     <tr>
       <td><label for="pwd">EDUCATIONAL QUALIFICATION:</label></td>
       <td><input name="edu" type="text" class="form-control" ></td>
     </tr>
     <tr>
       <td><label for="pwd">OCCUPATION:</label></td>
       <td><input name="occ" type="text" class="form-control"  ></td>
     </tr>
     <tr>
      <td> <label for="pwd">COMPUTER EXPERIENCE:</label></td>
       <td><input name="computer" type="text" class="form-control" ></td>
     </tr>
     <tr>
       <td><label for="pwd"> PHONE:</label></td>
       <td><input name="phone" type="number" class="form-control" ></td>
     </tr>
     <tr>
       <td><label for="pwd">RESIDENTIAL ADDRESS:</label></td>
      <td> <textarea class="form-control"  name="address" placeholder="Items" rows="5"></textarea><br></td>

     </div>
     <tr>
      <td> <label for="pwd" >Batches:</label></td>
      <td> <input name="batches" type="text" class="form-control" ></td>
     </tr>
     <tr>
       <td><label for="pwd">Batches1:</label></td>
       <td><input name="batches1" type="text" class="form-control" ></td>
     </div>
     <tr>
       <td><label for="pwd">section:</label></td>
       <td><select name="section" class="form-control">
        <option value="-">No section</option>
        <option value="A">section A</option>
        <option value="B">section B</option>
        <option value="C">section C</option>
        <option value="D">section D</option>
        <option value="E">section E</option>
      </select></td>

    </tr>
    <tr>
    <td> <label for="pwd">price:</label></td>
     <td><input name="price" type="number" class="form-control" ></td>
   </tr>
   <tr>
     <td><label for="pwd">photo:</label></td>
     <td> 
        <select name="photo" class="form-control">
        <option value="-">No chose</option>
        <option value="photo">Yes</option>
        <option value="nophoto">NO</option>
        
      </select>
     </td>
   </tr>
   
</table>
  <button type="submit" class="btn btn-default buttton" >Submit</button>
</form>




</div>
<div class="container">
  <h2 class="headerback">Registration result</h2>
  <!-- <p>Contextual classes can be used to color table rows or table cells. The classes that can be used are: .active, .success, .info, .warning, and .danger.</p> --> <div class="table-responsive"> 
    <table class="table">
      <thead>
        <tr class="whiteforth bgblack">
          <th>id#</th>
          <th>No</th>
          <th>NAME:</th>
          <th>FATHER NAME:</th>
          <th>DATE OF BIRTH:</th>
          <th>NRC NO:</th>
          <th>EDUCATIONAL QUALIFICATION:</th>
          <th>OCCUPATION:</th>
          <th>COMPUTER EXPERIENCE:</th>
          <th>PHONE:</th>
          <th>RESIDENTIAL ADDRESS:</th>
          <th>Batches:</th>
          <th>Batches1:</th>
          <th>section:</th>
          <th>price:</th>
          <th>Photo:</th>
          <th>Edit:</th>
          <th>Delete:</th>
          <th>Read:</th>

        </tr>
      </thead>

      <tbody>
       <?php $x=0;
       while($a = mysqli_fetch_assoc($registermain)){    
        $x=$x + 1;
        ?>

        <tr class="success bgwhite">

         <td><?php echo $a['rid']?></td>
         <td><?php echo $x; ?></td> 
         <td><?php echo $a['name']?></td>
         <td><?php echo $a['fname']?></td>
         <td><?php echo $a['dofb']?></td>
         <td><?php echo $a['nrcno']?></td>
         <td><?php echo $a['edu']?></td>
         <td><?php echo $a['occ']?></td>
         <td><?php echo $a['computer']?></td>
         <td><?php echo $a['phone']?></td>
         <td><?php echo $a['address']?></td>
         <td><?php echo $a['batches']?></td>
         <td><?php echo $a['batches1']?></td>
         <td><?php echo $a['section']?></td>
         <td><?php echo $a['price']?></td>
         <td><?php echo $a['photo']?></td>
         <td>

          <?php 
          $g = '1QwiYiip123Foho';
          if($g == $gi['idname']){
            ?>                  
            <a href="editr.php?rid=<?php echo $a['rid']; ?>" onclick="return confirm('sure to edit ?')"><button class="btn btn-primary" type="button">edit</button></a>
            <?php
          }else{
            ?>  
            <p style="color: red;"> 
              you con't edit
            </p>

            <?php
          }
          ?></td>
          <td>
            <?php 
            $g = '1QwiYiip123Foho';
            if($g == $gi['idname']){
              ?>                  
              <a href="deleter.php?rid=<?php echo $a['rid']; ?>" onclick="return confirm('sure to delete ?')"><button class="btn btn-danger" type="button">Delete</button></a>
              <?php
            }else{
              ?>  
              <p style="color: red;"> 
                you con't delete
              </p>

              <?php
            }
            ?>
          </td>
          <td><a href="print.php?rid=<?php echo $a['rid']; ?>" class="btn btn-info">Read</a></td>

        </tr>
        <?php
      } 
      ?>

    </tbody>


  </table>
</div>
</div>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.3.0/codemirror.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.3.0/mode/xml/xml.min.js"></script>
<script type="text/javascript" src="js/froala_editor.min.js"></script>
<script type="text/javascript" src="js/plugins/align.min.js"></script>
<script type="text/javascript" src="js/plugins/code_beautifier.min.js"></script>
<script type="text/javascript" src="js/plugins/code_view.min.js"></script>
<script type="text/javascript" src="js/plugins/colors.min.js"></script>
<script type="text/javascript" src="js/plugins/draggable.min.js"></script>
<script type="text/javascript" src="js/plugins/emoticons.min.js"></script>
<script type="text/javascript" src="js/plugins/font_size.min.js"></script>
<script type="text/javascript" src="js/plugins/font_family.min.js"></script>
<script type="text/javascript" src="js/plugins/image.min.js"></script>
<script type="text/javascript" src="js/plugins/file.min.js"></script>
<script type="text/javascript" src="js/plugins/image_manager.min.js"></script>
<script type="text/javascript" src="js/plugins/line_breaker.min.js"></script>
<script type="text/javascript" src="js/plugins/link.min.js"></script>
<script type="text/javascript" src="js/plugins/lists.min.js"></script>
<script type="text/javascript" src="js/plugins/paragraph_format.min.js"></script>
<script type="text/javascript" src="js/plugins/paragraph_style.min.js"></script>
<script type="text/javascript" src="js/plugins/video.min.js"></script>
<script type="text/javascript" src="js/plugins/table.min.js"></script>
<script type="text/javascript" src="js/plugins/url.min.js"></script>
<script type="text/javascript" src="js/plugins/entities.min.js"></script>
<script type="text/javascript" src="js/plugins/char_counter.min.js"></script>
<script type="text/javascript" src="js/plugins/inline_style.min.js"></script>
<script type="text/javascript" src="js/plugins/save.min.js"></script>
<script type="text/javascript" src="js/plugins/fullscreen.min.js"></script>
<script type="text/javascript" src="js/plugins/quote.min.js"></script>

<script>
  $(function(){
    $('#edit').froalaEditor({
      theme: 'royal'
    })
  });
</script>
</body>
</html>