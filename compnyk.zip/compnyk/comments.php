

<!-- form -->
<div class="container">
	<div class="cfornews-header">
		အၾကံျပဳစာေရးရန္
	</div>
	<form class="cfornews-form cfornews-formcc slideanim" method="post" id="commentforms">
		<label class="colorsr">အမည္ </label><br>
		
		<input name="cname" type="text" class="form-control" placeholder="Name" required >
		<br>

		<label class="colorsr">အၾကံျပဳ စာ </label><br>
		
		<textarea class="form-control commentss"  name="comment" placeholder="comment here" rows="5" required></textarea><br>
		<br>
		<button type="submit">ေပးပို႔မည္ <span class="glyphicon glyphicon-new-window"></button>
		</form>
	</div>

	<!-- form end -->
	<!-- show reset -->
	<div class="container">
		<h2>အၾကံျပဳစာမ်ား</h2>
		
		<!-- to edit and remove messages -->
		<?php 
		while($a = mysqli_fetch_assoc($res_admin)){    
			?>
			<div class="panel panel-info slideanim" >
				<div class="panel-heading"><?php echo $a['cname']?></div>
				<div class="panel-body"><?php echo $a['comment']?></div>
				<div class="panel-body" style="color: gray;">reply :<br> <br><?php echo $a['reply']?>
				
			</div>        
		</div>
		<?php 
	}
	?>
</div>