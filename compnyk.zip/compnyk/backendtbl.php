<?php
require_once('database.php');
$register = $database->read();
$registera = $database->read();
$registerb = $database->read();
$registerc = $database->read();
$registerd = $database->read();
$registert = $database->read();
$registere = $database->read();
session_start();

$database = new Database(); $id = $_SESSION['id'];
$gi = $database->get_fullname($id);
if (!$database->get_session()){
	header("location:login.php");
}


?>
<!DOCTYPE html>
<html>
<head>
	<title>backend</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="css/backend.css">
	<script>
		$(document).ready(function(){
			$("#slideshow").hide(0000);
			$("#slidebtn").click(function(){
				$("#slideshow").slideToggle(800);
			});
		});

		function sure(){
			confirm("Are you sure?");
		}
	</script>
</head>
<body>
	
	<?php include 'backendmods.php'; ?>
	<div class="container paddingch" >
		<h2 class="headerback">Registered Table </h2>
		            
		<table class="table table-dark">
			<thead>
				<tr class="bgblack">
					<th>no#</th>
					<th>id#</th>
					<th>student name</th>
					<th>Section</th>
					<th>Phone</th>
					<th>Batches</th>
					<th>price</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				$x=0;
				while($a = mysqli_fetch_assoc($register)){  
				$x=$x + 1;   
                 
					?>
					<tr class="success bgwhite">
						<td><?php echo $x; ?></td>
						<td><?php echo $a['rid']?></td>
						<td><?php echo $a['name']?></td>
						<td><?php echo $a['section']?></td>       
						<td><?php echo $a['phone']?></td>       
						<td><?php echo $a['batches']?></td>
						<td><?php echo $a['price']?></td>
						<td><?php 
												$g = '1QwiYiip123Foho';
												if($g == $gi['idname']){
													?>									
													<a href="editra.php?rid=<?php echo $a['rid']; ?>" onclick="return confirm('sure to edit ?')"><button onclick="sure()" class="btn btn-primary" type="button">edit</button></a>
													<?php
												}else{
													?>	
													<p style="color: red;">	
														you con't edit
													</p>
												
												<?php
											}
											?>	</td>
						<td><?php 
												$g = '1QwiYiip123Foho';
												if($g == $gi['idname']){
													?>									
													<a href="deletera.php?rid=<?php echo $a['rid']; ?>" onclick="return confirm('sure to edit ?')"><button class="btn btn-danger" type="button">Delete</button></a>
													<?php
												}else{
													?>	
													<p style="color: red;">	
														you con't delete
													</p>
												
												<?php
											}
											?></td>

					</tr>
					<?php 
				}
				?>
			</tbody>
		</table>
	</div>
	<?php
	if(isset($registert)){

		$total_pricet = 0;
		?>
		<div class="row zindex">
			<div class="col-sm-6">

				<?php
				if(isset($registera)){

					$total_price = 0;
					?>	
					<div class="table-responsive" style="margin-top: 20px;  padding: 10px;"> 
						<h2 class="headerback">Section A </h2>
						<table class="table table-bordered">
							<thead>
								<tr class="whiteforth bgblack">
									<th class="table-success">Photo</th>
									<th class="table-success">student name:</th>
									<th class="table-success">Money</th>
									<th class="table-success">edit</th>
									<th class="table-success">Delete</th>
								</tr>
							</thead>

							<tbody>
								<?php 
									
								while($k = mysqli_fetch_assoc($registera)){ 
									
									
									$d = 'A';
									while($d == $k['section']){	
										
										
											
										

										?>

										<tr class="success  bgwhite">
											
											<td class="table-success"><?php echo $k['photo']?></td>

											<td class="table-success"><?php echo $k['name']?></td>
											<td class="table-success"><?php echo $k['price']?></td>
											<td><?php 
												$g = '1QwiYiip123Foho';
												if($g == $gi['idname']){
													?>									
													<a href="editra.php?rid=<?php echo $k['rid']; ?>" onclick="return confirm('sure to edit ?')"><button class="btn btn-primary" type="button">edit</button></a>
													<?php
												}else{
													?>	
													<p style="color: red;">	
														you con't edit
													</p>
												</td>
												<?php
											}
											?>	</td>
											<td><?php 
												$g = '1QwiYiip123Foho';
												if($g == $gi['idname']){
													?>									
													<a href="deletera.php?rid=<?php echo $k['rid']; ?>" onclick="return confirm('sure to edit ?')"><button class="btn btn-danger" type="button">Delete</button></a>
													<?php
												}else{
													?>	
													<p style="color: red;">	
														you con't delete
													</p>
												</td>
												<?php
											}
											?></td>
										</tr>

										<?php 
										
										
									
									$total_price += $k['price'];
										$d++;
									}
								}
								?>

							</tbody>
							<tfoot>
								<tr class="bgblack">
									<th>
										<a href="sectiona.php"><button class="btn btn-info" type="button">Row sheep</button>
										</a>
									</th>
									<th>total</th>
									<th><?php echo $total_price; ?> -MMK</th>
								</tr>
							</tfoot>
							

						</table>


					</div>
					<?php
				} 
				?>
			</div>
			<div class="col-sm-6">
				<?php
				if(isset($registerb)){

					$total_priceb = 0;
					?>	
					<div class="table-responsive" style="margin-top: 20px;  padding: 10px;"> 
						<h2 class="headerback">Section B </h2>
						<table class="table table-bordered">
							<thead>
								<tr class="whiteforth bgblack">
									<th class="table-info">Photo</th>
									<th class="table-info">student name:</th>
									<th class="table-info">Money</th>
									<th class="table-info">edit</th>
									<th class="table-info">Delete</th>
								</tr>
							</thead>

							<tbody>
								<?php 
								while($kb = mysqli_fetch_assoc($registerb)){ 

									$d = 'B';
									while($d == $kb['section']){				


										?>

										<tr class="info bgwhite">
											<td class="table-info"><?php echo $kb['photo']?></td>

											<td class="table-info"><?php echo $kb['name']?></td>
											<td class="table-info"><?php echo $kb['price']?></td>
											<td><?php 
												$g = '1QwiYiip123Foho';
												if($g == $gi['idname']){
													?>									
													<a href="editra.php?rid=<?php echo $kb['rid']; ?>" onclick="return confirm('sure to edit ?')"><button class="btn btn-primary" type="button">edit</button></a>
													<?php
												}else{
													?>	
													<p style="color: red;">	
														you con't edit
													</p>
												</td>
												<?php
											}
											?>	</td>
											<td><?php 
												$g = '1QwiYiip123Foho';
												if($g == $gi['idname']){
													?>									
													<a href="deletera.php?rid=<?php echo $kb['rid']; ?>" onclick="return confirm('sure to delete ?')"><button class="btn btn-danger" type="button">Delete</button></a>
													<?php
												}else{
													?>	
													<p style="color: red;">	
														you con't delete
													</p>
												</td>
												<?php
											}
											?></td>
										</tr>

										<?php 
										$total_priceb += $kb['price'];
										$d++;

									}
								}
								?>

							</tbody>
							<tfoot>
								<tr class="bgblack">
									<th>
										<a href="sectionb.php"><button class="btn btn-info" type="button">Row sheep</button>
										</a>
									</th>
									<th>total</th>
									<th><?php echo $total_priceb; ?> -MMK</th>
								</tr>
							</tfoot>

						</table>


					</div>
					<?php
				} 
				?>
			</div>
		</div>
		<div class="row zindex">
			<div class="col-sm-6">
				<?php
				if(isset($registerc)){

					$total_pricec = 0;
					?>	
					<div class="table-responsive" style="margin-top: 20px;  padding: 10px;"> 
						<h2 class="headerback">Section C </h2>
						<table class="table table-bordered">
							<thead>
								<tr class="whiteforth bgblack">
									<th class="table-danger">Photo</th>
									<th class="table-danger">student name:</th>
									<th class="table-danger">Money</th>
									<th class="table-danger">edit</th>
									<th class="table-danger">Delete</th>
								</tr>
							</thead>

							<tbody>
								<?php 
								while($kc = mysqli_fetch_assoc($registerc)){ 

									$d = 'C';
									while($d == $kc['section']){				


										?>

										<tr class="danger bgwhite">
											<td class="table-danger"><?php echo $kc['photo']?></td>

											<td class="table-danger"><?php echo $kc['name']?></td>
											<td class="table-danger"><?php echo $kc['price']?></td>
											<td>
												<?php 
												$g = '1QwiYiip123Foho';
												if($g == $gi['idname']){
													?>									
													<a href="editra.php?rid=<?php echo $kc['rid']; ?>" onclick="return confirm('sure to edit ?')"><button class="btn btn-primary" type="button">edit</button></a>
													<?php
												}else{
													?>	
													<p style="color: red;">	
														you con't edit
													</p>
												
												<?php
											}
											?>	

										</td>
										<td>
											
											<?php 
												$g = '1QwiYiip123Foho';
												if($g == $gi['idname']){
													?>									
													<a href="deletera.php?rid=<?php echo $kc['rid']; ?>" onclick="return confirm('sure to delete ?')"><button class="btn btn-danger" type="button">Delete</button></a>
													<?php
												}else{
													?>	
													<p style="color: red;">	
														you con't delete
													</p>
												
												<?php
											}
											?>

										</td>
									</tr>

									<?php 
									$total_pricec += $kc['price'];
									$d++;

								}
							}
							?>

						</tbody>
						<tfoot>
							<tr class="bgblack">
								<th>
									<a href="sectionc.php"><button class="btn btn-info" type="button">Row sheep</button>
										</a>
								</th>
								<th>total</th>
								<th><?php echo $total_pricec; ?> -MMK</th>
							</tr>
						</tfoot>

					</table>


				</div>
				<?php
			} 
			?>
		</div>
		<div class="col-sm-6">
			<?php
			if(isset($registerd)){

				$total_priced = 0;
				?>	
				<div class="table-responsive" style="margin-top: 20px; padding: 10px;"> 
					<h2 class="headerback">Section D </h2>
					<table class="table table-bordered">
						<thead>
							<tr class="whiteforth bgblack">
								<th class="table-warning">Photo</th>
								<th class="table-warning">student name:</th>
								<th class="table-warning">Money</th>
								<th class="table-warning">edit</th>
								<th class="table-warning">Delete</th>
							</tr>
						</thead>

						<tbody>
							<?php 
							while($kd = mysqli_fetch_assoc($registerd)){ 

								$d = 'D';
								while($d == $kd['section']){				


									?>

									<tr class="warning bgwhite">
										<td class="table-warning"><?php echo $kd['photo']?></td>

										<td class="table-warning"><?php echo $kd['name']?></td>
										<td class="table-warning"><?php echo $kd['price']?></td>
										<td><?php 
												$g = '1QwiYiip123Foho';
												if($g == $gi['idname']){
													?>									
													<a href="editra.php?rid=<?php echo $kd['rid']; ?>" onclick="return confirm('sure to edit ?')"><button class="btn btn-primary" type="button">edit</button></a>
													<?php
												}else{
													?>	
													<p style="color: red;">	
														you con't edit
													</p>
												
												<?php
											}
											?>	</td>
										<td><?php 
												$g = '1QwiYiip123Foho';
												if($g == $gi['idname']){
													?>									
													<a href="deletera.php?rid=<?php echo $kd['rid']; ?>" onclick="return confirm('sure to delete ?')"><button class="btn btn-danger" type="button">Delete</button></a>
													<?php
												}else{
													?>	
													<p style="color: red;">	
														you con't delete
													</p>
												
												<?php
											}
											?></td>
									</tr>

									<?php 
									$total_priced += $kd['price'];
									$d++;

								}
							}
							?>

						</tbody>
						<tfoot>
							<tr class="bgblack">
								<th>
									<a href="sectiond.php"><button class="btn btn-info" type="button">Row sheep</button>
										</a>
								</th>
								<th>total</th>
								<th><?php echo $total_priced; ?> -MMK</th>
							</tr>
						</tfoot>

					</table>


				</div>
				<?php
				$total_pricet += ($total_price+$total_priceb+$total_pricec+$total_priced);
			} 
			?>
		</div>
	</div>
		<div class="row zindex">
			<div class="col-sm-6">
				<?php
			if(isset($registerd)){

				$total_pricee = 0;
				?>	
				<div class="table-responsive" style="margin-top: 20px; padding: 10px;"> 
					<h2 class="headerback">Section E </h2>
					<table class="table table-bordered">
						<thead>
							<tr class="whiteforth bgblack">
								<th class="table-warning">Photo</th>
								<th class="table-warning">student name:</th>
								<th class="table-warning">Money</th>
								<th class="table-warning">edit</th>
								<th class="table-warning">Delete</th>
							</tr>
						</thead>

						<tbody>
							<?php 
							while($kds = mysqli_fetch_assoc($registere)){ 

								$ds = 'E';
								while($ds == $kds['section']){				


									?>

									<tr class="warning bgwhite">
										<td class="table-warning"><?php echo $kds['photo']?></td>

										<td class="table-warning"><?php echo $kds['name']?></td>
										<td class="table-warning"><?php echo $kds['price']?></td>
										<td><?php 
												$g = '1QwiYiip123Foho';
												if($g == $gi['idname']){
													?>									
													<a href="editra.php?rid=<?php echo $kds['rid']; ?>" onclick="return confirm('sure to edit ?')"><button class="btn btn-primary" type="button">edit</button></a>
													<?php
												}else{
													?>	
													<p style="color: red;">	
														you con't edit
													</p>
												
												<?php
											}
											?>	</td>
										<td><?php 
												$g = '1QwiYiip123Foho';
												if($g == $gi['idname']){
													?>									
													<a href="deletera.php?rid=<?php echo $kds['rid']; ?>" onclick="return confirm('sure to delete ?')"><button class="btn btn-danger" type="button">Delete</button></a>
													<?php
												}else{
													?>	
													<p style="color: red;">	
														you con't delete
													</p>
												
												<?php
											}
											?></td>
									</tr>

									<?php 
									$total_pricee += $kds['price'];
									$ds++;

								}
							}
							?>

						</tbody>
						<tfoot>
							<tr class="bgblack">
								<th>
									<a href="sectione.php"><button class="btn btn-info" type="button">Row sheep</button>
										</a>
								</th>
								<th>total</th>
								<th><?php echo $total_pricee; ?> -MMK</th>
							</tr>
						</tfoot>

					</table>


				</div>
				<?php
				$total_pricet = ($total_price+$total_priceb+$total_pricec+$total_priced+$total_pricee);
			} 
			?>
			</div>
		</div>
	<div style="width: 500px;height: 300px; display: block;margin-left: auto; margin-right: auto;">


		<table class="table table-bordered">
			<thead>
				<tr class="bgblack">
					<th>section</th>
					<th>money</th>
				</tr>
			</thead>
			<tbody>
				<tr class="bgwhite">
					<td>A</td>
					<td><?php echo $total_price; ?></td>
				</tr>
				<tr class="bgwhite">
					<td>B</td>
					<td><?php echo $total_priceb; ?></td>
				</tr>
				<tr class="bgwhite">
					<td>C</td>
					<td><?php echo $total_pricec; ?></td>
				</tr>
				<tr class="bgwhite">
					<td>D</td>
					<td><?php echo $total_priced; ?></td>
				</tr>
				<tr class="bgwhite">
					<td>E</td>
					<td><?php echo $total_pricee; ?></td>
				</tr>
			</tbody>
			<tfoot>
				<tr class="bgblack">
					<th>Total</th>
					<th><?php echo "$ ".number_format($total_pricet, 2); ?> -MMK</th>

				</tr>
			</tfoot>
		</table></div>

		<?php
	} 
	?>
</body>
</html>