<!-- model for subjects -->
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Microsoft offic</h4>
        </div>
        <div class="modal-body">
          <div class="subjects-images-one basic">
            <img src="pics/basic.jpg" class="img-responsive" alt="Cinque Terre" width="100%" height="213px">
          </div>
          <div class="detailforcenter">
            Microsoft Offic Word, MS Excel, Ms Powerpoint
          </div>
          <div class="prizeformycenter">
            <span class="glyphicon glyphicon-usd"></span>&nbsp;&nbsp;သင္တန္းေၾကး - ၂၀၀၀၀ က်ပ္ 
          </div>
          <div class="photoformycenter">
            <span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;ဓာတ္ပံု (၂) ပံု
          </div>
          <div class="lengthformycenter">
            <span class="glyphicon glyphicon-hourglass"></span>&nbsp;&nbsp;သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ
          </div>          

        </div>
        <div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more" data-dismiss="modal">
    Close
    <span class="glyphicon glyphicon-remove-sign"></span>
    </div>
  

</div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>




  <!-- two -->
<div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">DTP</h4>
        </div>
        <div class="modal-body">
          <div class="subjects-images-one basic">
            <img src="pics/dtp.jpg" class="img-responsive" alt="Cinque Terre" width="100%" height="213px">
          </div>
          <div class="detailforcenter">
           Adobe PageMaker, CorelDraw, MS Publisher]
          </div>
          <div class="prizeformycenter">
            <span class="glyphicon glyphicon-usd"></span>&nbsp;&nbsp;သင္တန္းေၾကး - ၂၀၀၀၀ က်ပ္ 
          </div>
          <div class="photoformycenter">
            <span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;ဓာတ္ပံု (၂) ပံု
          </div>
          <div class="lengthformycenter">
            <span class="glyphicon glyphicon-hourglass"></span>&nbsp;&nbsp;သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ
          </div>          

        </div>
        <div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more" data-dismiss="modal">
    Close
    <span class="glyphicon glyphicon-remove-sign"></span>
    </div>
  

</div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>





  <!-- 3 -->
<div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Graphic Design</h4>
        </div>
        <div class="modal-body">
          <div class="subjects-images-one basic">
            <img src="pics/ds.jpg" class="img-responsive" alt="Cinque Terre" width="100%" height="213px">
          </div>
          <div class="detailforcenter">
            Photoshop , Illustrator, Indesign
          </div>
          <div class="prizeformycenter">
            <span class="glyphicon glyphicon-usd"></span>&nbsp;&nbsp;သင္တန္းေၾကး - ၂၀၀၀၀ က်ပ္ 
          </div>
          <div class="photoformycenter">
            <span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;ဓာတ္ပံု (၂) ပံု
          </div>
          <div class="lengthformycenter">
            <span class="glyphicon glyphicon-hourglass"></span>&nbsp;&nbsp;သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ
          </div>          

        </div>
        <div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more" data-dismiss="modal">
    Close
    <span class="glyphicon glyphicon-remove-sign"></span>
    </div>
  

</div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>




<!-- ၃+ -->
<div class="modal fade" id="myModal31" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Advance Graphic Design</h4>
        </div>
        <div class="modal-body">
          <div class="subjects-images-one basic">
            <img src="pics/ds.jpg" class="img-responsive" alt="Cinque Terre" width="100%" height="213px">
          </div>
          <div class="detailforcenter">
            Photoshop , Illustrator, Indesign
          </div>
          <div class="prizeformycenter">
            <span class="glyphicon glyphicon-usd"></span>&nbsp;&nbsp;သင္တန္းေၾကး - ၄၀၀၀၀ က်ပ္ 
          </div>
          <div class="photoformycenter">
            <span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;ဓာတ္ပံု (၂) ပံု
          </div>
          <div class="lengthformycenter">
            <span class="glyphicon glyphicon-hourglass"></span>&nbsp;&nbsp;သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၄)လ
          </div>          

        </div>
        <div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more" data-dismiss="modal">
    Close
    <span class="glyphicon glyphicon-remove-sign"></span>
    </div>
  

</div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>






  <!-- 4 -->
<div class="modal fade" id="myModal4" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Pratical A+ and Networking Basic</h4>
        </div>
        <div class="modal-body">
          <div class="subjects-images-one basic">
            <img src="pics/a.jpg" class="img-responsive" alt="Cinque Terre" width="100%" height="213px">
          </div>
          <div class="detailforcenter">
           
          </div>
          <div class="prizeformycenter">
            <span class="glyphicon glyphicon-usd"></span>&nbsp;&nbsp;သင္တန္းေၾကး - ၄၀၀၀၀ က်ပ္ 
          </div>
          <div class="photoformycenter">
            <span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;ဓာတ္ပံု (၂) ပံု
          </div>
          <div class="lengthformycenter">
            <span class="glyphicon glyphicon-hourglass"></span>&nbsp;&nbsp;သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ
          </div>          

        </div>
        <div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more" data-dismiss="modal">
    Close
    <span class="glyphicon glyphicon-remove-sign"></span>
    </div>
  

</div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>







  <!-- 5 -->
  <div class="modal fade" id="myModal5" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Video EditingVideo Editing</h4>
        </div>
        <div class="modal-body">
          <div class="subjects-images-one basic">
            <img src="pics/vd.jpg" class="img-responsive" alt="Cinque Terre" width="100%" height="213px">
          </div>
          <div class="detailforcenter">
            Adobe Premier, Sony Acid Pro, Window Movie Maker, Pinnacle Studio, Virtual DJ, Cyberlink Power Director, Format Factory, Nero and etc . . . . .
          </div>
          <div class="prizeformycenter">
            <span class="glyphicon glyphicon-usd"></span>&nbsp;&nbsp;သင္တန္းေၾကး - ၄၀၀၀၀ က်ပ္ 
          </div>
          <div class="photoformycenter">
            <span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;ဓာတ္ပံု (၂) ပံု
          </div>
          <div class="lengthformycenter">
            <span class="glyphicon glyphicon-hourglass"></span>&nbsp;&nbsp;သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ
          </div>          

        </div>
        <div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more" data-dismiss="modal">
    Close
    <span class="glyphicon glyphicon-remove-sign"></span>
    </div>
  

</div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>






  <!-- 6 -->
<div class="modal fade" id="myModal6" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Website Design</h4>
        </div>
        <div class="modal-body">
          <div class="subjects-images-one basic">
            <img src="pics/wd.jpg" class="img-responsive" alt="Cinque Terre" width="100%" height="213px">
          </div>
          <div class="detailforcenter">
            Front End][HTML 5 ,CSS 3, Javascript, JQuery, Bootstrap
          </div>
          <div class="prizeformycenter">
            <span class="glyphicon glyphicon-usd"></span>&nbsp;&nbsp;သင္တန္းေၾကး - ၆၀၀၀၀ က်ပ္ 
          </div>
          <div class="photoformycenter">
            <span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;ဓာတ္ပံု (၂) ပံု
          </div>
          <div class="lengthformycenter">
            <span class="glyphicon glyphicon-hourglass"></span>&nbsp;&nbsp;သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၄)လ
          </div>  
          <div class="photoformycenter">
            <span class="glyphicon glyphicon-info-sign"></span>&nbsp;လ (ကိုပိုင္ laptop ယူလာ လ်ွင္ပို ေကာင္းပါသည္။)
          </div>        

        </div>
        <div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more" data-dismiss="modal">
    Close
    <span class="glyphicon glyphicon-remove-sign"></span>
    </div>
  

</div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>









  <!-- 7 -->
<div class="modal fade" id="myModal7" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Website Developing</h4>
        </div>
        <div class="modal-body">
          <div class="subjects-images-one basic">
            <img src="pics/wdeve.jpg" class="img-responsive" alt="Cinque Terre" width="100%" height="213px">
          </div>
          <div class="detailforcenter">
            Backend End][PHP +MySQL, CMS [Wordpress, Drupal], CodeIgnitor with many project tutorials
          </div>
          <div class="prizeformycenter">
            <span class="glyphicon glyphicon-usd"></span>&nbsp;&nbsp;သင္တန္းေၾကး - ၁၅၀၀၀၀ က်ပ္ 
          </div>
          <div class="photoformycenter">
            <span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;ဓာတ္ပံု (၂) ပံု
          </div>
          <div class="lengthformycenter">
            <span class="glyphicon glyphicon-hourglass"></span>&nbsp;&nbsp;သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၄)လ
          </div> 
          <div class="photoformycenter">
            <span class="glyphicon glyphicon-info-sign"></span>&nbsp;&nbsp; (ကိုပိုင္ laptop ယူလာရမည္။)
          </div>         

        </div>
        <div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more" data-dismiss="modal">
    Close
    <span class="glyphicon glyphicon-remove-sign"></span>
    </div>
  

</div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>







  <!-- 8 -->
<div class="modal fade" id="myModal8" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Website Developing</h4>
        </div>
        <div class="modal-body">
          <div class="subjects-images-one basic">
            <img src="pics/la.jpg" class="img-responsive" alt="Cinque Terre" width="100%" height="213px">
          </div>
          <div class="detailforcenter">
            Laravel Framework
          </div>
          <div class="prizeformycenter">
            <span class="glyphicon glyphicon-usd"></span>&nbsp;&nbsp;သင္တန္းေၾကး - ၁၅၀၀၀၀ က်ပ္ 
          </div>
          <div class="photoformycenter">
            <span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;ဓာတ္ပံု (၂) ပံု
          </div>
          <div class="lengthformycenter">
            <span class="glyphicon glyphicon-hourglass"></span>&nbsp;&nbsp;သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ
          </div>  
          <div class="photoformycenter">
            <span class="glyphicon glyphicon-info-sign"></span>&nbsp;&nbsp; (ကိုပိုင္ laptop ယူလာရမည္။)
          </div>         

        </div>
        <div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more" data-dismiss="modal">
    Close
    <span class="glyphicon glyphicon-remove-sign"></span>
    </div>
  

</div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
  <!-- 9 -->
  <div class="modal fade" id="myModal9" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">HR / Admin Basic Course</h4>
        </div>
        <div class="modal-body">
          <div class="subjects-images-one basic">
            <img src="pics/hr.jpg" class="img-responsive" alt="Cinque Terre" width="100%" height="213px">
          </div>
          <div class="detailforcenter">
            Microsoft offic word, MS Excel, Ms Powerpoint
          </div>
          <div class="prizeformycenter">
            <span class="glyphicon glyphicon-usd"></span>&nbsp;&nbsp;သင္တန္းေၾကး - ၄၀၀၀၀ က်ပ္ 
          </div>
          <div class="photoformycenter">
            <span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;ဓာတ္ပံု (၂) ပံု
          </div>
          <div class="lengthformycenter">
            <span class="glyphicon glyphicon-hourglass"></span>&nbsp;&nbsp;သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ
          </div>   
          <div class="photoformycenter">
            <span class="glyphicon glyphicon-info-sign"></span>&nbsp;&nbsp; (ဆယ္တန္း ေအာင္ျမင္ျပီး သူမ်ားသာ။)
          </div>        

        </div>
        <div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more" data-dismiss="modal">
    Close
    <span class="glyphicon glyphicon-remove-sign"></span>
    </div>
  

</div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>
