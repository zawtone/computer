<?php
$name = $_FILES["uploads"]["name"];
$tmp = $_FILES["uploads"]["tmp_name"];
$type = $_FILES["uploads"]["type"];
if($type == "image/jpeg" || $type == "image/png" || $type == "image/gif") {
move_uploaded_file($tmp, "uploads/$name");
}
header("location: uploadimg.php");
?>