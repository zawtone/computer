

<?php
 require_once('database.php');
 $rid = $_GET['rid'];
 $ed = $database->read($rid);
 $e = mysqli_fetch_assoc($ed);
 if(isset($_POST) & !empty($_POST)){
     $name = $database->sanitize($_POST['name']);
     $fname = $database->sanitize($_POST['fname']);
     $dofb = $database->sanitize($_POST['dofb']);
     $nrcno = $database->sanitize($_POST['nrcno']);
     $edu = $database->sanitize($_POST['edu']);
     $occ = $database->sanitize($_POST['occ']);
     $computer = $database->sanitize($_POST['computer']);
     $phone = $database->sanitize($_POST['phone']);
     $address = $database->sanitize($_POST['address']);
     $batches = $database->sanitize($_POST['batches']);
     $batches1 = $database->sanitize($_POST['batches1']);
     $section = $database->sanitize($_POST['section']);
     $price = $database->sanitize($_POST['price']);
     $photo = $database->sanitize($_POST['photo']);
     
    $ress = $database->update($name,$fname,$dofb,$nrcno,$edu,$occ,$computer,$phone,$address,$batches,$batches1,$section,$price,$photo, $rid);
    if($ress){
        header("location:backendr.php");
    }else{
        echo "failed to update data";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>
		sms admin
	</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/selete.js"></script>
	<script>
		function cho(){
		var a=document.getElementById('choose').value;
		document.getElementById('responed').value= ""+a;

}
	</script>
	<style type="text/css">
		.navbarfor-new{
	border-radius: 0px !important;
}
body {
 background-color: #5A5959;
	background-size: cover;
	background-position: top;
}
/*==*/
	.whole1{
			width: 250px;
			height: 50px;
			background-color: #00F;
			display: flex;	
			opacity: 0.5;
		}
		.inner-back1{
			width: 240px;
			height: 40px;
			margin-top: 5px;
			margin-left: 5px;
			background-color: white;
		}
		.inner-one1{
			width: 230px;
			height: 30px;
			margin-top: 5px;
			margin-left: 5px;
			background-color: blue;
		}
		.logo{
			width: 230px;
			height: 30px;
			font-size: 28px;
			padding-top: 7px;
			text-align: center;
			color: white;
			text-shadow: 1px 1px 3px black;
			position: relative;
			font-family: Algerian;
			margin-top: -42px;
		}

/*==*/
.data-back{
	width: 125px;
	height: 30px;
	border-radius: 15px;
	border: 3px solid #C9C9C9;
	color: white;
	text-align: center;
	box-shadow: 1px 1px 3px #C9C9C9;
}
.data-back:hover{
	background-color: #E1DADA;
	text-decoration: none;
	color: #6C6969;
}


.row-new{
	margin-right: 0px !important;
	margin-left: 0px !important;
}
.navbar-inverse{
	background-color: transparent;
	border: 0px !important;
}
.form-footer{
	width: 100%;
	height: auto;
	float: right;
	box-shadow: 1px 1px 6px black;
	border-left: 5px solid white;
}
.undefine li{
	list-style: none;
	margin-top: 20px;
}
.undefine {
	margin-left: -25px !important;
}
.form-footer h1{
	color: #E7E4E4;
}
label{
	color: #E7E4E4;
}
.drop{
	background-color: transparent !important;
}
.action:hover{
	background-color: transparent !important;
}
.action:focus{
	background-color: transparent !important;
}

.logins{
	margin-top: 10px !important;
}
.drop li a{
	color: #E7E4E4;
}
.buttton{
	opacity: 0.8;
	width: 100px;
	margin-bottom: 30px;
}
.data-link{
	color: white !important;
}
.data-link:hover{
	color: blue !important;
	text-decoration: none;
}
.navbar-brand{
	padding: 0px !important;
}
	</style>
	
</head>
<body>


	<div class="col-sm-8 tab-content">
		<div class="container form-footer tab-pane fade in active" id="home">
			<h1>Student Registeration !</h1>
			<form role="form" method="post">
			    <div class="form-group">
			      <label for="email">NAME:</label>
			      <input name="name" type="text" class="form-control" value="<?php echo $e['name'] ?>" >
			    </div>
			    <div class="form-group">
			      <label for="pwd">FATHER NAME:</label>
			      <input name="fname" type="text" class="form-control" value="<?php echo $e['fname'] ?>">
			    </div>
			    <div class="form-group">
			      <label for="pwd">DATE OF BIRTH:</label>
			      <input name="dofb" type="number" class="form-control" value="<?php echo $e['dofb'] ?>">
			    </div>
			    <div class="form-group">
			      <label for="pwd">NRC NO:</label>
			      <input name="nrcno" type="text" class="form-control" value="<?php echo $e['nrcno'] ?>">
			    </div>
			    <div class="form-group">
			      <label for="pwd">EDUCATIONAL QUALIFICATION:</label>
			      <input name="edu" type="text" class="form-control"  value="<?php echo $e['edu'] ?>">
			    </div>
			    <div class="form-group">
			      <label for="pwd">OCCUPATION:</label>
			      <input name="occ" type="text" class="form-control"  value="<?php echo $e['occ'] ?>">
			    </div>
			    <div class="form-group">
			      <label for="pwd">COMPUTER EXPERIENCE:</label>
			      <input name="computer" type="text" class="form-control" value="<?php echo $e['computer'] ?>">
			    </div>
			    <div class="form-group">
			      <label for="pwd"> PHONE:</label>
			      <input name="phone" type="number" class="form-control" value="<?php echo $e['phone'] ?>">
			    </div>
				<div class="form-group">
			      <label for="pwd">RESIDENTIAL ADDRESS:</label>
			      <textarea class="form-control" id="comments" name="exitem"  rows="5"><?php echo $e['address'] ?></textarea><br>
			    </div>
			    <div class="form-group">
			      <label for="pwd">Batches:</label>
			      <input name="batches" type="text" class="form-control" value="<?php echo $e['batches'] ?>">
			    </div>
			    <div class="form-group">
			      <label for="pwd">Batches1:</label>
			      <input name="batches1" type="text" class="form-control" value="<?php echo $e['batches1'] ?>">
			    <div class="form-group">
			      <label for="pwd">section:</label>
			      <input type="text" name="section" id="responed" value="<?php echo $e['section'] ?>" >
			      <select  class="form-control" id="choose" onchange="cho()">
						<option value="<?php echo $e['section'] ?>">section <?php echo $e['section'] ?></option>
						<option value="-"> no section</option>
						<option value="A">section A</option>
						<option value="B">section B</option>
						<option value="C">section C</option>
						<option value="D">section D</option>
						<option value="E">section E</option>
					</select>
					
			    </div>
			    <div class="form-group">
			      <label for="pwd">price:</label>
			      <input name="price" type="number" class="form-control" value="<?php echo $e['price'] ?>">
			    </div>
			    	<div class="form-group">
			      <label for="pwd">photo:</label>
			      <select name="photo" class="form-control">
			<option value="<?php echo $e['photo'] ?>"><?php echo $e['photo'] ?></option>      	
	        <option value="-">No section</option>
	        <option value="Yes">Yes</option>
	        <option value="No">NO</option>
	        
	      </select>
			    </div>
				
			    
			    <button type="submit" class="btn btn-primary buttton" >Submit</button>
			</form>
		</div>

		
  
</div>

</body>
</html>