<?php
require_once('database.php');

$news = $database->newsread();


?>
<div class="header_news header_news-link slide">
<p>သတင္းမ်ား</p>
</div>

               

<div class="whole-news-content">
<?php 
                    while($a = mysqli_fetch_assoc($news)){    
                ?>
<!-- mini news -->

<script type="text/javascript">
  $(document).ready(function(){
      $(".news-model<?php echo $a['modid']?> ").hide(0000);
    $(".new-show-battem-link<?php echo $a['neid']?>").click(function(){
        $(".news-model<?php echo $a['modid']?> ").toggle("slow");
    });
});
</script>

<div class="boxnews slideanim" >
  
<div class="imgnews">
<div class="newslast-update" style="<?php echo $a['newmod']?> !important;">
  <div class="newslast-updates">
    
  </div>
   <p>
     New
   </p>
  </div>
  <img src="<?php echo $a['test']?>" width="220px" height="198px"></div>

<div class="textnews">
<h6><?php echo $a['dfn']?></h6>

<p><?php echo $a['mini']?></p>
</div>
<div class="button_read_C">
  <a href="http://localhost/compnyk/comment.php">
    <div class="rebotton-for-com">
      အၾကံျပဳစာေရးရန္
      <span class="glyphicon glyphicon-pencil"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more1 new-show-battem-link<?php echo $a['neid']?>">
    More detail <span class="glyphicon glyphicon-forward"></span>
    </div>
  

</div>
</div>
<!-- fool model -->
<div class="news-model<?php echo $a['modid']?> news-modelshow">
 <div class="news-model-text">
   <?php echo $a['whole']?>
 </div>

  <div class="container">
  <h2>Image Gallery</h2>
            
  <div class="row">
    <div class="col-md-4">
      <a href="<?php echo $a['onep']?>" class="thumbnail thumbnailcn">
        <p> <?php echo $a['onet']?></p>    
        <img src="<?php echo $a['onep']?>" alt="Pulpit Rock" style="width:100%;height:auto">
      </a>
    </div>
    <div class="col-md-4">
      <a href="<?php echo $a['twop']?>" class="thumbnail thumbnailcn">
        <p> <?php echo $a['twot']?></p>
        <img src="<?php echo $a['twop']?>" alt="Moustiers Sainte Marie" style="width:100%;height:auto">
      </a>
    </div>
    <div class="col-md-4">
      <a href="<?php echo $a['threep']?>" class="thumbnail thumbnailcn">
        <p> <?php echo $a['threet']?></p>      
        <img src="<?php echo $a['threep']?>" alt="Cinque Terre" style="width:100%;height:auto">
      </a>
    </div>
  </div>
  <div class="row">
    <div class="col-md-4">
      <a href="<?php echo $a['fourp']?>" class="thumbnail thumbnailcn">
        <p> <?php echo $a['fourt']?></p>    
        <img src="<?php echo $a['fourp']?>" alt="Pulpit Rock" style="width:100%;height:auto">
      </a>
    </div>
    <div class="col-md-4">
      <a href="<?php echo $a['fivep']?>" class="thumbnail thumbnailcn">
        <p> <?php echo $a['fivet']?></p>
        <img src="<?php echo $a['fivep']?>" alt="Moustiers Sainte Marie" style="width:100%;height:auto">
      </a>
    </div>
    <div class="col-md-4">
      <a href="<?php echo $a['sixp']?>" class="thumbnail thumbnailcn">
        <p> <?php echo $a['sixt']?></p>      
        <img src="<?php echo $a['sixp']?>" alt="Cinque Terre" style="width:100%;height:auto">
      </a>
    </div>
  </div>
</div>
</div>
</div>
<?php 
                      }
                  ?>


<!-- end -->