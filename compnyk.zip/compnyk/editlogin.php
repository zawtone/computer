<?php
 require_once('database.php');
 $id = $_GET['id'];
 $ed = $database->loginread($id);
 $e = mysqli_fetch_assoc($ed);
 if(isset($_POST) & !empty($_POST)){
     $lname = $database->sanitize($_POST['lname']);
     $pass = $database->sanitize($_POST['pass']);
     $idname = $database->sanitize($_POST['idname']);
     
     
    $ress = $database->loginupdate($lname,$pass,$idname, $id);
    if($ress){
        header("location:backendlogin.php");
    }else{
        echo "failed to update data";
    }
}




?>
<!DOCTYPE html>
<html>
<head>
	<title>
		edit
	</title>
	<title>
		sms admin
	</title>
	<meta   charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container " id="">
	<h3>edit login</h3>
			<form role="form" method="post">
				<div class="form-group">
			      <label for="email">User name</label>
			      <input name="lname" type="text" class="form-control" value="<?php echo $e['lname'] ?>" >
			    </div>
			    <div class="form-group">
			      <label for="email">Password</label>
			      <input name="pass" type="text" class="form-control" value="<?php echo $e['pass'] ?>"  >
			    </div>
			    <div class="form-group">
			      <label for="pwd">admin code def(1QwiYiip123Foho)</label>
			      <input name="idname" type="text" class="form-control" value="<?php echo $e['idname'] ?>"  >
			    </div>
			    <input type="submit" class="btn btn-default pull-right" value="submits">
			</form>
</div>
</body>
</html>