<?php
 require_once('database.php');
 $id = $_GET['id'];
 
 $res = $database->logindelete($id);
 if($res){
 	header('location: backendlogin.php');
 }else{
 	echo "Failed to Delete Record";
 }
?>