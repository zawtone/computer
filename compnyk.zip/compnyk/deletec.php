<?php
 require_once('database.php');
 $cid = $_GET['cid'];
 
 $res = $database->deletec($cid);
 if($res){
 	header('location: backend.php');
 }else{
 	echo "Failed to Delete Record";
 }
?>