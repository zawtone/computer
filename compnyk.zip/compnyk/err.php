<div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
          
          <div class="detailforcenter">
           Wrong username or password
          </div>
          
          </div>          

        </div>
       
  
  
    <div class="rebotton_for-more" data-dismiss="modal">
    Close
    <span class="glyphicon glyphicon-remove-sign"></span>
    </div>
  


        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
        </div>
      </div>
      
    </div>
  </div>