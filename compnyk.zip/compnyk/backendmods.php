<div class="menu-bar">
		<div class="menu-bar-inner">
			<div id="slidebtn">
				<span class="glyphicon glyphicon-align-right"></span>
			</div>
			<div class="menu">
				MENU
			</div>
		</div>
		<div class="logut-id">
			<a href="logout.php" onclick="return confirm('sure to Logout ?')"><p><span class="glyphicon glyphicon-off"></span>Logout</p></a>
		</div>
	</div>
	<div id="slideshow">
		<div>
			<a href="backendlogin.php"><p>Admin</p></a>
		</div>
		<div>
			<a href="backendtbl.php"><p>Register result</p></a>
		</div>
		<div>
			<a href="backendr.php"><p>Register</p></a>

		</div>
		<div>
			<a href="backendexp.php"><p>Expenses</p></a>
		</div>
		<div>
			<a href="backend.php"><p>Comment</p></a>
		</div>
		<div>
			<a href="backendnew.php"><p>News</p></a>
		</div>
		
		<div>
			<a href="servicescom.php"><p>Servics</p></a>
		</div>
		<div>
			<a href="backendcom.php"><p>Servics Result</p></a>
		</div>
		
		

	</div>
	<!-- nenu -->