<?php 
$g = '1QwiYiip123Foho';


if($g == $gi['idname']){

?>
									
<a href="editra.php?rid=<?php echo $kb['rid']; ?>"><button class="btn btn-primary" type="button">edit</button></a>

<?php

 }else{
 	?>
 	
 	<p style="color: red;">	
 			you con not edit
 	</p>
 </td>
 <?php

 }

 ?>	

