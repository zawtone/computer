<div>
  
  <div class="subjects-wholes " id="subjects-id">
    <!-- header -->
    <div class="subjects-header-up">
      <p>သင္ခန္းစာမ်ား</p>
    </div>
     <!-- end -->
<div class="innersubjects">
<div class="whole_sujects slideanim slide">
<div class="subjects_contact">
<div class="arrow">
<div class="header_subjectss">&nbsp;</div>

<div class="header_subjectsss">&nbsp;</div>
</div>

<p class="text_header">Basic</p>

<div class="detail_subjects">
<hr />
<p>[Microsoft offic word, MS Excel, Ms Powerpoint]</p>


</div>

<div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more" data-toggle="modal" data-target="#myModal">
    More detail
    <span class="glyphicon glyphicon-forward"></span>
    </div>
  

</div>

</div>
</div>

<div class="whole_sujects slideanims">
<div class="subjects_contact">
<div class="arrow">
<div class="header_subjectss">&nbsp;</div>

<div class="header_subjectsss">&nbsp;</div>
</div>

<p class="text_header">DTP</p>

<div class="detail_subjects">
<hr />
<p>[Adobe PageMaker, CorelDraw, MS Publisher]</p>

<!-- <hr />
<ul>
  <li>သင္တန္းေၾကး - ၁၅၀၀၀ က်ပ္ + ဓာတ္ပံု (၂) ပံု</li>
  <li>သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ</li>
</ul> -->
</div>

<div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div  class="rebotton_for-more" data-toggle="modal" data-target="#myModal2">
    More detail
    <span class="glyphicon glyphicon-forward"></span>
    </div>
  

</div>

</div>
</div>
</div>

<div class="innersubjects">
<div class="whole_sujects slideanim">
<div class="subjects_contact">
<div class="arrow">
<div class="header_subjectss">&nbsp;</div>

<div class="header_subjectsss">&nbsp;</div>
</div>

<p class="text_header">Graphic Design</p>

<div class="detail_subjects">
<hr />
<p>[Photoshop , Illustrator, Indesign]</p>

<!-- <hr />
<ul>
  <li>သင္တန္းေၾကး - ၂၀၀၀၀ က်ပ္ + ဓာတ္ပံု (၂) ပံု</li>
  <li>သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ</li>
</ul> -->
</div>

<div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more" data-toggle="modal" data-target="#myModal3" >
    More detail
    <span class="glyphicon glyphicon-forward"></span>
    </div>
  

</div>
</div>
</div>

<div class="whole_sujects slideanims">
<div class="subjects_contact">
<div class="arrow">
<div class="header_subjectss">&nbsp;</div>

<div class="header_subjectsss">&nbsp;</div>
</div>

<p class="text_header">Pratical A+</p>

<div class="detail_subjects">
<hr />
<p>[Headware Preparing and software instralling]</p>

<!-- <hr />
<ul>
  <li>သင္တန္းေၾကး - ၂၀၀၀၀ က်ပ္ + ဓာတ္ပံု (၂) ပံု</li>
  <li>သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ</li>
</ul> -->
</div>

<div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more" data-toggle="modal" data-target="#myModal4">
    More detail
    <span class="glyphicon glyphicon-forward"></span>
    </div>
  

</div>
</div>
</div>
</div>

<div class="innersubjects">
<div class="whole_sujects slideanim">
<div class="subjects_contact">
<div class="arrow">
<div class="header_subjectss">&nbsp;</div>

<div class="header_subjectsss">&nbsp;</div>
</div>

<p class="text_header">Video EditingVideo Editing</p>

<div class="detail_subjects">
<hr />
<p>[Adobe Premier, Sony Acid Pro, Window Movie Maker, Pinnacle Studio, Virtual DJ, Cyberlink Power Director, Format Factory, Nero and etc . . . . .]</p>


<!-- <ul>
  <li>သင္တန္းေၾကး - ၂၀၀၀၀ က်ပ္ + ဓာတ္ပံု (၂) ပံု</li>
  <li>သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ</li>
</ul> -->
</div>

<div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more" data-toggle="modal" data-target="#myModal5">
    More detail
    <span class="glyphicon glyphicon-forward"></span>
    </div>
  

</div>


</div>
</div>

<div class="whole_sujects slideanims">
<div class="subjects_contact">
<div class="arrow">
<div class="header_subjectss">&nbsp;</div>

<div class="header_subjectsss">&nbsp;</div>
</div>

<p class="text_header">Website Design</p>

<div class="detail_subjects">
<hr />
<p>[Front End][HTML 5 ,CSS 3, Javascript, JQuery, Bootstrap]</p>

<!-- <hr />
<ul>
  <li>သင္တန္းေၾကး - ၅၀၀၀၀ က်ပ္ + ဓာတ္ပံု (၂) ပံု</li>
  <li>သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၄)လ</li>
</ul> -->
</div>

<div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more " data-toggle="modal" data-target="#myModal6">
    More detail
    <span class="glyphicon glyphicon-forward"></span>
    </div>
  

</div>
</div>
</div>
</div>

<div class="innersubjects">
<div class="whole_sujects slideanim">
<div class="subjects_contact">
<div class="arrow">
<div class="header_subjectss">&nbsp;</div>

<div class="header_subjectsss">&nbsp;</div>
</div>

<p class="text_header">Website Developing</p>

<div class="detail_subjects">
<hr />
<p>[Backend End][PHP +MySQL, CMS [Wordpress, Drupal], CodeIgnitor with many project tutorials]</p>

<!-- <hr />
<ul>
  <li>သင္တန္းေၾကး - ၁၀၀၀၀၀ က်ပ္ + ဓာတ္ပံု (၂) ပံု</li>
  <li>သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၄)လ</li>
</ul> -->
</div>

<div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more " data-toggle="modal" data-target="#myModal7">
    More detail
    <span class="glyphicon glyphicon-forward"></span>
    </div>
 

</div>
</div>
</div>

<div class="whole_sujects slideanims">
<div class="subjects_contact">
<div class="arrow">
<div class="header_subjectss">&nbsp;</div>

<div class="header_subjectsss">&nbsp;</div>
</div>

<p class="text_header">Website Developing</p>

<!-- <div class="detail_subjects">
<hr />
<p>[Laravel Framework]</p>

<hr />
<ul>
  <li>သင္တန္းေၾကး - ၁၀၀၀၀၀ က်ပ္ + ဓာတ္ပံု (၂) ပံု</li>
  <li>သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ</li>
</ul>
</div> -->
<div class="detail_subjects">
<hr />
<p>[Laravel Framework]</p>

<!-- <hr />
<ul>
  <li>သင္တန္းေၾကး - ၁၀၀၀၀၀ က်ပ္ + ဓာတ္ပံု (၂) ပံု</li>
  <li>သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ</li>
</ul> -->
</div>

<div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more " data-toggle="modal" data-target="#myModal8">
    More detail
    <span class="glyphicon glyphicon-forward"></span>
    </div>
  

</div>
</div>
</div>
</div>

<div class="innersubjects1">
<div class="whole_sujects slideanims">
<div class="subjects_contact">
<div class="arrow">
<div class="header_subjectss">&nbsp;</div>

<div class="header_subjectsss">&nbsp;</div>
</div>

<p class="text_header">HR / Admin Basic Course</p>

<!-- <div class="detail_subjects">
<hr />
<p>[Laravel Framework]</p>

<hr />
<ul>
  <li>သင္တန္းေၾကး - ၁၀၀၀၀၀ က်ပ္ + ဓာတ္ပံု (၂) ပံု</li>
  <li>သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ</li>
</ul>
</div> -->
<div class="detail_subjects">
<hr />
<p></p>

<!-- <hr />
<ul>
  <li>သင္တန္းေၾကး - ၁၀၀၀၀၀ က်ပ္ + ဓာတ္ပံု (၂) ပံု</li>
  <li>သင္​တန္​းၾကာျမင္​့ခ်ိန္​ - (၂)လ</li>
</ul> -->
</div>

<div class="button_read_M">
  <a href="http://localhost/compnyk/register.php">
    <div class="rebotton-for-reg">
      စာရင္းသြင္းမည္
      <span class="glyphicon glyphicon-export"></span>
    </div>
  </a>
  
    <div class="rebotton_for-more " data-toggle="modal" data-target="#myModal9">
    More detail
    <span class="glyphicon glyphicon-forward"></span>
    </div>
  

</div>
</div>
</div>
</div>
</div>

</div>


