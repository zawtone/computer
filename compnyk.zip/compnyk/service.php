
<?php
require_once('database.php');

$res_com = $database->servicesread();
$res_comb = $database->servicesread();
$res_comc = $database->servicesread();
$res_comd = $database->servicesread();




?>
<!DOCTYPE html>
<html>
<head>
	<title>forcomputer</title>
	<meta   charset="utf-8" />
	<link rel="shortcut icon" href="http://localhost/compnyk/pics/logopnyk.jpg">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/subject.css">
	<link rel="stylesheet" type="text/css" href="css/news.css">
	<link rel="stylesheet" type="text/css" href="css/service.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/copy.js"></script>
	<!-- window -->
	<script src="js/window.js"></script>
	<!---- start-smoth-scrolling---->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<!---- start-smoth-scrolling---->
	<style type="text/css">
	.actives{
		border-bottom: 0 !important;
	}
	.actives1{
		border-bottom: 0 !important;
	}
	.actives2{
		border-bottom: 0 !important;
	}
	.actives4{
		border-bottom: 0 !important;
	}
	.actives5{
		border-bottom: 3px solid #00FFB7 !important;
	}
</style>
</head>
<body>
	<!-- for the whole -->
	<div class="thewhole thewholecc">
		<div><!-- nav and croudel -->
			<?php
			include("nav.php");
			?>
			<?php
			include("crousel.php");
			?>
			<!-- nav and croudle end -->

			<!-- inner content -->

			<div class=" service-header">
				<span>Our service</span>
			</div>
			<div class="container-fluid whole-service">
				<div class="row">
					<div class="col-sm-3">
						<div class="servic-menu">
							<a data-toggle="tab" href="#pal">
								PC and Laptop
							</a>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="servic-menu">
							<a data-toggle="tab" href="#pri">
								Printer
							</a>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="servic-menu">
							<a data-toggle="tab" href="#net">
								Network
							</a>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="servic-menu">
							<a data-toggle="tab" href="#web">
								Web developing
							</a>
						</div>
					</div>
				</div>
			</div>	
			<div class="tab-content wholetabfade">
				
				<div id="pal" class="tab-pane fade innertab servicetext  in active " >
					<div class="headerforservice-mini"><h3>Desktop and Laptop service</h3></div>
					<ul>
						<li>
							Window and Linux installation
						</li>
						<li>
							Dual Booting (Window and Linux)
						</li>
						<li>
							Hardware & Software installation (Windows & Linux)
						</li>
						<li>
							Hardware & Software troubleshooting
						</li>
						<li>
							Virus Cleaning & System Repairing
						</li>
						<li>
							Data Recovery and License Window Recovery Service
						</li>
						<li>
							Keyboard Repair & Replacing 
						</li>
					</ul>

					<div class="headerfor-client">
						<h3>
							Our Client Projects
						</h3>
					</div>
					<div class="row" style="display: block;max-width: 780px;margin-left: auto;margin-right: auto;height: auto;">
						 				<?php 

						                    while($a = mysqli_fetch_assoc($res_com)){    
						                    	$aa = 'PCL';
											while($aa == $a['serv']){
						                ?>
						
						<div class="inner-opj-show">
						<div class="ser-product-show">
							<div class="css-for-opjid">
								<p><?php echo $a['proid']?></p>
							</div>

							<img src="user_images/<?php echo $a['img']?>" >
							<div class="css-showmoredat-1 " data-toggle="modal" data-target="#myModal<?php echo $a['modid']?>" style="position: relative;">
								Show more datail
							</div>
						</div>
						<!-- Modal -->
  <div class="modal fade" id="myModal<?php echo $a['modid']?>" role="dialog">
    <div class="modal-dialog wholemod-for-ser">
    <h3 class="modcode"><?php echo $a['proid']?></h3>
      <img src="user_images/<?php echo $a['img']?>" class="imgsive">

      <div class="row">
      	<div class="col-sm-6"><div class="dates"><span>Reseive Date</span> <?php echo $a['redate']?></div></div>
      	<div class="col-sm-6"><div class="dates"><span>Finish Date</span> <?php echo $a['findate']?></div></div>
      </div>

      <div class="row">
      	<div class="col-sm-12">
      		<div class="percentages">
      			<h3><?php echo $a['per']?>% complete</h3>
      			<div class="progress percentagesbar">
				  <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="50"
				  aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $a['per']?>%">
				  </div>
				</div>
      		</div>
      	</div>
      </div>

      <div class="row">
      	<div class="col-sm-12">
      		<p class="information">
      			<?php echo $a['infor']?> 
      		</p>
      		 <button type="button" class="btn btn-default" data-dismiss="modal" style="float: right;">Close</button>
      	</div>
      </div>

      
    </div>
  </div>
						</div>
						<?php $aa++;
      			  			}
      			  			
		                      }
		                  ?>

						




				
			</div>
		</div>
		<div id="pri" class="tab-pane fade innertab servicetext">
			<div class="headerforservice-mini"><h3>Printer service</h3></div>
					<ul>
						<li>
							Window and Linux installation
						</li>
						<li>
							Dual Booting (Window and Linux)
						</li>
						<li>
							Hardware & Software installation (Windows & Linux)
						</li>
						<li>
							Hardware & Software troubleshooting
						</li>
						<li>
							Virus Cleaning & System Repairing
						</li>
						<li>
							Data Recovery and License Window Recovery Service
						</li>
						<li>
							Keyboard Repair & Replacing 
						</li>
					</ul>

					<div class="headerfor-client">
						<h3>
							Our Client Projects
						</h3>
					</div>
					<div class="row" style="display: block;max-width: 780px;margin-left: auto;margin-right: auto;height: auto;">
						 				<?php 

						                    while($ab = mysqli_fetch_assoc($res_comb)){    
						                    	$aab = 'PRI';
											while($aab == $ab['serv']){
						                ?>
						
						<div class="inner-opj-show">
						<div class="ser-product-show">
							<div class="css-for-opjid">
								<p><?php echo $ab['proid']?></p>
							</div>

							<img src="user_images/<?php echo $ab['img']?>" >
							<div class="css-showmoredat-1 " data-toggle="modal" data-target="#myModal<?php echo $ab['modid']?>" style="position: relative;">
								Show more datail
							</div>
						</div>
						<!-- Modal -->
  <div class="modal fade" id="myModal<?php echo $ab['modid']?>" role="dialog">
    <div class="modal-dialog wholemod-for-ser">
    <h3 class="modcode"><?php echo $ab['proid']?></h3>
      <img src="user_images/<?php echo $ab['img']?>" class="imgsive">

      <div class="row">
      	<div class="col-sm-6"><div class="dates"><span>Reseive Date</span> <?php echo $ab['redate']?></div></div>
      	<div class="col-sm-6"><div class="dates"><span>Finish Date</span> <?php echo $ab['findate']?></div></div>
      </div>

      <div class="row">
      	<div class="col-sm-12">
      		<div class="percentages">
      			<h3><?php echo $ab['per']?>% complete</h3>
      			<div class="progress percentagesbar">
				  <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="50"
				  aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $ab['per']?>%">
				  </div>
				</div>
      		</div>
      	</div>
      </div>

      <div class="row">
      	<div class="col-sm-12">
      		<p class="information">
      			<?php echo $ab['infor']?> 
      		</p>
      		 <button type="button" class="btn btn-default" data-dismiss="modal" style="float: right;">Close</button>
      	</div>
      </div>

      
    </div>
  </div>
						</div>
						<?php $aab++;
      			  			}
      			  			
		                      }
		                  ?>								
			</div>
		</div>
		<div id="net" class="tab-pane fade innertab servicetext">
			<div class="headerforservice-mini"><h3>Network service</h3></div>
					<ul>
						<li>
							Window and Linux installation
						</li>
						<li>
							Dual Booting (Window and Linux)
						</li>
						<li>
							Hardware & Software installation (Windows & Linux)
						</li>
						<li>
							Hardware & Software troubleshooting
						</li>
						<li>
							Virus Cleaning & System Repairing
						</li>
						<li>
							Data Recovery and License Window Recovery Service
						</li>
						<li>
							Keyboard Repair & Replacing 
						</li>
					</ul>

					<div class="headerfor-client">
						<h3>
							Our Client Projects
						</h3>
					</div>
					<div class="row" style="display: block;max-width: 780px;margin-left: auto;margin-right: auto;height: auto;">
						 				<?php 

						                    while($ac = mysqli_fetch_assoc($res_comc)){    
						                    	$aac = 'NET';
											while($aac == $ac['serv']){
						                ?>
						
						<div class="inner-opj-show">
						<div class="ser-product-show">
							<div class="css-for-opjid">
								<p><?php echo $ac['proid']?></p>
							</div>

							<img src="user_images/<?php echo $ac['img']?>" >
							<div class="css-showmoredat-1 " data-toggle="modal" data-target="#myModal<?php echo $ac['modid']?>" style="position: relative;">
								Show more datail
							</div>
						</div>
						<!-- Modal -->
  <div class="modal fade" id="myModal<?php echo $ac['modid']?>" role="dialog">
    <div class="modal-dialog wholemod-for-ser">
    <h3 class="modcode"><?php echo $ac['proid']?></h3>
      <img src="user_images/<?php echo $ac['img']?>" class="imgsive">

      <div class="row">
      	<div class="col-sm-6"><div class="dates"><span>Reseive Date</span> <?php echo $ac['redate']?></div></div>
      	<div class="col-sm-6"><div class="dates"><span>Finish Date</span> <?php echo $ac['findate']?></div></div>
      </div>

      <div class="row">
      	<div class="col-sm-12">
      		<div class="percentages">
      			<h3><?php echo $ac['per']?>% complete</h3>
      			<div class="progress percentagesbar">
				  <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="50"
				  aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $ac['per']?>%">
				  </div>
				</div>
      		</div>
      	</div>
      </div>

      <div class="row">
      	<div class="col-sm-12">
      		<p class="information">
      			<?php echo $ac['infor']?> 
      		</p>
      		 <button type="button" class="btn btn-default" data-dismiss="modal" style="float: right;">Close</button>
      	</div>
      </div>

      
    </div>
  </div>
						</div>
						<?php $aac++;
      			  			}
      			  			
		                      }
		                  ?>

						




				
			</div>
		</div>
		<div id="web" class="tab-pane fade innertab servicetext">
			<div class="headerforservice-mini"><h3>Web Developing service</h3></div>
					<ul>
						<li>
							Window and Linux installation
						</li>
						<li>
							Dual Booting (Window and Linux)
						</li>
						<li>
							Hardware & Software installation (Windows & Linux)
						</li>
						<li>
							Hardware & Software troubleshooting
						</li>
						<li>
							Virus Cleaning & System Repairing
						</li>
						<li>
							Data Recovery and License Window Recovery Service
						</li>
						<li>
							Keyboard Repair & Replacing 
						</li>
					</ul>

					<div class="headerfor-client">
						<h3>
							Our Client Projects
						</h3>
					</div>
					<div class="row" style="display: block;max-width: 780px;margin-left: auto;margin-right: auto;height: auto;">
						 				<?php 

						                    while($ad = mysqli_fetch_assoc($res_comd)){    
						                    	$aad = 'WEB';
											while($aad == $ad['serv']){
						                ?>
						
						<div class="inner-opj-show">
						<div class="ser-product-show">
							<div class="css-for-opjid">
								<p><?php echo $ad['proid']?></p>
							</div>

							<img src="user_images/<?php echo $ad['img']?>" >
							<div class="css-showmoredat-1 " data-toggle="modal" data-target="#myModal<?php echo $ad['modid']?>" style="position: relative;">
								Show more datail
							</div>
						</div>
						<!-- Modal -->
  <div class="modal fade" id="myModal<?php echo $ad['modid']?>" role="dialog">
    <div class="modal-dialog wholemod-for-ser">
    <h3 class="modcode"><?php echo $ad['proid']?></h3>
      <img src="user_images/<?php echo $ad['img']?>" class="imgsive">

      <div class="row">
      	<div class="col-sm-6"><div class="dates"><span>Reseive Date</span> <?php echo $ad['redate']?></div></div>
      	<div class="col-sm-6"><div class="dates"><span>Finish Date</span> <?php echo $ad['findate']?></div></div>
      </div>

      <div class="row">
      	<div class="col-sm-12">
      		<div class="percentages">
      			<h3><?php echo $ad['per']?>% complete</h3>
      			<div class="progress percentagesbar">
				  <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="50"
				  aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $ad['per']?>%">
				  </div>
				</div>
      		</div>
      	</div>
      </div>

      <div class="row">
      	<div class="col-sm-12">
      		<p class="information">
      			<?php echo $ad['infor']?> 
      		</p>
      		 <button type="button" class="btn btn-default" data-dismiss="modal" style="float: right;">Close</button>
      	</div>
      </div>

      
    </div>
  </div>
						</div>
						<?php $aad++;
      			  			}
      			  			
		                      }
		                  ?>

						




				
			</div>
		</div>
	</div>

	<!-- content end -->

	<?php
	include("subjectmod.php");
	?>
	<div class="footer_part "><!-- footer -->
		<?php
		include("footer.php");
		?>
	</div>
	
	<div class="pbzmh">
		power by zmh.


		<a href="#" class="topup" id="toTop" style="display: block;"> <span class="glyphicon glyphicon-menu-up  forupdownmenu" id="toTopHover" style="opacity: 1;"> </span></a> 


	</div>
</div><!-- thewhole end -->
<script type="text/javascript">
	$(document).ready(function() {

             /* var defaults = {
                  containerID: 'toTop', // fading element id
                containerHoverID: 'toTopHover', // fading element hover id
                scrollSpeed: 1200,
                easingType: 'linear' 
            };*/


            $().UItoTop({ easingType: 'easeOutQuart' });

        });
    </script>
</body>
</html>