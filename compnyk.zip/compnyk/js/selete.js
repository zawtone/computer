//for service
		function cho(){
		var a=document.getElementById('choose').value;
		document.getElementById('responed').innerHTML="your selected :"+a;

		}
//for service
		
//for service
		function choone(){
		var a=document.getElementById('chooseone').value;
		document.getElementById('responedone').innerHTML="your selected :"+a;

		}		