 $(document).ready(function(){
    
        
       
        $(".forjq-show").toggle(0000);
      

      /*$("#show").click(function(){
        $("p").show(1000);
      });*/
        $(".forjq-show").show(2000);

/*for window upload*/
        $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });

  
        /*next*/
      $(window).scroll(function() {
    $(".slideanims").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slides");
        }
    });
  });
    
});

    $(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").slideToggle(1000);
    });
});
    

    $(document).ready(function(){
      $(".news-model ").hide(0000);
    $(".new-show-battem-link").click(function(){
        $(".news-model ").toggle("slow");
    });
});