
  function addData() 
  {
    if(isValid()) 
    {
      var i = 1;
      while(true) 
      {
        if(localStorage.getItem("StudentId" + i) == null) 
        {
          localStorage.setItem("StudentId" + i,document.getElementById("txtId").value);
          localStorage.setItem("StudentName" + i, document.getElementById("txtname").value);
          localStorage.setItem("Level" + i, document.getElementById("txtLevel").value);
          localStorage.setItem("Address" + i, document.getElementById("txtAddress").value);
          localStorage.setItem("Amount" + i, document.getElementById("txtAmount").value);
          
          document.getElementById("txtId").value = "";
          document.getElementById("txtname").value = "";
          document.getElementById("txtLevel").value = "";
          document.getElementById("txtAddress").value = "";
          document.getElementById("txtAmount").value = "";
          
          if(localStorage.length == 0)
            document.getElementById("datatable").style.display = "none";
          else
            document.getElementById("datatable").removeAttribute("style");
            
          getData();
          
          if(getElement("languageselect")[getElement("languageselect").selectedIndex].value == "english")
            alert("Save successfully!");
          if(getElement("languageselect")[getElement("languageselect").selectedIndex].value == "myanmar")
            alert("သိမ္းဆည္းျပီးပါျပီ!");
          document.getElementById("txtId").focus();
          break;
        }
        i++;
      }
    }
  }
  
  function isValid() {
  
    var txtId = document.getElementById("txtId");
    var txtname = document.getElementById("txtname");
    var txtLevel = document.getElementById("txtLevel");
    var txtAddress = document.getElementById("txtAddress");
    var txtAmount = document.getElementById("txtAmount");
    
    if(txtId.value == "") {
      if(txtId.parentNode.innerHTML.indexOf("*") == -1)
        txtId.parentNode.innerHTML += "<span style=\"color:red\">*</span>";
      txtId.focus();
      return false;
    } else if(txtname.value == "") {
      if(txtname.parentNode.innerHTML.indexOf("*") == -1)
        txtname.parentNode.innerHTML += "<span style=\"color:red\">*</span>";
      txtname.focus();
      return false;
    } else if(txtLevel.value == "") {
      if(txtLevel.parentNode.innerHTML.indexOf("*") == -1)
        txtLevel.parentNode.innerHTML += "<span style=\"color:red\">*</span>";
      txtLevel.focus();
      return false;
    } else if(txtAddress.value == "") {
      if(txtAddress.parentNode.innerHTML.indexOf("*") == -1)
        txtAddress.parentNode.innerHTML += "<span style=\"color:red\">*</span>";
      txtAddress.focus();
      return false;
    } else if(txtAmount.value == "") {
      if(txtAmount.parentNode.innerHTML.indexOf("*") == -1)
        txtAmount.parentNode.innerHTML += "<span style=\"color:red\">*</span>";
      txtAmount.focus();
      return false;
    } else
      return true;
  }
  
  function getData() {
    removeallrow();
    
    var totalAmount = 0;
    var table = document.getElementById("datatable").getElementsByTagName("tbody")[0];
  
    if(localStorage.length == 0)
      document.getElementById("datatable").style.display = "none";
    else
      document.getElementById("datatable").removeAttribute("style");
    
    for(var i = 0; i < (localStorage.length); i++) {
      //var row = table.insertRow(i);
      
      if(localStorage.getItem("StudentId" + i) != null) {
        var row = table.insertRow(table.rows.length);
      
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        var cell3 = row.insertCell(2);
        var cell4 = row.insertCell(3);
        var cell5 = row.insertCell(4);
        var cell6 = row.insertCell(5);
        
        cell1.innerHTML = localStorage.getItem("StudentId" + i);
        cell2.innerHTML = localStorage.getItem("StudentName" + i);
        cell3.innerHTML = localStorage.getItem("Level" + i);
        cell4.innerHTML = localStorage.getItem("Address" + i);
        cell5.innerHTML = localStorage.getItem("Amount" + i);

        if(getElement("languageselect")[getElement("languageselect").selectedIndex].value == "english")
          cell6.innerHTML = "<button class=\"btnedit\" onclick=\"editrow('" + i + "');\">Edit</button>&nbsp;<button class=\"btnremove\" onclick=\"removerow('" + i + "');\">Remove</button>";
        else if(getElement("languageselect")[getElement("languageselect").selectedIndex].value == "myanmar")
          cell6.innerHTML = "<button class=\"btnedit\" onclick=\"editrow('" + i + "');\">ျပင္ဆင္ျခင္း</button>&nbsp;<button class=\"btnremove\" onclick=\"removerow('" + i + "');\">ဖ်က္မယ္</button>";
        if((i%2) == 0)
          row.setAttribute("class", "altrow");
        else
          row.setAttribute("class", "row");
          
        cell5.setAttribute("style", "text-align:right");
        totalAmount += parseInt(localStorage.getItem("Amount" + i));
  
      }
    }
    document.getElementById("txttotalAmount").value = totalAmount;
  }
  
  function removeallrow() {
    var table = document.getElementById("datatable").getElementsByTagName("tbody")[0];
    for(var i = table.rows.length - 1; i != -1; i--)
      table.deleteRow(i);
  }
  
  function removerow(index) {
    var bool = false;
    if(getElement("languageselect")[getElement("languageselect").selectedIndex].value == "english")
      bool = confirm("Are you sure want to delete?");
    else if(getElement("languageselect")[getElement("languageselect").selectedIndex].value == "myanmar")
      bool = confirm("ဖ်က္မွာေသခ်ာပါသလား?");
    if(bool) {
      var table = document.getElementById("datatable").getElementsByTagName("tbody")[0];
      table.deleteRow(index - 1);
      
      localStorage.removeItem("StudentId" + index);
      localStorage.removeItem("StudentName" + index);
      localStorage.removeItem("Level" + index);
      localStorage.removeItem("Address" + index);
      localStorage.removeItem("Amount" + index);
      
      var array = [];
      for(var i = 0; i < localStorage.length; i++) {
        if(localStorage.getItem("StudentId" + i) != null) {
          var _Id = localStorage.getItem("StudentId" + i);
          var _name = localStorage.getItem("StudentName" + i);
          var _Level = localStorage.getItem("Level" + i);
          var _Address = localStorage.getItem("Address" + i);
          var _Amount = localStorage.getItem("Amount" + i);
          array.push({ StudentId:_Id,StudentName : _name, Level : _Level, Address : _Address, Amount : _Amount });
        }
      }
      
      localStorage.clear();
      
      for(var j = 0; j < array.length; j++) {
        var i = j + 1;
        localStorage.setItem("StudentId" + i, array[j].StudentId);
        localStorage.setItem("StudentName" + i, array[j].StudentName);
        localStorage.setItem("Level" + i, array[j].Level);
        localStorage.setItem("Address" + i, array[j].Address);
        localStorage.setItem("Amount" + i, array[j].Amount);
      }
      getData();

      var bool = false;
      if(getElement("languageselect")[getElement("languageselect").selectedIndex].value == "english")
        alert("delete successfully!");
      else if(getElement("languageselect")[getElement("languageselect").selectedIndex].value == "myanmar")
        alert("ဖ်က္ျပီးပါျပီ!");
    }
  }
  
  function editrow(index) {
    var table = document.getElementById("datatable").getElementsByTagName("tbody")[0];
    document.getElementById("txtId").value = localStorage.getItem("StudentId" + index);
    document.getElementById("txtname").value = localStorage.getItem("StudentName" + index);
    document.getElementById("txtLevel").value = localStorage.getItem("Level" + index);
    document.getElementById("txtAddress").value = localStorage.getItem("Address" + index);
    document.getElementById("txtAmount").value = localStorage.getItem("Amount" + index);
    
    document.getElementById("btnadd").style.display = "none";
    document.getElementById("btnedit").style.display = "block";
    
    document.getElementById("btnedit").setAttribute("onclick", "editData('" + index + "');");
  }
  
  function editData(index) {
    localStorage.setItem("StudentId" + index, document.getElementById("txtId").value);
    localStorage.setItem("StudentName" + index, document.getElementById("txtname").value);
    localStorage.setItem("Level" + index, document.getElementById("txtLevel").value);
    localStorage.setItem("Address" + index, document.getElementById("txtAddress").value);
    localStorage.setItem("Amount" + index, document.getElementById("txtAmount").value);
    
    document.getElementById("txtId").value = "";
    document.getElementById("txtname").value = "";
    document.getElementById("txtLevel").value = "";
    document.getElementById("txtAddress").value = "";
    document.getElementById("txtAmount").value = "";
    
    document.getElementById("btnadd").style.display = "block";
    document.getElementById("btnedit").style.display = "none";
    
    getData();
    if(getElement("languageselect")[getElement("languageselect").selectedIndex].value == "english") alert("update successfully!");
    if(getElement("languageselect")[getElement("languageselect").selectedIndex].value == "myanmar") alert("ျပင္ဆင္ျခင္းျပီးပါျပီ!");
    document.getElementById("txtId").focus();
  }
  
  function hasData(e) {
    var source = e.target || e.srcElement;
    if(source.value != 0) {
      try {
        source.parentNode.removeChild(document.getElementsByTagName("span")[0]);
      } catch(e) { }
    }
  }
  
  function keyDown(e) {
    var source = e.target || e.srcElement;
    var code = e.keyCode ? e.keyCode : e.charCode;
    var id = source.getAttribute("id");
    if(code == 13) 
    {
      if(id == "txtId") document.getElementById("txtname").focus();else
      if(id == "txtname")document.getElementById("txtLevel").focus();else
      if(id == "txtLevel")document.getElementById("txtAddress").focus();else 
      if(id == "txtAddress")document.getElementById("txtAmount").focus();else 
      if(id == "txtAmount") 
      {
        if(document.getElementById("btnadd").style.display != "none")
          document.getElementById("btnadd").click();
        else
          document.getElementById("btnedit").click();
      }
    }
  }
  function keyPress(e) {
    var minKeyCode = 48;
    var maxKeyCode = 58;
    
    var source = e.target || e.srcElement;
    var code = parseInt(e.keyCode ? e.keyCode : e.charCode);
    
    //alert(code);
    
    if(code >= minKeyCode && code <= maxKeyCode) { }
    else {
      switch(code) {
        case 8: break;
        case 9: break;
        case 13: break;
        case 37: break;
        case 39: break;
        case 46: break;
        default: e.preventDefault();
      } 
    }
  }
  
  function keyUp(e) 
  {
    var source = e.target || e.srcElement;
    
    var totalAmount = 0;
    var table = document.getElementById("datatable").getElementsByTagName("tbody")[0];
    for(var i = 0; i < table.rows.length; i++) 
      totalAmount += parseInt(table.rows[i].cells[4].innerHTML);
    if(source.value != "")  totalAmount += parseInt(source.value); else   totalAmount += 0;
    document.getElementById("txttotalAmount").value = totalAmount;
  }
  
  function languageChange() 
  {
    var listbox = document.getElementById("languageselect");
    var txtlanguage = listbox[listbox.selectedIndex].value;
    if(txtlanguage == "myanmar") 
    {
      
      getElement("lblselectlanguage").innerHTML = "စာရင္းသြင္းျခင္း";
      getElement("lblId").innerHTML = "အမည္";
      getElement("lblname").innerHTML = "အဘအမည္";
      getElement("lblLevel").innerHTML = "ေမြးသကၠရာဇ္​";
      getElement("lblAddress").innerHTML = "မွတ္ပံုတင္ နံပာတ္";
      getElement("lblAmount").innerHTML = "ပညာအရည္​အခ်င္​း";
      getElement("lblocc").innerHTML = "အလုပ္​အကိုင္";
      getElement("lblcom").innerHTML = "ကြန္​ပ်ဴတာ အ​ေတြ႔အၾကံဳ (႐ွိ\မ႐ွိ) ";
      getElement("lblpho").innerHTML = "ဆက္​သြယ္​ရန္​ဖုန္";
      getElement("lbladdress").innerHTML = "ေနရပ္​လိပ္​စာ ";
      getElement("lblbatch").innerHTML = "သင္​တန္​းအပတ္​စဥ္";
      

     /* getElement("txtId").setAttribute("placeholder", "ေက်းဇူးျပဳျပီး အမွတ္စဥ္ ရိုက္ထည့္ေပးပါ...");
      getElement("txtname").setAttribute("placeholder", "ေက်းဇူးျပဳျပီး နာမည္ ရိုက္ထည့္ေပးပါ...");
      getElement("txtLevel").setAttribute("placeholder", "ေက်းဇူးျပဳျပီး အတန္း ရိုက္ထည့္ေပးပါ...");
      getElement("txtAddress").setAttribute("placeholder", "ေက်းဇူးျပဳျပီး လိပ္စာရိုက္ထည့္ေပးပါ...");
      getElement("txtAmount").setAttribute("placeholder", "ေက်းဇူးျပဳျပီး သင္တန္းေၾကး ရိုက္ထည့္ေပးပါ...");*/

      getElement("btnadd").innerHTML = "အတည္ျပဳ႕ သည္";
      /*getElement("btnedit").innerHTML = " ျပင္ဆင္ျခင္း";*/

      getElement("lblgridid").innerHTML = "အမွတ္စဥ္";
      getElement("lblgridname").innerHTML = "နာမည္";
      getElement("lblgridLevel").innerHTML = "အတန္း";
      getElement("lblgridAddress").innerHTML = "လိပ္စာ";
      getElement("lblgridAmount").innerHTML = "သင္တန္းေၾကး ";

      for(var i = 0; i < document.getElementsByClassName("btnedit").length; i++)
        document.getElementsByClassName("btnedit")[i].innerHTML = " ျပင္ဆင္ျခင္း";

      for(var i = 0; i < document.getElementsByClassName("btnremove").length; i++)
        document.getElementsByClassName("btnremove")[i].innerHTML = "ဖ်က္မယ္";
    }
    if(txtlanguage == "english") {
      getElement("lblselectlanguage").innerHTML = "Registration ";
      
      getElement("lblId").innerHTML = "NAME ";
      getElement("lblname").innerHTML = " FATHER NAME ";
      getElement("lblLevel").innerHTML = " DATE OF BIRTH ";
      getElement("lblAddress").innerHTML = " NRC NO ";
      getElement("lblAmount").innerHTML = " EDUCATIONAL QUALIFICATION ";
      getElement("lblocc").innerHTML = " OCCUPATION ";
      getElement("lblcom").innerHTML = " COMPUTER EXPERIENCE ";
      getElement("lblpho").innerHTML = " PHONE ";
      getElement("lbladdress").innerHTML = " RESIDENTIAL ADDRESS ";
      getElement("lblbatch").innerHTML = " Batch ";
      

      /*getElement("txtId").setAttribute("placeholder", "please type Student Id");
      getElement("txtname").setAttribute("placeholder", "please type Student Name");
      getElement("txtLevel").setAttribute("placeholder", "please type Level");
      getElement("txtAddress").setAttribute("placeholder", "please type Address");
      getElement("txtAmount").setAttribute("placeholder", "please type Amount");*/

      getElement("btnadd").innerHTML = "SUBMIT";
      /*getElement("btnedit").innerHTML = "edit";*/

      getElement("lblgridid").innerHTML = "STUDENTID";
      getElement("lblgridname").innerHTML = "STUDENTNAME ";
      getElement("lblgridLevel").innerHTML = " LEVEL";
      getElement("lblgridAddress").innerHTML = " ADDRESS ";
      getElement("lblgridAmount").innerHTML = " AMOUNT ";

      for(var i = 0; i < document.getElementsByClassName("btnedit").length; i++)
        document.getElementsByClassName("btnedit")[i].innerHTML = "Edit";

      for(var i = 0; i < document.getElementsByClassName("btnremove").length; i++)
        document.getElementsByClassName("btnremove")[i].innerHTML = "Remove";
    }
    document.cookie = "language=" + getElement("languageselect")[getElement("languageselect").selectedIndex].value + ";";
  }
  
  function getElement(id) 
  {
    return document.getElementById(id);
  }
  function Load() 
  {
    var languageselect = getElement("languageselect");
    if(document.cookie.split("=")[1] == "") 
    {
      var language = window.navigator.userLanguage || window.navigator.language;
      if(language == "en-US") language = "english";
      for(var i = 0; i < languageselect.length; i++) 
        if(language == languageselect[i].value)     languageselect.selectedIndex = i;
    } else 
    {
      for(var i = 0; i < languageselect.length; i++) 
        if(document.cookie.split("=")[1] == languageselect[i].value)     languageselect.selectedIndex = i;
      languageChange();
    }
  }
  