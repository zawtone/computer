 <?php  
  session_start();
  require_once('database.php');
  $database = new Database();

 if (isset($_REQUEST['submit'])) {
    extract($_REQUEST);
      $login = $database->login($lname, $pass);
      if ($login) {
          // Registration Success
         header("location:backendtbl.php");
      } else {
          // Registration Failed
         
          echo 'wroud pass';
 
 
      }
  } 
  
?>
<!DOCTYPE html>
<html>
<head>
	<title>forcomputer</title>
  <meta   charset="utf-8" />
  <link rel="shortcut icon" href="http://localhost/compnyk/pics/logopnyk.jpg">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/subject.css">
  <link rel="stylesheet" type="text/css" href="css/news.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/copy.js"></script>
<!-- window -->
	<script src="js/window.js"></script>
<!---- start-smoth-scrolling---->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<!---- start-smoth-scrolling---->
<link rel="stylesheet" href="validation/jquery-validation-1.19.0/demo/css/screen.css">
  <script src="validation/jquery-validation-1.19.0/dist/jquery.validate.js"></script>
  <script src="validation/jquery-validation-1.19.0/dist/additional-methods.js"></script>
  <script type="text/javascript">
    $().ready(function() {
    // validate the comment form when it is submitted
    $("#loginform").validate();
  });

  </script>
<style type="text/css">
  .error{
    color: red !important;
  }
	.actives{
		border-bottom: 0 !important;
	}
	.actives1{
		border-bottom: 0 !important;
	}
	.actives2{
		border-bottom: 0 !important;
	}
	.actives4{
		border-bottom: 3px solid #00FFB7 !important;
	}
	.actives5{
		border-bottom: 0 !important;
	}
</style>
</head>
<body oncontextmenu="return false">
	<!-- for the whole -->
<div class="thewhole thewholecl">
<div><!-- nav and croudel -->
	<?php
		include("nav.php");
	?>
	<?php
		include("crousel.php");
	?>
</div><!-- nav and croudle end -->

<!-- inner content -->
	
	<div class="container">
  <div class="cfornews-header">
   Admin LOGIN
  </div>
  <form class="cfornews-form cfornews-formcl slideanim" method="POST" action="#" id="loginform">
    <label class="colorsrr">အမည္ </label><br>
    
    <input name="lname" type="text" class="form-control" placeholder="Name" required/ >
    <br>

    <label class="colorsrr">စကား၀ွက္ </label><br>
    
    <input name="pass" type="password" class="form-control" placeholder="Password" required/ >
    <br>
    <button type="submit" name="submit"> ၀င္မည္။<span class="glyphicon glyphicon-new-window"></button>
  </form>
</div>
<!-- content end -->
	<?php
		include("subjectmod.php");
	?>

<div class="footer_part "><!-- footer -->
	<?php
		include("footer.php");
	?>
</div>
	
<div class="pbzmh">
  power by zmh.
  
        
        <a href="#" class="topup" id="toTop" style="display: block;"> <span class="glyphicon glyphicon-menu-up  forupdownmenu" id="toTopHover" style="opacity: 1;"> </span></a> 
        
      
</div>
</div><!-- thewhole end -->
<script type="text/javascript">
            $(document).ready(function() {
              
             /* var defaults = {
                  containerID: 'toTop', // fading element id
                containerHoverID: 'toTopHover', // fading element hover id
                scrollSpeed: 1200,
                easingType: 'linear' 
              };*/
              
              
              $().UItoTop({ easingType: 'easeOutQuart' });
              
            });
          </script>
</body>
</html>