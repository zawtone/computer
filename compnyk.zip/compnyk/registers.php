

<select id="languageselect" title="Select Language" onChange="languageChange();" style="float: right; display: block;">
    
    <option value="english">English</option>
    <option value="myanmar">Myanmar</option>
  </select>

<div class="form-header_whole">
  <span class="form-header_wholetwo" id="lblselectlanguage">Registration</span>
  
</div>

<!-- register form -->





  <form class="formregister formregistercr" method="post" id="regsterform">
  <label id="lblId" class="slideanim colorsr">
    NAME
  </label>
  <br>
  <input name="name" type="text" class="form-control" placeholder="Your Name" required>
  <br>

  <label id="lblname" class="slideanim colorsr">
    FATHER NAME
  </label>
  <br>
  <input name="fname" type="text" class="form-control" placeholder="Father Name" required><br>

  <label id="lblLevel" class="slideanim colorsr">
    DATE OF BIRTH
  </label>
  <br>
  <input name="dofb" type="text" class="form-control" placeholder="Date of Birth" required><br>

  <label id="lblAddress" class="slideanim colorsr">
    NRC NO
  </label>
  <br>
  <input name="nrcno" type="text" class="form-control" placeholder="Nrc No" required><br>

  <label id="lblAmount" class="slideanim colorsr">
    EDUCATIONAL QUALIFICATION 
  </label>
  <br>
  <input name="edu" type="text" class="form-control" placeholder="Educational" required><br>

  <label id="lblocc" class="slideanim colorsr">
    OCCUPATION
  </label>
  <br>
  <input name="occ" type="text" class="form-control" placeholder="Occupation" required><br>

  <label id="lblcom" class="slideanim colorsr">
    COMPUTER EXPERIENCE 
  </label>
  <br>
  <input name="computer" type="text" class="form-control" placeholder="Computer Exp" required><br>

  <label id="lblpho" class="slideanim colorsr">
    PHONE 
  </label>
  <br>
  <input name="phone" type="number" placeholder="+959" class="form-control" required><br>

  <label id="lbladdress" class="slideanim colorsr">
    RESIDENTIAL ADDRESS
  </label>
  <br>
 <textarea class="form-control commentss"  name="address" placeholder="Address" rows="5" required></textarea><br>

  <label id="lblbatch" class="slideanim colorsr">
    Batch 
  </label>
  <br>
  <input name="batches" type="text" class="form-control" placeholder="Batch" required><br>



<script type="text/javascript">
  $(document).ready(function(){
 $("#btnadd").hide(0000);
  $("#accept").change(function(){
      $("#btnadd").slideToggle(400);
    });
   });
</script>
  
  <input type="checkbox" name="" id="accept">


  <button id="btnadd" type="submit" >SUBMIT</button>


</form>



<!-- end -->