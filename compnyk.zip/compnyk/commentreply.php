<?php
require_once('database.php');
$cid = $_GET['cid'];
$res_admin = $database->cread($cid);

 $r = mysqli_fetch_assoc($res_admin);

 if(isset($_POST) & !empty($_POST)){
	 $reply = $database->sanitize($_POST['reply']);
	
	$res = $database->rupdate($reply, $cid);
	if($res){
	 	header("location:backend.php");
	}else{
	 	echo "failed to update data";
	}
}

?>


<!DOCTYPE html>
<html>
<head>
	<title>
		comment
	</title>
	<meta   charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>
<div>
  						
  					
  					<form role="form" method="post">

  						<div class="form-group">
      						<label for="inputlg" style="font-size: 20px;
													color: #00DBFF;">
												REPLY HERE
							</label>
     						 <input class="form-control input-lg" id="inputlg" type="text" name="reply"  value="<?php echo $r['reply'] ?>">
    					</div>
    					 <a href=""><button  type="submit" class="btn btn-primary" style="margin-right: auto !important;
display: block;
margin-left: auto;
margin-bottom: 10px;">Sent <span class="glyphicon glyphicon-share-alt"></span></button></a>
</div>
    			
					</form>
					</div>
</body>
</html>