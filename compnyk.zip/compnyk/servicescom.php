<?php

	error_reporting( ~E_NOTICE ); // avoid notice
	
	require_once 'connection.php';
	require_once 'database.php';
	session_start();

$database = new Database(); $id = $_SESSION['id'];
$gi = $database->get_fullname($id);
if (!$database->get_session()){
 header("location:login.php");
}
	
	if(isset($_GET['delete_id']))
	{
		// select image from db to delete
		$stmt_select = $connection->prepare('SELECT img FROM services WHERE id =:id');
		$stmt_select->execute(array(':id'=>$_GET['delete_id']));
		$imgRow=$stmt_select->fetch(PDO::FETCH_ASSOC);
		unlink("user_images/".$imgRow['img']);
		
		// it will delete an actual record from db
		$stmt_delete = $connection->prepare('DELETE FROM services WHERE id =:id');
		$stmt_delete->bindParam(':id',$_GET['delete_id']);
		$stmt_delete->execute();
		
		header("Location: servicescom.php");
	}
	if(isset($_POST['btnsave']))
	{
		$serv = $_POST['serv'];
		$infor = $_POST['infor'];// user name
		$proid = $_POST['proid'];
		$modid = $_POST['modid'];
		$redate = $_POST['redate'];
		$findate = $_POST['findate'];
		$fin = $_POST['fin'];
		$per = $_POST['per'];
		$phone = $_POST['phone'];// user email
		
		$imgFile = $_FILES['img']['name'];
		$tmp_dir = $_FILES['img']['tmp_name'];
		$imgSize = $_FILES['img']['size'];
		
		if(empty($serv)){
			$errMSG = "Please Enter services option.";
		}
		if(empty($infor)){
			$errMSG = "Please Enter information.";
		}
		else if(empty($proid)){
			$errMSG = "Please Enter Product id.";
		}
		else if(empty($modid)){
			$errMSG = "Please Enter modal id.";
		}
		else if(empty($redate)){
			$errMSG = "Please Enter Receive date.";
		}
		else if(empty($findate)){
			$errMSG = "Please Enter finish date.";
		}
		else if(empty($fin)){
			$errMSG = "Please Enter Finish or not.";
		}
		else if(empty($per)){
			$errMSG = "Please Enter Your Percentage.";
		}
		else if(empty($phone)){
			$errMSG = "Please Enter Your Percentage.";
		}
		else if(empty($imgFile)){
			$errMSG = "Please Select Image file.";
		}
		else
		{
			$upload_dir = 'user_images/'; // upload directory
	
			$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
		
			// valid image extensions
			$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
		
			// rename uploading image
			$img = rand(1000,1000000).".".$imgExt;
				
			// allow valid image file formats
			if(in_array($imgExt, $valid_extensions)){			
				// Check file size '5MB'
				if($imgSize < 5000000)				{
					move_uploaded_file($tmp_dir,$upload_dir.$img);
				}
				else{
					$errMSG = "Sorry, your file is too large.";
				}
			}
			else{
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
			}
		}
		
		
		// if no error occured, continue ....
		if(!isset($errMSG))
		{
			$stmt = $connection->prepare('INSERT INTO services(serv,infor,proid,modid,img,redate,findate,fin,per,phone) VALUES(:serv, :infor, :proid, :modid, :img, :redate, :findate, :fin, :per, :phone)');
			$stmt->bindParam(':serv',$serv);
			$stmt->bindParam(':infor',$infor);
			$stmt->bindParam(':proid',$proid);
			$stmt->bindParam(':modid',$modid);
			$stmt->bindParam(':img',$img);
			$stmt->bindParam(':redate',$redate);
			$stmt->bindParam(':findate',$findate);
			$stmt->bindParam(':fin',$fin);
			$stmt->bindParam(':per',$per);
			$stmt->bindParam(':phone',$phone);

			if($stmt->execute())
			{
				$successMSG = "new record succesfully inserted ...";
				 // redirects image view page after 5 seconds.
			}
			else
			{
				$errMSG = "error while inserting....";
			}
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="css/backend.css">
	<script>
		$(document).ready(function(){
			$("#slideshow").hide(0000);
			$("#slidebtn").click(function(){
				$("#slideshow").slideToggle(800);
			});
		});

		function sure(){
			confirm("Are you sure?");
		}
	</script>
	<style type="text/css">
		.table-bordered > tbody > tr > td{
			border: 1px solid #A49C9C !important;
		}
	</style>
</head>
<body>
<?php include 'backendmods.php'; ?>


<div class="container paddingch">


	<h2 class="headerback">Services  </h2>
    

	<?php
	if(isset($errMSG)){
			?>
            <div class="alert alert-danger">
            	<span class="glyphicon glyphicon-info-sign"></span> <strong><?php echo $errMSG; ?></strong>
            </div>
            <?php
	}
	else if(isset($successMSG)){
		?>
        <div class="alert alert-success">
              <strong><span class="glyphicon glyphicon-info-sign"></span> <?php echo $successMSG; ?></strong>
        </div>
        <?php
	}
	?>   

<form method="post" enctype="multipart/form-data" class="form-horizontal">
	    
	<table class="table table-bordered table-responsive">
	<tr>
    	<td><label class="control-label">Services Options.</label></td>
        <td>
        	<select name="serv" class="form-control">
        <option value="<?php echo $serv; ?>"><?php echo $serv; ?></option>
        <option value="PCL">PC and Laptop</option>
        <option value="PRI">Printer</option>
        <option value="NET">Network</option>
        <option value="WEB">Web Developing</option>
      
      </select>
        </td>
    </tr>
    <tr>
    	<td><label class="control-label">Imformation of item.</label></td>
        <td><textarea class="form-control"  name="infor" placeholder="Items" rows="5"><?php echo $infor; ?></textarea>
        </td>
    </tr>

    <tr>
    	<td><label class="control-label">product id.</label></td>
        <td><input class="form-control" type="text" name="proid" placeholder="Enter Username" value="<?php echo $proid; ?>" /></td>
    </tr>
    <tr>
    	<td><label class="control-label">Phone no.</label></td>
        <td><input class="form-control" type="text" name="phone" value="<?php echo $phone; ?>"  /></td>
    </tr>

    <tr>
    	<td><label class="control-label">Model id.</label></td>
        <td><input class="form-control" type="text" name="modid" placeholder="Enter Username" value="<?php echo $modid; ?>" /></td>
    </tr>
    <tr>
    	<td><label class="control-label">Resive date.</label></td>
        <td><input class="form-control" type="text" name="redate" placeholder="Enter Username" value="<?php echo $redate; ?>" /></td>
    </tr>
     <tr>
    	<td><label class="control-label">Profile Img.</label></td>
        <td><input class="input-group" type="file" name="img" accept="image/*" /></td>
    </tr>
    
    <tr>
    	<td><label class="control-label">Finish date.</label></td>
        <td><input class="form-control" type="text" name="findate" placeholder="Enter Username" value="<?php echo $findate; ?>" /></td>
    </tr>
    <tr>
    	<td><label class="control-label">Finish.</label></td>
        <td><input class="form-control" type="text" name="fin" placeholder="Enter Username" value="<?php echo $fin; ?>" /></td>
    </tr>
    
    
    <tr>
    	<td><label class="control-label">Percentage</label></td>
    	
        <td><input class="form-control" type="text" name="per" placeholder="Your Profession" value="<?php echo $per; ?>" /></td>
    </tr>
    
    
    <tr>
        <td colspan="2"><button type="submit" name="btnsave" class="btn btn-default">
        <span class="glyphicon glyphicon-save"></span> &nbsp; save
        </button>
        </td>
    </tr>
    
    </table>
    
</form>
</div>
<div class="container">
	<table class="table table-dark">
			<thead>
				<tr class="bgblack">
					<th>For Services op</th>
					<th>Product id</th>
					<th>Phone no</th>
					<th>Photo</th>
					<th>information</th>
					<th>Receive date</th>
					<th>Finish date</th>
					<th>Finish or not</th>
					<th>Percentage</th>
					<th>Model id</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody>
<?php
	
	$stmtr = $connection->prepare('SELECT id, serv, infor, proid, modid, img, redate, findate, fin, per, phone FROM services ORDER BY id DESC');
	$stmtr->execute();
	
	if($stmtr->rowCount() > 0)
	{
		while($row=$stmtr->fetch(PDO::FETCH_ASSOC))
		{
			extract($row);
			?>
			<tr class="success bgwhite">
						<td><?php echo $row['serv']?></td>
						<td><?php echo $row['proid']?></td>
						<td><?php echo $row['phone']?></td>
						<td><img src="user_images/<?php echo $row['img']; ?>" class="img-rounded" width="100px" height="100px" /></td>
						<td><?php echo $row['infor']?></td>
						     
						<td><?php echo $row['redate']?></td>       
						<td><?php echo $row['findate']?></td>
						<td><?php echo $row['fin']?></td>
						<td><?php echo $row['per']?>
							
							<div class="progress">
							  <div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar"
							  aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $row['per']?>%">
							    
							  </div>
							</div>
						</td>
						<td><?php echo $row['modid']?></td>
				<td><a class="btn btn-info" href="editservices.php?edit_id=<?php echo $row['id']; ?>" title="click for edit" onclick="return confirm('sure to edit ?')"><span class="glyphicon glyphicon-edit"></span> Edit</a> </td>
				<td><a class="btn btn-danger" href="?delete_id=<?php echo $row['id']; ?>" title="click for delete" onclick="return confirm('sure to delete ?')"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a></td>
				      
			<?php
		}
	}
	else
	{
		?>
        <td colspan="9">
        	<div class="alert alert-danger" title="hi">
			    <strong>No data have.........</strong> 
			  </div>
        </td>
        <?php
	}
	
?>
</tbody>
</table>
</div>



	


<!-- Latest compiled and minified JavaScript -->
<script src="bootstrap/js/bootstrap.min.js"></script>


</body>
</html>