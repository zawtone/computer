<!DOCTYPE html>
<html>
<head>
	<title>
		chatbox
	</title>
	<style type="">
		
	</style>
</head>
<body style="font-size: 16px; color: white;">
<a href="javascript:void(Tawk_API.toggle())" style="font-size: 16px; color: white;"> Chat Here! </a>


<div id="status"></div>
<!-- cbox -->
<!--Start of tawk.to Status Code-->
<!--Start of tawk.to Status Code-->

<script type="text/javascript">
Tawk_API = Tawk_API || {};
Tawk_API.onStatusChange = function (status){
if(status === 'online')
{
document.getElementById('status').innerHTML = '<a href="javascript:void(Tawk_API.toggle())">Online - Click to chat</a>';
}
else if(status === 'away')
{
document.getElementById('status').innerHTML = 'We are currently away';
}
else if(status === 'offline')
{
document.getElementById('status').innerHTML = 'Live chat is Offline';
}
};
</script>

<!--End of tawk.to Status Code -->
<!--   -->
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5c111e4082491369ba9dce23/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>
</html>