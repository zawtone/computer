<?php
 require_once('database.php');
 $rid = $_GET['rid'];
 
 $res = $database->delete($rid);
 if($res){
 	header('location: backendr.php');
 }else{
 	echo "Failed to Delete Record";
 }
?>