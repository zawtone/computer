<?php
 require_once('database.php');
 $serid = $_GET['serid'];
 
 $res = $database->comdelete($serid);
 if($res){
 	header('location: backendcom.php');
 }else{
 	echo "Failed to Delete Record";
 }
?>