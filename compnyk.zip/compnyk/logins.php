
<div class="container">
  <div class="cfornews-header">
   Admin LOGIN
  </div>
  <form class="cfornews-form cfornews-formcl slideanim" method="POST" action="#">
    <label>အမည္ </label><br>
    <input type="text" name="lname" value="Name" onfocus="this.value='';" onblur="if (this.value == ''){this.value= 'Name';}">
    <br>

    <label>စကား၀ွက္ </label><br>
    <input type="text" name="pass" value="password" onfocus="this.value='';" onblur="if (this.value == ''){this.value= 'password';}">
    <br>
    <button type="submit" name="submit"> ၀င္မည္။<span class="glyphicon glyphicon-new-window"></button>
  </form>
</div>