<?php
require_once('database.php');
require_once 'connection.php';

$res_com = $database->servicesread();
$res_comb = $database->servicesread();
$res_comc = $database->servicesread();
$res_comd = $database->servicesread();

session_start();

$database = new Database(); $id = $_SESSION['id'];
$gi = $database->get_fullname($id);
if (!$database->get_session()){
 header("location:login.php");
}

if(isset($_GET['delete_id']))
  {
    // select image from db to delete
    $stmt_select = $connection->prepare('SELECT img FROM services WHERE id =:id');
    $stmt_select->execute(array(':id'=>$_GET['delete_id']));
    $imgRow=$stmt_select->fetch(PDO::FETCH_ASSOC);
    unlink("user_images/".$imgRow['img']);
    
    // it will delete an actual record from db
    $stmt_delete = $connection->prepare('DELETE FROM services WHERE id =:id');
    $stmt_delete->bindParam(':id',$_GET['delete_id']);
    $stmt_delete->execute();
    
    header("Location: backendcom.php");
  }
?>

<!DOCTYPE html>
<html>
<head>
	<title>backend</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/backend.css">

  <link rel="stylesheet" href="validation/jquery-validation-1.19.0/demo/css/screen.css">
  <script src="validation/jquery-validation-1.19.0/dist/jquery.validate.js"></script>
  <script src="validation/jquery-validation-1.19.0/dist/additional-methods.js"></script>
  <script>
    $(document).ready(function(){
     $("#slideshow").hide(0000);
     $("#slidebtn").click(function(){
      $("#slideshow").slideToggle(800);
    });
   });
    $().ready(function() {
    // validate the comment form when it is submitted
    $("#commentForm").validate();
  });

</script>
</head>
<body>
	<?php include 'backendmods.php'; ?>
  <!-- nenu -->


  <div class="container paddingch">
    <h2 class="headerback">Desktop and Laptop services </h2>

    <table class="table table-dark">
      <thead>
        <tr class="bgblack">
          <th>For Services op</th>
          <th>Product id</th>
          <th>Phone no</th>
          <th>Photo</th>
          <th>information</th>
          <th>Receive date</th>
          <th>Finish date</th>
          <th>Finish or not</th>
          <th>Percentage</th>
          <th>Model id</th>
          <th>Edit</th>
          <th>Delete</th>
        </tr>
      </thead>
      <tbody>
         <?php 

            while($a = mysqli_fetch_assoc($res_com)){    
               $aa = 'PCL';
            while($aa == $a['serv']){
          ?>

           <tr class="success">
             <td><?php echo $a['serv']?></td>
            <td><?php echo $a['proid']?></td>
            <td><?php echo $a['phone']?></td>
            <td><img src="user_images/<?php echo $a['img']; ?>" class="img-rounded" width="100px" height="100px" /></td>
            <td><?php echo $a['infor']?></td>
                 
            <td><?php echo $a['redate']?></td>       
            <td><?php echo $a['findate']?></td>
            <td><?php echo $a['fin']?></td>
            <td><?php echo $a['per']?>
              <div class="progress">
                <div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar"
                aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $a['per']?>%">
                  
                </div>
              </div>
            </td>
            <td><?php echo $a['modid']?></td>
             <td>
              <?php 
              $g = '1QwiYiip123Foho';
              if($g == $gi['idname']){
                ?>                  
                <a class="btn btn-info" href="editservicesnext.php?edit_id=<?php echo $a['id']; ?>" title="click for edit" onclick="return confirm('sure to edit ?')"><span class="glyphicon glyphicon-edit"></span> Edit</a>
                <?php
              }else{
                ?>  
                <p style="color: red;"> 
                  you con't edit
                </p>

                <?php
              }
              ?></td>
              <td>
               <?php 
               $g = '1QwiYiip123Foho';
               if($g == $gi['idname']){
                ?>                  
                <a class="btn btn-danger" href="?delete_id=<?php echo $a['id']; ?>" title="click for delete" onclick="return confirm('sure to delete ?')"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a>
                <?php
              }else{
                ?>  
                <p style="color: red;"> 
                  you con't delete
                </p>

                <?php
              }
              ?></td>

            </tr>
            <?php $aa++;
          }
          }
          ?>

        </tbody>


      </table>
    
  </div>

  <!-- printer -->
   <div class="container paddingch">
    <h2 class="headerback">Printer services </h2>

    <table class="table table-dark">
      <thead>
        <tr class="bgblack">
          <th>For Services op</th>
          <th>Product id</th>
          <th>Phone no</th>
          <th>Photo</th>
          <th>information</th>
          <th>Receive date</th>
          <th>Finish date</th>
          <th>Finish or not</th>
          <th>Percentage</th>
          <th>Model id</th>
          <th>Edit</th>
          <th>Delete</th>
        </tr>
      </thead>
      <tbody>
         <?php 

            while($ab = mysqli_fetch_assoc($res_comb)){    
               $aab = 'PRI';
            while($aab == $ab['serv']){
          ?>

           <tr class="success">
             <td><?php echo $ab['serv']?></td>
            <td><?php echo $ab['proid']?></td>
            <td><?php echo $ab['phone']?></td>
            <td><img src="user_images/<?php echo $ab['img']; ?>" class="img-rounded" width="100px" height="100px" /></td>
            <td><?php echo $ab['infor']?></td>
                 
            <td><?php echo $ab['redate']?></td>       
            <td><?php echo $ab['findate']?></td>
            <td><?php echo $ab['fin']?></td>
            <td><?php echo $ab['per']?>
              <div class="progress">
                <div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar"
                aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $ab['per']?>%">
                  
                </div>
              </div>
            </td>
            <td><?php echo $ab['modid']?></td>
             <td>
              <?php 
              $g = '1QwiYiip123Foho';
              if($g == $gi['idname']){
                ?>                  
               <a class="btn btn-info" href="editservicesnext.php?edit_id=<?php echo $ab['id']; ?>" title="click for edit" onclick="return confirm('sure to edit ?')"><span class="glyphicon glyphicon-edit"></span> Edit</a>
                <?php
              }else{
                ?>  
                <p style="color: red;"> 
                  you con't edit
                </p>

                <?php
              }
              ?></td>
              <td>
               <?php 
               $g = '1QwiYiip123Foho';
               if($g == $gi['idname']){
                ?>                  
                <a class="btn btn-danger" href="?delete_id=<?php echo $ab['id']; ?>" title="click for delete" onclick="return confirm('sure to delete ?')"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a>
                <?php
              }else{
                ?>  
                <p style="color: red;"> 
                  you con't delete
                </p>

                <?php
              }
              ?></td>

            </tr>
            <?php $aab++;
          }
          }
          ?>

        </tbody>


      </table>
    
  </div>

  <!-- network -->
  <div class="container paddingch">
    <h2 class="headerback">Network services </h2>

    <table class="table table-dark">
      <thead>
        <tr class="bgblack">
          <th>For Services op</th>
          <th>Product id</th>
          <th>Phone no</th>
          <th>Photo</th>
          <th>information</th>
          <th>Receive date</th>
          <th>Finish date</th>
          <th>Finish or not</th>
          <th>Percentage</th>
          <th>Model id</th>
          <th>Edit</th>
          <th>Delete</th>
        </tr>
      </thead>
      <tbody>
         <?php 

            while($ac = mysqli_fetch_assoc($res_comc)){    
               $aac = 'NET';
            while($aac == $ac['serv']){
          ?>

           <tr class="success">
             <td><?php echo $ac['serv']?></td>
            <td><?php echo $ac['proid']?></td>
            <td><?php echo $ac['phone']?></td>
            <td><img src="user_images/<?php echo $ac['img']; ?>" class="img-rounded" width="100px" height="100px" /></td>
            <td><?php echo $ac['infor']?></td>
                 
            <td><?php echo $ac['redate']?></td>       
            <td><?php echo $ac['findate']?></td>
            <td><?php echo $ac['fin']?></td>
            <td><?php echo $ac['per']?>
              <div class="progress">
                <div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar"
                aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $ac['per']?>%">
                  
                </div>
              </div>
            </td>
            <td><?php echo $ac['modid']?></td>
             <td>
              <?php 
              $g = '1QwiYiip123Foho';
              if($g == $gi['idname']){
                ?>                  
                <a class="btn btn-info" href="editservicesnext.php?edit_id=<?php echo $ac['id']; ?>" title="click for edit" onclick="return confirm('sure to edit ?')"><span class="glyphicon glyphicon-edit"></span> Edit</a>
                <?php
              }else{
                ?>  
                <p style="color: red;"> 
                  you con't edit
                </p>

                <?php
              }
              ?></td>
              <td>
               <?php 
               $g = '1QwiYiip123Foho';
               if($g == $gi['idname']){
                ?>                  
                <a class="btn btn-danger" href="?delete_id=<?php echo $ac['id']; ?>" title="click for delete" onclick="return confirm('sure to delete ?')"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a>
                <?php
              }else{
                ?>  
                <p style="color: red;"> 
                  you con't delete
                </p>

                <?php
              }
              ?></td>

            </tr>
            <?php $aac++;
          }
          }
          ?>

        </tbody>


      </table>
    
  </div>


  <!-- web developing -->
  <div class="container paddingch">
    <h2 class="headerback">Web Developing services </h2>

    <table class="table table-dark">
      <thead>
        <tr class="bgblack">
          <th>For Services op</th>
          <th>Product id</th>
          <th>Phone no</th>
          <th>Photo</th>
          <th>information</th>
          <th>Receive date</th>
          <th>Finish date</th>
          <th>Finish or not</th>
          <th>Percentage</th>
          <th>Model id</th>
          <th>Edit</th>
          <th>Delete</th>
        </tr>
      </thead>
      <tbody>
         <?php 

            while($ad = mysqli_fetch_assoc($res_comd)){    
               $aad = 'PCL';
            while($aad == $ad['serv']){
          ?>

           <tr class="success">
             <td><?php echo $ad['serv']?></td>
            <td><?php echo $ad['proid']?></td>
            <td><?php echo $ad['phone']?></td>
            <td><img src="user_images/<?php echo $ad['img']; ?>" class="img-rounded" width="100px" height="100px" /></td>
            <td><?php echo $ad['infor']?></td>
                 
            <td><?php echo $ad['redate']?></td>       
            <td><?php echo $ad['findate']?></td>
            <td><?php echo $ad['fin']?></td>
            <td><?php echo $ad['per']?>
              <div class="progress">
                <div class="progress-bar progress-bar-info progress-bar-striped" role="progressbar"
                aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $ad['per']?>%">
                  
                </div>
              </div>
            </td>
            <td><?php echo $ad['modid']?></td>
             <td>
              <?php 
              $g = '1QwiYiip123Foho';
              if($g == $gi['idname']){
                ?>                  
                <a class="btn btn-info" href="editservicesnext.php?edit_id=<?php echo $ad['id']; ?>" title="click for edit" onclick="return confirm('sure to edit ?')"><span class="glyphicon glyphicon-edit"></span> Edit</a>
                <?php
              }else{
                ?>  
                <p style="color: red;"> 
                  you con't edit
                </p>

                <?php
              }
              ?></td>
              <td>
               <?php 
               $g = '1QwiYiip123Foho';
               if($g == $gi['idname']){
                ?>                  
                <a class="btn btn-danger" href="?delete_id=<?php echo $ad['id']; ?>" title="click for delete" onclick="return confirm('sure to delete ?')"><span class="glyphicon glyphicon-remove-circle"></span> Delete</a>
                <?php
              }else{
                ?>  
                <p style="color: red;"> 
                  you con't delete
                </p>

                <?php
              }
              ?></td>

            </tr>
            <?php $aad++;
          }
          }
          ?>

        </tbody>


      </table>
    
  </div>
</body>
</html>