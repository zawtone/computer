<?php
require_once('database.php');

session_start();

$database = new Database(); $rid = $_SESSION['rid'];
if (!$database->sget_session()){
 header("location:slogin.php");
}

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>student</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/studentprf.css">
</head>
<body>
	
<div class="logut">
	
	<a href="logout.php">
		<button class="btn btn-danger">
		LOGout
	</button></a>
</div>
<div class="innermarquee">
  <marquee direction="left" class="marquee-1"><p>မဂၤလာပါ! <?php $database->sget_fullname($rid); ?> ပညာရင္​ခြင္​ ကြန္​ပ်ဴတာ သင္​တန္​း သင္​တန္​းသား/သူ ​​ေရးရာ page မွႀကိဳဆိုပါတယ္​</p></marquee>
  
	

</div>
<div class="container">
	
  <div class="alert alert-success">
    <strong>Setion!</strong> &nbsp; <?php $database->sget_fullname($rid); ?>
  </div>
  <div class="alert alert-info">
    <strong>အမည္!</strong>  &nbsp;<?php $database->ssget_fullname($rid); ?>
  </div>
  <div class="alert alert-danger">
    <strong>သင္​တန္​းအပတ္​စဥ္!</strong> &nbsp;<?php $database->sssget_fullname($rid); ?>
  </div>
</div>
<div>
	<div class="headerabout-sub">
		အေၾကာင္းအရာ
	</div>
	
		<p class="text-sub-inner">
			ဤ​ေနရာတြင္​ သင္​တန္​းသား သင္​တန္​းသူတို႔အတြက္​ အသံုးဝင္​မည္​့ ကြန္​ပ်ဴတာ Level အဆင္​့လိုက္​ စာအုပ္​မ်ားကို ​ေဖာ္​ျပ​ေပးထားပါသည္​။ 
			<br><br>

		သင္​တန္​းသူသင္​တန္​းသားတို႔အ​​ေနျဖင့္​စာအုပ္​စာရြက္​မ်ား ​ေပ်ာက္​သြား၍​ေသာ္​လည္​း​ေကာင္​း၊ လိုအပ္​၍​ေသာလည္​း​ေကာင္​း လာေရာက္ေလ့လာနိူင္ပါသည္။
<br><br>
		သင္​တန္​းသူသင္​တန္​းသားတို႔အ​ေနနဲ႔ ကြၽန္​​ေတာ္​တို႔ Pageအတြက္​ အၾကံျပဳခ်က္​မ်ားကို ​ေရးသား​ေပး​ေစလိုပါသည္​။
<br><br>
		သို႔မွသာ ကြၽန္​​ေတာ္​တို႔page၏ လိုအပ္​ခ်က္​မ်ားကို ထပ္​မံျဖည္​့စြက္​ႏိုင္​မည္​ ျဖစ္​သည္​။
<br><br><br>
		
			
				<button type="button" class="btn btn-primary" data-toggle="collapse" data-target="#comment-student-id">အၾကံျပဳစာေရးရန္</button>
				<div class="container comment-student collapse" id="comment-student-id">
					
						
					
					<form role="form" method="post">
		
						<div class="form-group">
							<label for="item" style="color: white;">သင္​တန္​းသူသင္​တန္​းသားတို႔အ​​ေနျဖင့္​စာအုပ္​စာရြက္​မ်ား ​ေပ်ာက္​သြား၍​ေသာ္​လည္​း​ေကာင္​း၊ လိုအပ္​၍​ေသာလည္​း​ေကာင္​း လာေရာက္ေလ့လာနိူင္ပါသည္။</label>
							<textarea class="form-control" id="comments" name="exitem" placeholder="အၾကံျပဳစာ" rows="5"></textarea><br>
						</div>
						
						<div class="row">
				        <div class="col-sm-12 form-group">
				          <button class="btn btn-default pull-right" type="submit">Sent</button>
				        </div>
				      </div>
					</form>
				</div>
		</p>  
		
		
</div>


<div class="rs-box-whole">
	<div class="rs-box-inner">
		<a href="pdfbasic.php">
		<div style="background-image: url(pics/basic.jpg)">
			
		</div>
		</a>
		<a href="pdfbasic.html">
		<p>
			Basic
		</p>
		</a>
	</div>
	<div class="rs-box-inner">
		<a href="">
		<div style="background-image: url(pics/dtp.jpg)">
			
		</div>
		</a>
		<a href="">
		<p>
			DTP
		</p>
		</a>
	</div>
	<div class="rs-box-inner">
		<a href="">
		<div  style="background-image: url(pics/ps.jpg)">
			
		</div>
		</a>
		<a href="">
		<p>
			Photoshop
		</p>
		</a>
	</div>
	<div class="rs-box-inner">
		<a href="">
		<div  style="background-image: url(pics/basic.jpg)">
			
		</div>
		</a>
		<a href="">
		<p>
			Basic
		</p>
		</a>
	</div>
</div>
<div class="rs-box-whole">
	<div class="rs-box-inner">
		<a href="">
		<div style="background-image: url(pics/basic.jpg)">
			
		</div>
		</a>
		<a href="">
		<p>
			Basic
		</p>
		</a>
	</div>
	<div class="rs-box-inner">
		<a href="">
		<div style="background-image: url(pics/basic.jpg)">
			
		</div>
		</a>
		<a href="">
		<p>
			Basic
		</p>
		</a>
	</div>
	<div class="rs-box-inner">
		<a href="">
		<div style="background-image: url(pics/basic.jpg)">
			
		</div>
		</a>
		<a href="">
		<p>
			Basic
		</p>
		</a>
	</div>
	<div class="rs-box-inner">
		<a href="">
		<div style="background-image: url(pics/basic.jpg)">
			
		</div>
		</a>
		<a href="">
		<p>
			Basic
		</p>
		</a>
	</div>
</div>
</body>
</html>