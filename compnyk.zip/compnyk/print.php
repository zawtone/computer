
<?php
 require_once('database.php');
 $rid = $_GET['rid'];
 $ed = $database->read($rid);
 $e = mysqli_fetch_assoc($ed);
 session_start();

$database = new Database(); $id = $_SESSION['id'];
if (!$database->get_session()){
 header("location:index.php");
}


?>

<!DOCTYPE html>
<html>
<head>
	<title>
		print
	</title>
	<meta   charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script>
function myFunction() {
    window.print();
}
</script>
	<style type="text/css">
	.for-whole-print {
    width: 80%;
    margin-left: auto;
    margin-right: auto;
    margin-top: 30px;
    height: auto;
    display: block;
}
.row div{
	margin-top: 20px !important;
	
}
.stole div{
	margin-top:5px !important;
	margin-bottom: 0px;
}
.footer-theprint-1{
	width: 80%;
    margin-left: auto;
    margin-right: auto;
    margin-top: 30px;
    margin-bottom: -25px;
}
	.front-box{

	 width: 240px;
    font-family: Bodoni MT;
    padding: 7px;
    font-size: 14px;
    display: block;
    float: left;
margin-top: 5px;
		}
		.back-box{
			font-family: Bodoni MT;
			width: 625px;
display: block;
float: left;
border-left: 3px solid #E4E4E4;
margin-top: 4px;
padding: 12px;
font-size: 15px;
min-height: 45px;
padding-left: 21px;
		}
.box-holder{
	width: 866px;
margin-left: auto;
margin-right: auto;
}



	</style>
</head>
<body>
	<div class="print-btn">
		<button onclick="myFunction()" style="float: right;"><span class="glyphicon glyphicon-print"></span></button>
	</div>
	<div class="container">	
 <img src="pics/print1.jpg" class="img-responsive" alt="Cinque Terre" width="40%" height="300" style="margin-left: auto;
 margin-right: auto;">
        
</div>
<div class="for-whole-print">
	<!-- inner box -->
	<div class="box-holder">
		<div class="front-box">
			NAME:
		</div>
		<div class="back-box">
			&nbsp;<?php echo $e['name'] ?>
		</div>
	</div>
	<div class="box-holder">
		<div class="front-box">
			FATHER NAME:
		</div>
		<div class="back-box">
			&nbsp;<?php echo $e['fname'] ?>
		</div>
	</div>

<div class="box-holder">
		<div class="front-box">
			DATE OF BIRTH:
		</div>
		<div class="back-box">
			&nbsp;<?php echo $e['dofb'] ?>
		</div>
	</div>

<div class="box-holder">
		<div class="front-box">
			NRC NO:
		</div>
		<div class="back-box">
			&nbsp;<?php echo $e['nrcno'] ?>
		</div>
	</div>

<div class="box-holder">
		<div class="front-box">
			EDUCATIONAL QUALIFICATION:
		</div>
		<div class="back-box">
			&nbsp;<?php echo $e['edu'] ?>
		</div>
	</div>

<div class="box-holder">
		<div class="front-box">
			OCCUPATION:
		</div>
		<div class="back-box">
			&nbsp;<?php echo $e['occ'] ?>
		</div>
	</div>

<div class="box-holder">
		<div class="front-box">
			COMPUTER EXPERIENCE:
		</div>
		<div class="back-box">
			&nbsp;<?php echo $e['computer'] ?>
		</div>
	</div>

<div class="box-holder">
		<div class="front-box">
			PHONE:
		</div>
		<div class="back-box">
			&nbsp;<?php echo $e['phone'] ?>
		</div>
	</div>

<div class="box-holder">
		<div class="front-box">
			RESIDENTIAL ADDRESS:
		</div>
		<div class="back-box">
			&nbsp;<?php echo $e['address'] ?>
		</div>
	</div>
</div>




<div class="footer-theprint-1">
	<div class="row">
		<div class="col-sm-4">
			<div style="width: 1in; height:1in; border: 5px solid black; margin-left: auto; margin-right: auto; text-align: center; padding-top: 35px; font-size: 11px; margin-bottom: 32px;">
				photo
			</div>
		</div>
		<div class="col-sm-4">
			<img src="pics/logopnyk.jpg" class="img-responsive" alt="Cinque Terre" width="40%" height="305" style="margin-left: 70px;">
		</div>
		<div class="col-sm-4">
			<div style="width: 175px;
height: 30px;">
				<div style="display: block; float: left;">
					SIGNATURE:
				</div>
				<div style="border-bottom: 2px dotted black; display: block; float: left; width: 91px;
height: 20px;">
					
				</div>
			</div>
			<div style="width: 175px;
height: 30px;">
				<div style="display: block; float: left;">
					DATE:
				</div>
				<div style="border-bottom: 2px dotted black; display: block; float: left; width: 132px;
height: 20px; ">
					
				</div>
			</div>


		</div>
	</div>
</div>


<div class="footer-theprint-1">
	<div style="border-top: 5px double black; padding-top: 8px;">
		OFFIC ONLY
	</div>
	<div class="row stole">
		<div class="col-sm-4">
			<div style="width: 195px;
height: 30px;">
				<div style="display: block; float: left;">
					BATCH:
				</div>
				<div style="border-bottom: 2px dotted black; display: block; float: left; width: 132px;
height: 20px; ">
					
				</div>
			</div>


		</div>
		<div class="col-sm-4">
			<div style="width: 175px;
height: 30px;">
				<div style="display: block; float: left;">
					COURSE:
				</div>
				<div style="border-bottom: 2px dotted black; display: block; float: left; width: 91px;
height: 20px;">
					
				</div>
			</div>

		</div>


		<div class="col-sm-4">
			<div style="width: 175px;
height: 30px;">
				<div style="display: block; float: left;">
					FEES:
				</div>
				<div style="border-bottom: 2px dotted black; display: block; float: left; width: 91px;
height: 20px;">
					
				</div>
			</div>
		</div>

		
	</div>
</div>
</body>
</html>