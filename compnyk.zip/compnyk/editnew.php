<?php
 require_once('database.php');
 $neid = $_GET['neid'];
 $ed = $database->newsreaded($neid);
 $e = mysqli_fetch_assoc($ed);
 if(isset($_POST) & !empty($_POST)){
     $dfn = $database->sanitize($_POST['dfn']);
     $mini = $database->sanitize($_POST['mini']);
     $whole = $database->sanitize($_POST['whole']);
     $test = $database->sanitize($_POST['test']);
     $onet = $database->sanitize($_POST['onet']);
     $onep = $database->sanitize($_POST['onep']);
     $twot = $database->sanitize($_POST['twot']);
     $twop = $database->sanitize($_POST['twop']);
     $threet = $database->sanitize($_POST['threet']);
     $threep = $database->sanitize($_POST['threep']);
     $fourt = $database->sanitize($_POST['fourt']);
     $fourp = $database->sanitize($_POST['fourp']);
     $fivet = $database->sanitize($_POST['fivet']);
     $fivep = $database->sanitize($_POST['fivep']);
     $sixt = $database->sanitize($_POST['sixt']);
     $sixp = $database->sanitize($_POST['sixp']);
     $modid = $database->sanitize($_POST['modid']);
     $newmod = $database->sanitize($_POST['newmod']);
     
    $ress = $database->newsupdate($dfn,$mini,$whole,$test,$onet,$onep,$twot,$twop,$threet,$threep,$fourt,$fourp,$fivet,$fivep,$sixt,$sixp,$modid,$newmod, $neid);
    if($ress){
        header("location:backendnew.php");
    }else{
        echo "failed to update data";
    }
}




?>

<!DOCTYPE html>
<html>
<head>
	<title>
		edit
	</title>
	<title>
		sms admin
	</title>
	<meta   charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/selete.js"></script>
	<script>
		function cho(){
		var a=document.getElementById('choose').value;
		document.getElementById('responed').value= ""+a;

}
function choone(){
		var a=document.getElementById('chooseone').value;
		document.getElementById('responedone').value= ""+a;

}
function chotwo(){
		var a=document.getElementById('choosetwo').value;
		document.getElementById('responedtwo').value= ""+a;

}
function chothree(){
		var a=document.getElementById('choosethree').value;
		document.getElementById('responedthree').value= ""+a;

}
function chofour(){
		var a=document.getElementById('choosefour').value;
		document.getElementById('responedfour').value= ""+a;

}
function chofive(){
		var a=document.getElementById('choosefive').value;
		document.getElementById('responedfive').value= ""+a;

}
function chosix(){
		var a=document.getElementById('choosesix').value;
		document.getElementById('responedsix').value= ""+a;

}
function chonon(){
		var a=document.getElementById('choosenon').value;
		document.getElementById('responednon').value= ""+a;

}
	</script>
	<style type="text/css">
		.navbarfor-new{
	border-radius: 0px !important;
}
body {
 background-color: #5A5959;
	background-size: cover;
	background-position: top;
}
/*==*/
	.whole1{
			width: 250px;
			height: 50px;
			background-color: #00F;
			display: flex;	
			opacity: 0.5;
		}
		.inner-back1{
			width: 240px;
			height: 40px;
			margin-top: 5px;
			margin-left: 5px;
			background-color: white;
		}
		.inner-one1{
			width: 230px;
			height: 30px;
			margin-top: 5px;
			margin-left: 5px;
			background-color: blue;
		}
		.logo{
			width: 230px;
			height: 30px;
			font-size: 28px;
			padding-top: 7px;
			text-align: center;
			color: white;
			text-shadow: 1px 1px 3px black;
			position: relative;
			font-family: Algerian;
			margin-top: -42px;
		}

/*==*/
.data-back{
	width: 125px;
	height: 30px;
	border-radius: 15px;
	border: 3px solid #C9C9C9;
	color: white;
	text-align: center;
	box-shadow: 1px 1px 3px #C9C9C9;
}
.data-back:hover{
	background-color: #E1DADA;
	text-decoration: none;
	color: #6C6969;
}


.row-new{
	margin-right: 0px !important;
	margin-left: 0px !important;
}
.navbar-inverse{
	background-color: transparent;
	border: 0px !important;
}
.form-footer{
	width: 100%;
	height: auto;
	float: right;
	box-shadow: 1px 1px 6px black;
	border-left: 5px solid white;
}
.undefine li{
	list-style: none;
	margin-top: 20px;
}
.undefine {
	margin-left: -25px !important;
}
.form-footer h1{
	color: #E7E4E4;
}
label{
	color: #E7E4E4;
}
.drop{
	background-color: transparent !important;
}
.action:hover{
	background-color: transparent !important;
}
.action:focus{
	background-color: transparent !important;
}

.logins{
	margin-top: 10px !important;
}
.drop li a{
	color: #E7E4E4;
}
.buttton{
	opacity: 0.8;
	width: 100px;
	margin-bottom: 30px;
}
.data-link{
	color: white !important;
}
.data-link:hover{
	color: blue !important;
	text-decoration: none;
}
.navbar-brand{
	padding: 0px !important;
}
.whiteforth{
	color: white;
}
	</style>
</head>
<body>
<div class="container form-footer tab-pane fade in active" id="home">
			<h1>Student Registeration !</h1>
			<form role="form" method="post">
				<div class="form-group">
			      <label for="email">Date of news(also text eg(full mooom of---))</label>
			      <input name="dfn" type="text" class="form-control" value="<?php echo $e['dfn'] ?>" >
			    </div>
			    <div class="form-group">
			      <label for="email">for read more text:</label>
			      <input name="mini" type="text" class="form-control" value="<?php echo $e['mini'] ?>" >
			    </div>
			    <div class="form-group">
			      <label for="pwd">full text</label>
			      <input name="whole" type="text" class="form-control" value="<?php echo $e['whole'] ?>">
			    </div>

			    <div class="form-group">
			      <label for="pwd">read more photo(image name(.file extention))</label>
			      
			      <input type="text" class="form-control " name="test" id="responed" value="<?php echo $e['test'] ?>">
                            
                <select id="choose"  onchange="cho()"  >                  
                  <?php          
                    $files = glob("uploads/*.*");
                     foreach ($files as $file) {
                        echo "<option value='$file'>";
                        echo "$file";
                        echo "</option>";
                  }?>
                </select> 
			    </div>
			    <!-- one -->
			    <div class="panel panel-default">
				    <div class="panel-heading">
				    	<div class="form-group">
					      <label for="pwd">image discation</label>
					      <input name="onet" type="text" class="form-control" value="<?php echo $e['onet'] ?>">
					    </div>
				    </div>
				    <div class="panel-body">
				    	<div class="form-group">
					      <label for="pwd">image name(.file extention)</label>
					     
					      <input type="text" class="form-control " name="onep" id="responedone" value="<?php echo $e['onep'] ?>">
                            
                <select id="chooseone"  onchange="choone()"   >                  
                  <?php          
                    $files = glob("uploads/*.*");
                     foreach ($files as $file) {
                        echo "<option  value='$file'>";
                        echo "$file";
                        echo "</option>";
                  }?>
                </select>
					    </div>
				    </div>
				  </div>

				  <!-- one -->
			    <div class="panel panel-default">
				    <div class="panel-heading">
				    	<div class="form-group">
					      <label for="pwd">image discation</label>
					      <input name="twot" type="text" class="form-control" value="<?php echo $e['twot'] ?>">
					    </div>
				    </div>
				    <div class="panel-body">
				    	<div class="form-group">
					      <label for="pwd">image name(.file extention)</label>
					      
					      <input type="text" class="form-control " name="twop" id="responedtwo" value="<?php echo $e['twop'] ?>">
                            
                <select id="choosetwo"  onchange="chotwo()"  >                  
                  <?php          
                    $files = glob("uploads/*.*");
                     foreach ($files as $file) {
                        echo "<option value='$file'>";
                        echo "$file";
                        echo "</option>";
                  }?>
                </select>
					    </div>
				    </div>
				  </div>

				  <!-- one -->
			    <div class="panel panel-default">
				    <div class="panel-heading">
				    	<div class="form-group">
					      <label for="pwd">image discation</label>
					      <input name="threet" type="text" class="form-control" value="<?php echo $e['threet'] ?>">
					    </div>
				    </div>
				    <div class="panel-body">
				    	<div class="form-group">
					      <label for="pwd">image name(.file extention)</label>
					      
					      <input type="text" class="form-control " name="threep" id="responedthree" value="<?php echo $e['threep'] ?>">
                            
                <select id="choosethree"  onchange="chothree()"  >                  
                  <?php          
                    $files = glob("uploads/*.*");
                     foreach ($files as $file) {
                        echo "<option value='$file'>";
                        echo "$file";
                        echo "</option>";
                  }?>
                </select>
					    </div>
				    </div>
				  </div>

				  <!-- one -->
			    <div class="panel panel-default">
				    <div class="panel-heading">
				    	<div class="form-group">
					      <label for="pwd">image discation</label>
					      <input name="fourt" type="text" class="form-control" value="<?php echo $e['fourt'] ?>">
					    </div>
				    </div>
				    <div class="panel-body">
				    	<div class="form-group">
					      <label for="pwd">image name(.file extention)</label>
					      
					      <input type="text" class="form-control " name="fourp" id="responedfour" value="<?php echo $e['fourp'] ?>">
                            
                <select id="choosefour"  onchange="chofour()"  >                  
                  <?php          
                    $files = glob("uploads/*.*");
                     foreach ($files as $file) {
                        echo "<option value='$file'>";
                        echo "$file";
                        echo "</option>";
                  }?>
                </select> 
					    </div>
				    </div>
				  </div>

				  <!-- one -->
			    <div class="panel panel-default">
				    <div class="panel-heading">
				    	<div class="form-group">
					      <label for="pwd">image discation</label>
					      <input name="fivet" type="text" class="form-control" value="<?php echo $e['fivet'] ?>">
					    </div>
				    </div>
				    <div class="panel-body">
				    	<div class="form-group">
					      <label for="pwd">image name(.file extention)</label>
					      
					      <input type="text" class="form-control " name="fivep" id="responedfive" value="<?php echo $e['fivep'] ?>">
                            
                <select id="choosefive"  onchange="chofive()"  >                  
                  <?php          
                    $files = glob("uploads/*.*");
                     foreach ($files as $file) {
                        echo "<option value='$file'>";
                        echo "$file";
                        echo "</option>";
                  }?>
                </select> 
					    </div>
				    </div>
				  </div>

				  <!-- one -->
			    <div class="panel panel-default">
				    <div class="panel-heading">
				    	<div class="form-group">
					      <label for="pwd">image discation</label>
					      <input name="sixt" type="text" class="form-control" value="<?php echo $e['sixt'] ?>">
					    </div>
				    </div>
				    <div class="panel-body">
				    	<div class="form-group">
					      <label for="pwd">image name(.file extention)</label>
					      
					      <input type="text" class="form-control " name="sixp" id="responedsix" value="<?php echo $e['sixp'] ?>">
                            
                <select id="choosesix"  onchange="chosix()"  >                  
                  <?php          
                    $files = glob("uploads/*.*");
                     foreach ($files as $file) {
                        echo "<option value='$file'>";
                        echo "$file";
                        echo "</option>";
                  }?>
                </select> 
					    </div>
				    </div>
				  </div>


			    <div class="form-group">
			      <label for="pwd">plz put number not same </label>
			      <input name="modid" type="text" class="form-control" value="<?php echo $e['modid'] ?>">
			    </div>
			    <input type="text" name="newmod" class="form-control" id="responednon" value="<?php echo $e['newmod'] ?>">
			    
			    <button type="submit" class="btn btn-primary buttton" >Submit</button>
			</form>

			<select id="choosenon" onchange="chonon()">
		<option value="visibility:hidden">No New mode</option>
		<option value="visibility:visible">New mode</option>
		
	</select>
		</div>
</body>
</html>