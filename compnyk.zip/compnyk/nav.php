<nav class="navbar navbar-inverse navbar-inverse navbar-inverse nav_change navbar-fixed-top forjq-show" style="font-family: Zawgyi-One;">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle querylink-togg" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand lastchage querlinklogo-name" href="http://localhost/compnyk" >ပညာရင္ခြင္ ကြန္ျပဴတာသင္တန္း</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="actives"><a class="lastchage" href="http://localhost/compnyk">Home</a></li>
        


        <li class="actives1">
          <a class="lastchage" href="http://localhost/compnyk/comment.php">
        အၾကံျပဳ ခၽက္
      </a>
    </li>

       

        <li class="dropdown">
          <a class="dropdown-toggle lastchage" data-toggle="dropdown" href="#">သင္ခန္းစာမ်ား<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="#"  data-toggle="modal" data-target="#myModal">Basic</a></li>
            <li><a href="#" data-toggle="modal" data-target="#myModal2">DTP</a></li>
            <li><a href="#" data-toggle="modal" data-target="#myModal3">Graphic Design</a></li>
            <li><a href="#" data-toggle="modal" data-target="#myModal4">Pratical A+</a></li>
            <li><a href="#" data-toggle="modal" data-target="#myModal5">Video EditingVideo Editing</a></li>
            <li><a href="#" data-toggle="modal" data-target="#myModal6">Website Design</a></li>
            <li><a href="#" data-toggle="modal" data-target="#myModal7">Website Developing</a></li>
            <li><a href="#" data-toggle="modal" data-target="#myModal8">Website Developing</a></li>
            <li><a href="#" data-toggle="modal" data-target="#myModal9">HR / Admin Basic Course</a></li>
          </ul>
        </li>



        <li class="actives3"><a class="lastchage" href="http://localhost/compnyk/about.php">
          About us
        </a>
      </li>


      

      <li class="actives5"><a class="lastchage" href="http://localhost/compnyk/service.php">
          Our service
        </a>
      </li>

    </ul>
    <ul class="nav navbar-nav navbar-right">
         <li class="actives2">
          <a class="lastchage" href="http://localhost/compnyk/register.php">
          စာရင္းသြင္းျခင္း
        </a>
      </li>

        <li class="dropdown actives4">
        <a class="lastchage" class="dropdown-toggle " data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-log-in"></span>
          login
          <span class="caret">  
          </span>
        </a>
        <ul class="dropdown-menu">
          <li>
            <a href="http://localhost/compnyk/slogin.php" >
              Student Login
            </a>
          </li>
          <li>
            <a href="http://localhost/compnyk/login.php" >Admin Login
            </a>
          </li>           
        </ul>
      </li>
    </ul>

  </div>
</div>
</nav>