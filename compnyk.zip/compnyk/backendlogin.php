<?php
require_once('database.php');

$logins = $database->loginread();
session_start();
$database = new Database(); $id = $_SESSION['id'];
$gi = $database->get_fullname($id);
if (!$database->get_session()){
 header("location:login.php");
}
 if(isset($_POST) & !empty($_POST)){
     $lname = $database->sanitize($_POST['lname']);
     $pass = $database->sanitize($_POST['pass']);
     $idname = $database->sanitize($_POST['idname']);
    
    

     $res = $database->loigncreate($lname,$pass,$idname);
     if($res){
        header("location:backendlogin.php");
     }else{
        echo "failed to insert data";
     }
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>backend</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" href="css/backend.css">
<script>
$(document).ready(function(){
	$("#slideshow").hide(0000);
    $("#slidebtn").click(function(){
        $("#slideshow").slideToggle(800);
    });
});

</script>
</head>
<body>
	<?php include 'backendmods.php'; ?>
	

						<?php 
                        $g = '1QwiYiip123Foho';
                        if($g == $gi['idname']){
                          ?>
		<div class="container paddingch">
			<h2 class="headerback">Admin Login </h2>
			<form role="form" method="post" class="bgform">
				<div class="form-group">
			      <label for="email">User name</label>
			      <input name="lname" type="text" class="form-control"  >
			    </div>
			    <div class="form-group">
			      <label for="email">Password</label>
			      <input name="pass" type="text" class="form-control"  >
			    </div>
			    <div class="form-group">
			      <label for="pwd">admin code def(1QwiYiip123Foho)</label>
			      <input name="idname" type="text" class="form-control" >
			    </div>
			    <input type="submit" class="btn btn-default" value="submits">
			</form>
			<h2 class="headerback">Login Pass And Username</h2>
             
  <table class="table table-dark">
    <thead>
      <tr class="bgblack">
      	<th>no#</th>
        <th>id#</th>
        <th>Date</th>
        <th>Item</th>
        <th>edit</th>
        <th>delete</th>
        
      </tr>
    </thead>
    <tbody>
      			<?php 
      			
                    while($a = mysqli_fetch_assoc($logins)){  
                      
                ?>
      <tr class="success bgwhite">
      	<td><?php echo $a['id'] ?></td>
        <td><?php echo $a['lname']?></td>
        <td><?php echo $a['pass']?></td>
        <td><?php echo $a['idname']?></td>       
        
        <td>

        				                 
                          <a href="editlogin.php?id=<?php echo $a['id']; ?>" onclick="return confirm('sure to edit ?')"><button class="btn btn-primary" type="button">edit</button></a>
                            
                          </td>
        				<td>
                                        
                          <a href="deletelogin.php?id=<?php echo $a['id']; ?>" onclick="return confirm('sure to delete ?')"><button class="btn btn-danger" type="button">Delete</button></a>
                           
                 
                        
                        </td>
       
      					</tr>
      			  <?php 
      			  
							
                      }
                  ?>
    </tbody>
    

		</div>
						<?php
                        }else{
                          ?>
                          <code>
                          <div >
                          	<p class="errmesforlogin paddingch">

                          		Sorry! Only Admin Can inset, edit and delete!!!
                          	</p>
                          </div>
                          </code>
                        
                        <?php
                      }
                      ?>
</body>
</html>