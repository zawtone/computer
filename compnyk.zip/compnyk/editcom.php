<?php
 require_once('database.php');
 $serid = $_GET['serid'];
 $ed = $database->comread($serid);
 $e = mysqli_fetch_assoc($ed);
 if(isset($_POST) & !empty($_POST)){
     $serimg = $database->sanitize($_POST['serimg']);
     $prjid = $database->sanitize($_POST['prjid']);
     $imfor = $database->sanitize($_POST['imfor']);
     $percen = $database->sanitize($_POST['percen']);
     $fin = $database->sanitize($_POST['fin']);
     $modelid = $database->sanitize($_POST['modelid']);
     $redate = $database->sanitize($_POST['redate']);
     $findate = $database->sanitize($_POST['findate']);
    
    $ress = $database->comupdate($serimg,$prjid,$imfor,$percen,$fin,$modelid,$redate,$findate, $serid);
    if($ress){
        header("location:backendcom.php");
    }else{
        echo "failed to update data";
    }
}




?>
<!DOCTYPE html>
<html>
<head>
    <title>
        sms admin
    </title>
    <meta   charset="utf-8" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script>
        function cho(){
        var a=document.getElementById('choose').value;
        document.getElementById('responed').value= ""+a;

}
    </script>
    <style type="text/css">
        .navbarfor-new{
    border-radius: 0px !important;
}
body {
 background-color: #5A5959;
    background-size: cover;
    background-position: top;
}
/*==*/
    .whole1{
            width: 250px;
            height: 50px;
            background-color: #00F;
            display: flex;  
            opacity: 0.5;
        }
        .inner-back1{
            width: 240px;
            height: 40px;
            margin-top: 5px;
            margin-left: 5px;
            background-color: white;
        }
        .inner-one1{
            width: 230px;
            height: 30px;
            margin-top: 5px;
            margin-left: 5px;
            background-color: blue;
        }
        .logo{
            width: 230px;
            height: 30px;
            font-size: 28px;
            padding-top: 7px;
            text-align: center;
            color: white;
            text-shadow: 1px 1px 3px black;
            position: relative;
            font-family: Algerian;
            margin-top: -42px;
        }

/*==*/
.data-back{
    width: 125px;
    height: 30px;
    border-radius: 15px;
    border: 3px solid #C9C9C9;
    color: white;
    text-align: center;
    box-shadow: 1px 1px 3px #C9C9C9;
}
.data-back:hover{
    background-color: #E1DADA;
    text-decoration: none;
    color: #6C6969;
}


.row-new{
    margin-right: 0px !important;
    margin-left: 0px !important;
}
.navbar-inverse{
    background-color: transparent;
    border: 0px !important;
}
.form-footer{
    width: 100%;
    height: auto;
    float: right;
    box-shadow: 1px 1px 6px black;
    border-left: 5px solid white;
}
.undefine li{
    list-style: none;
    margin-top: 20px;
}
.undefine {
    margin-left: -25px !important;
}
.form-footer h1{
    color: #E7E4E4;
}
label{
    color: #E7E4E4;
}
.drop{
    background-color: transparent !important;
}
.action:hover{
    background-color: transparent !important;
}
.action:focus{
    background-color: transparent !important;
}

.logins{
    margin-top: 10px !important;
}
.drop li a{
    color: #E7E4E4;
}
.buttton{
    opacity: 0.8;
    width: 100px;
    margin-bottom: 30px;
}
.data-link{
    color: white !important;
}
.data-link:hover{
    color: blue !important;
    text-decoration: none;
}
.navbar-brand{
    padding: 0px !important;
}
.whiteforth{
    color: white;
}
    </style>
    <script type="text/javascript">
        /*function zaw(){
            alert("Thank You !");
        }*/
    </script>
</head>
<body>



    
    <div class="col-sm-8 tab-content" style="margin-bottom: 20px;">
        <div class="container form-footer tab-pane fade in active" id="home">
            <h1>object item record</h1>
            <form role="form" method="post">

                <div class="form-group">
                  <label for="email">Date of item receade</label>
                  <input name="redate" type="date" class="form-control is-invalid" value="<?php echo $e['redate'] ?>"  >
                </div>

                <div class="form-group">
                  <label for="email">item id</label>
                  <input name="prjid" type="text" class="form-control is-invalid" value="<?php echo $e['prjid'] ?>"  >
                </div>

                 <div class="form-group">
                  <label for="pwd"><!-- read more photo(Selete images) -->
                    Selete Photo
                  </label>                
                <select id="sel1" class="form-control is-invalid" onchange="cho()"  name="serimg" value="<?php echo $e['serimg'] ?>" >                  
                  <?php          
                    $files = glob("uploads/*.*");
                     foreach ($files as $file) {
                        echo "<option name='test' value='$file'>";
                        echo "$file";
                        echo "</option>";
                  }?>
                </select>                 
                </div>

                <div class="form-group">
                  <label for="comment">imformation for item:</label>
                  <textarea class="form-control is-invalid" rows="5" id="comment" name="imfor"  style="max-width: 1055px;" ><?php echo $e['imfor'] ?></textarea>
                </div>

                <div class="form-group">
                  <label for="email">Percentage finish</label>
                  <input name="percen" type="text" class="form-control is-invalid" value="<?php echo $e['percen'] ?>%"  >
                </div>

                <div class="form-group">
                  <label for="email">Plz put as you like (text less(22))</label>
                  <input name="modelid" type="text" class="form-control is-invalid" value="<?php echo $e['modelid'] ?>"  >
                </div>

                 <div class="form-group">
                  <label for="email">Date finish</label>
                  <input name="findate" type="date" class="form-control is-invalid" value="<?php echo $e['findate'] ?>"  >
                </div>
                <div class="form-group">
                    <label for="exampleFormControlSelect1">Example select</label>
                    <select class="form-control" id="exampleFormControlSelect1" name="fin" value="<?php echo $e['fin'] ?>" >
                      <option value="visibility:hidden">unfinsh</option>
                      <option value="visibility:visible">finish</option>
                    
                    </select>
                  </div>
                
                
                
                
                <button type="submit" class="btn btn-primary buttton" >Submit</button>
            </form>

            
        </div>

        
  
</div>

</body>
</html>