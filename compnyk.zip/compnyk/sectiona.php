<?php
require_once('database.php');
$register = $database->read();

session_start();

$database = new Database(); $id = $_SESSION['id'];
$gi = $database->get_fullname($id);
if (!$database->get_session()){
	header("location:login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>sectionA</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="css/backends.css">
	<script type="text/javascript">
		function change() {
document.getElementById("rochange").style.transform = "rotate(-90deg)";
document.getElementById("rochange").style.margin = "410px auto 415px";

}

	</script>
</head>
<body>

		
	
	<table  border="2" cellspacing="0" id="rochange">
		<tr>
			<td colspan="6" class="namecom" onClick="change()">
				<p>Pyin Nyar Yin Khwin Computer Training Center</p>
			</td>
			<td colspan="4">
				<div class="section">
					section A- <span></span>
				</div>
				<div class="date">
					(7:00-9:00) AM
				</div>
			</td>
			<td colspan="2">
				<div class="batch">
					Batch :<span></span>
				</div>
			</td>
		</tr>
		<tr>
			<td class="no-row">
				No
			</td>
			<td class="name">
				Name
			</td>
			<td >
				
			</td>
			<td>
				
			</td>
			<td>
				
			</td>
			<td>
				
			</td>
			<td>
				
			</td>
			<td>
				
			</td>
			<td>
				
			</td>
			<td>
				
			</td>
			<td>
				
			</td>
			<td>
				
			</td>
			
		</tr>

		<?php while($k = mysqli_fetch_assoc($register)){ 
			
			
			$d = 'A';
			while($d == $k['section']){
			
				
		?>
		 
		<tr>
			<td class="no-row">
				1
			</td>
			<td class="namein">
				<p><?php echo $k['name']?></p>
			</td>
			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
		</tr>
		<?php 
			$d++;
			}
		}
		 ?>
		 <tr>
			<td class="no-row">
				
			</td>
			<td class="namein" style="text-align: center;">
				<p>volunteer </p>
			</td>
			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
		</tr>
		<tr>
			<td class="no-row">
				
			</td>
			<td class="namein" style="text-align: center;">
				<p>Teacher</p>
			</td>
			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
		</tr>
		<tr>
			<td class="no-row">
				
			</td>
			<td class="namein" style="text-align: center;">
				<p>Remark</p>
			</td>
			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
		</tr>
	</table>
</body>
</html>