<?php
require_once('database.php');

$exp = $database->expenread();
session_start();
$database = new Database(); $id = $_SESSION['id'];
$gi = $database->get_fullname($id);
if (!$database->get_session()){
 header("location:login.php");
}


 

 
 if(isset($_POST) & !empty($_POST)){
     $exdate = $database->sanitize($_POST['exdate']);
     $exitem = $database->sanitize($_POST['exitem']);
     $exunit = $database->sanitize($_POST['exunit']);
     $examount = $database->sanitize($_POST['examount']);
    

     $res = $database->expencreate($exdate,$exitem,$exunit,$examount);
     if($res){
        header("location:backendexp.php");
     }else{
        echo "failed to insert data";
     }
}





?>
<!DOCTYPE html>
<html>
<head>
	<title>backend</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/backend.css">
<script>
$(document).ready(function(){
	$("#slideshow").hide(0000);
    $("#slidebtn").click(function(){
        $("#slideshow").slideToggle(800);
    });
});
</script>
</head>
<body>
<?php include 'backendmods.php'; ?>
<!-- nenu -->

<div class="container paddingch">
	<h2 class="headerback">Expenses Form</h2>
	<form role="form" method="post" class="bgform">
		<div class="form-group">
			<label for="date">DATE:</label>
			<input name="exdate" type="number" class="form-control"  >
		</div>
		<div class="form-group">
			<label for="item">Item:</label>
			<textarea class="form-control" id="comments" name="exitem" placeholder="Items" rows="5"></textarea><br>
		</div>
		<div class="form-group">
			<label for="unmber">Unit:</label>
			<input name="exunit" type="number" class="form-control"  >
		</div>
		<div class="form-group">
			<label for="number">Amount:</label>
			<input name="examount" type="number" class="form-control"  >
		</div>
		<div class="row">
        <div class="col-sm-12 form-group">
          <button class="btn btn-default " type="submit">Submit</button>
        </div>
      </div>
	</form>
	<h2 class="headerback">Expenses result</h2>
  <p>all item</p>   
  <?php
	if(isset($exp)){

		$total_amount = 0;
		?>         
  <table class="table table-dark">
    <thead>
      <tr class="bgblack">
      	<th>no#</th>
        <th>id#</th>
        <th>Date</th>
        <th>Item</th>
        <th>Unit</th>
        <th>Amount</th>
        <th>Edit</th>
        <th>Delete</th>
      </tr>
    </thead>
    <tbody>
      			<?php 
      			$x=0;
                    while($a = mysqli_fetch_assoc($exp)){  
                    $x++;  
                ?>
      <tr class="success bgwhite">
      	<td><?php echo $x; ?></td>
        <td><?php echo $a['exid']?></td>
        <td><?php echo $a['exdate']?></td>
        <td><?php echo $a['exitem']?></td>       
        <td><?php echo $a['exunit']?></td>       
        <td><?php echo $a['examount']?></td>
        <td>

        <?php 
                        $g = '1QwiYiip123Foho';
                        if($g == $gi['idname']){
                          ?>                  
                          <a href="editex.php?exid=<?php echo $a['exid']; ?>" onclick="return confirm('sure to edit ?')"><button class="btn btn-primary" type="button">edit</button></a>
                          <?php
                        }else{
                          ?>  
                          <p style="color: red;"> 
                            you con't edit
                          </p>
                        
                        <?php
                      }
                      ?></td>
        <td>
                         <?php 
                        $g = '1QwiYiip123Foho';
                        if($g == $gi['idname']){
                          ?>                  
                          <a href="deleteex.php?exid=<?php echo $a['exid']; ?>" onclick="return confirm('sure to delete ?')"><button class="btn btn-danger" type="button">Delete</button></a>
                          <?php
                        }else{
                          ?>  
                          <p style="color: red;"> 
                            you con't delete
                          </p>
                        
                        <?php
                      }
                      ?></td>
       
      </tr>
      			  <?php 
      			  $total_amount += $a['examount'];
							
                      }
                  ?>
    </tbody>
    <tfoot>
				<tr class="bgblack">
				<th></th>
				<th></th>
				<th></th>
				<th>total</th>
				<th><?php echo $total_amount; ?> -MMK</th>
				</tr>
				</tfoot>
  </table>
  <?php
		} 
		?>
</div>
</body>
</html>