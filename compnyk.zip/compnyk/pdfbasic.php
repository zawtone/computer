
<!DOCTYPE html>
<html>
<head>
	<title>pdf</title>
	<meta   charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script>
$(document).ready(function(){
   $('#iframe').attr('src', 'https://laravel.com/');
});
</script>
	<style type="text/css">
		.header-rs-1{

    width: 90%;
    height: auto;
    padding: 9px;
    border: 4px solid #DDD;
    margin-left: auto;
    margin-right: auto;
    text-align: center;
    border-radius: 4px;
    background-color: #DEBFBF;
    font-size: 20px;

		}
	</style>
</head>
<body>
	<!-- https://drive.google.com/open?id=1x9L_BzvVGbKkUdHn74zT8LKdeUW5DwFu -->
<div class="container">
	<p class="header-rs-1">
		Basic
	</p>
	



<iframe id="iframe" name="myIframe" frameborder="5" width="500" height="300"></iframe>

</div>
</body>
</html>
