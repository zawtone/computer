

<?php
 require_once('database.php');
 $cid = $_GET['cid'];
 $ed = $database->creaded($cid);
 $e = mysqli_fetch_assoc($ed);
 if(isset($_POST) & !empty($_POST)){
     $cname = $database->sanitize($_POST['cname']);
     $comment = $database->sanitize($_POST['comment']);
     
     
    $ress = $database->cupdate($cname,$comment, $cid);
    if($ress){
        header("location:backend.php");
    }else{
        echo "failed to update data";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>
		sms admin
	</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	

	
	
</head>
<body>


	<div class="col-sm-8 tab-content">
		<div class="container form-footer tab-pane fade in active" id="home">
			<h1>Student Registeration !</h1>
			<form role="form" method="post">
			    <div class="form-group">
			      <label for="email">NAME:</label>
			      <input name="cname" type="text" class="form-control" value="<?php echo $e['cname'] ?>" >
			    </div>
			    <div class="form-group">
			      <label for="pwd">Comment:</label>
			      <input name="comment" type="text" class="form-control" value="<?php echo $e['comment'] ?>">
			    </div>
			    
			    
			    <button type="submit" class="btn btn-primary buttton" >Submit</button>
			</form>
		</div>

		
  
</div>

</body>
</html>