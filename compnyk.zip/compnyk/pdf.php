<!DOCTYPE html>
<html>
<head>
	<title>
		file
	</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<style type="text/css">
		

	</style>
</head>
<body>
	<?php $('body').bind('copy paste cut drag drop', function (e) {

e.preventDefault();

}); ?>

	<iframe src="http://localhost/compnyk/hhh.htm" width="100%" height="415px" allowfullscreen="allowfullscreen"></iframe>

</body>
</html>