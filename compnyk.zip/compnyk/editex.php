<?php
 require_once('database.php');
 $exid = $_GET['exid'];
 $ex = $database->expenread($exid);
 $e = mysqli_fetch_assoc($ex);
 if(isset($_POST) & !empty($_POST)){
     $exdate = $database->sanitize($_POST['exdate']);
     $exitem = $database->sanitize($_POST['exitem']);
     $exunit = $database->sanitize($_POST['exunit']);
     $examount = $database->sanitize($_POST['examount']);
     
     
    $ress = $database->expenupdate($exdate,$exitem,$exunit,$examount, $exid);
    if($ress){
        header("location:backendexp.php");
    }else{
        echo "failed to update data";
    }
}
?>


<!DOCTYPE html>
<html>
<head>
	<title>update</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
	<h3>Update Expenses</h3>
	<form role="form" method="post">
		<div class="form-group">
			<label for="date">DATE:</label>
			<input name="exdate" type="number" class="form-control" value="<?php echo $e['exdate'] ?>" >
		</div>
		<div class="form-group">
			<label for="item">Item:</label>
			<textarea class="form-control" id="comments" name="exitem"  rows="5" ><?php echo $e['exitem'] ?></textarea><br>
		</div>
		<div class="form-group">
			<label for="unmber">Unit:</label>
			<input name="exunit" type="number" class="form-control" value="<?php echo $e['exunit'] ?>" >
		</div>
		<div class="form-group">
			<label for="number">Amount:</label>
			<input name="examount" type="number" class="form-control" value="<?php echo $e['examount'] ?>" >
		</div>
		<div class="row">
        <div class="col-sm-12 form-group">
          <button class="btn btn-default pull-right" type="submit">Submit</button>
        </div>
      </div>
	</form>
</div>
</body>
</html>