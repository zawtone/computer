<!-- <?php
 require_once('database.php');
 $rid = $_GET['rid'];
 $ed = $database->read($rid);
 $e = mysqli_fetch_assoc($ed);
 session_start();

$database = new Database(); $id = $_SESSION['id'];
if (!$database->get_session()){
 header("location:index.php");
}


?> -->
<!DOCTYPE html>
<html>
<head>
	<title>
		print
	</title>
	<meta   charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<style type="text/css">
	.for-whole-print {
		width: 90%;
		margin-left: auto;
		margin-right: auto;
	}
	.front-box{

		width: 300px;
		
		padding: 7px;
		font-size: 18px;
		display: block;
		float: left;
		margin-top: 10px;
	}
	.back-box{
		width: 900px;
		display: block;
		float: left;
		border-left: 3px solid #E4E4E4;
		margin-top: 10px;
		padding: 7px;
		font-size: 18px;
	}
</style>
</head>
<body>
	<div class="container">	
		<img src="pics/print1.jpg" class="img-responsive" alt="Cinque Terre" width="40%" height="300" style="margin-left: auto;
		margin-right: auto;">
		
	</div>
	<div class="for-whole-print">
		<!-- inner box -->
		<div class="box-holder">
			<div class="front-box">
				NAME:
			</div>
			<div class="back-box">
				<?php echo $e['name'] ?>
			</div>
		</div>
		<div class="box-holder">
			<div class="front-box">
				FATHER NAME:
			</div>
			<div class="back-box">
				<?php echo $e['fname'] ?>
			</div>
		</div>

		<div class="box-holder">
			<div class="front-box">
				DATE OF BIRTH:
			</div>
			<div class="back-box">
				<?php echo $e['dofb'] ?>
			</div>
		</div>

		<div class="box-holder">
			<div class="front-box">
				NRC NO:
			</div>
			<div class="back-box">
				<?php echo $e['nrcno'] ?>
			</div>
		</div>

		<div class="box-holder">
			<div class="front-box">
				EDUCATIONAL QUALIFICATION:
			</div>
			<div class="back-box">
				<?php echo $e['edu'] ?>
			</div>
		</div>

		<div class="box-holder">
			<div class="front-box">
				OCCUPATION:
			</div>
			<div class="back-box">
				<?php echo $e['occ'] ?>
			</div>
		</div>

		<div class="box-holder">
			<div class="front-box">
				COMPUTER EXPERIENCE:
			</div>
			<div class="back-box">
				<?php echo $e['computer'] ?>
			</div>
		</div>

		<div class="box-holder">
			<div class="front-box">
				PHONE:
			</div>
			<div class="back-box">
				<?php echo $e['phone'] ?>
			</div>
		</div>

		<div class="box-holder">
			<div class="front-box">
				RESIDENTIAL ADDRESS:
			</div>
			<div class="back-box">
				<?php echo $e['address'] ?>
			</div>
		</div>




	</div>
</body>
</html>