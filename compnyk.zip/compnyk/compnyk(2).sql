-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2019 at 11:03 AM
-- Server version: 5.6.17-log
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `compnyk`
--

-- --------------------------------------------------------

--
-- Table structure for table `news-tbl`
--

CREATE TABLE IF NOT EXISTS `newstbl` (
  `neid` int(11) NOT NULL AUTO_INCREMENT,
  `dfn` varchar(225) NOT NULL,
  `mini` varchar(225) NOT NULL,
  `whole` varchar(2000) NOT NULL,
  `test` varchar(225) NOT NULL,
  `onet` varchar(225) NOT NULL,
  `onep` varchar(225) NOT NULL,
  `twot` varchar(225) NOT NULL,
  `twop` varchar(225) NOT NULL,
  `threet` varchar(225) NOT NULL,
  `threep` varchar(225) NOT NULL,
  `fourt` varchar(225) NOT NULL,
  `fourp` varchar(225) NOT NULL,
  `fivet` varchar(225) NOT NULL,
  `fivep` varchar(225) NOT NULL,
  `sixt` varchar(225) NOT NULL,
  `sixp` varchar(225) NOT NULL,
  `modid` varchar(11) NOT NULL,
  `newmod` varchar(100) NOT NULL,
  PRIMARY KEY (`neid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `news-tbl`
--

INSERT INTO `newstbl` (`neid`, `dfn`, `mini`, `whole`, `test`, `onet`, `onep`, `twot`, `twop`, `threet`, `threep`, `fourt`, `fourp`, `fivet`, `fivep`, `sixt`, `sixp`, `modid`, `newmod`) VALUES
(5, '23-11-19(fool)', 'zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw ', 'zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw zaw ', 'pnyk (1).jpg', 'stupic', 'pnyk (1).jpg', 'stupic', '', 'stupic', 'pnyk (1).jpg', 'stupic', 'pnyk (1).jpg', 'stupic', 'pnyk (1).jpg', 'stupic', 'pnyk (1).jpg', '33', ''),
(7, 'dfn', 'adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk ', 'adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk adfsdghfgk ', 'pnyk (4).jpg', '', 'pnyk (4).jpg', '', 'pnyk (4).jpg', '', 'pnyk (4).jpg', '', 'pnyk (4).jpg', '0', 'pnyk (4).jpg', '', 'pnyk (4).jpg', '44', 'visibility:hidden'),
(10, '11-3-19(flool mon', 'hello word i am coming. whti my code!!!!!!!(fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code f', 'fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code fool code ', '', 'baby', 'pnyk (1).jpg', 'bye', 'pnyk (1).jpg', 'hi', 'pnyk (1).jpg', 'for suprise', 'pnyk (1).jpg', 'for donation', 'pnyk (1).jpg', 'for fool', 'pnyk (1).jpg', '55', 'visibility:visible');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
