<?php
 require_once('database.php');
 $neid = $_GET['neid'];
 
 $res = $database->deletenews($neid);
 if($res){
 	header('location: backendnew.php');
 }else{
 	echo "Failed to Delete Record";
 }
?>