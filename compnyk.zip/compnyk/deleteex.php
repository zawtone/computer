<?php
 require_once('database.php');
 $exid = $_GET['exid'];
 
 $res = $database->expendelete($exid);
 if($res){
 	header('location: backendexp.php');
 }else{
 	echo "Failed to Delete Record";
 }
?>