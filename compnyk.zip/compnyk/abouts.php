<div class="wells wellscb slideanim">
  <div class="header_about header_aboutcb">
    <p>အေၾကာင္းအရာ</p>
  </div>

  <div class="image_about">
    <img src="pics/crousel.jpg" class="img-responsive" alt="Cinque Terre" width="100%" height="300">
  </div>

  <div class="about-detail-text about-detail-textcb">ပညာရင္ခြင္ စာၾကည့္တုိက္ မွ ျမန္မာလူငယ္မ်ား IT နည္းပညာႏွင့္ နီးနီးစပ္စပ္ရွိကာ ကြန္ျပဴတာဆိုင္ရာ ပညာရပ္မ်ားအား ကၽြမ္းက်င္ပိုင္ႏိုင္ေရးအတြက္ ပညာဒါန ကြန္ျပဴတာသင္တန္းကို အေျခခံမွစတင္၍ အဆင့္ျမင့္အထိ ဖြင့္လွစ္ သင္ၾကားေပးလ်က္ ရွိပါသည္။ လစဥ္ တန္းခြဲသစ္မ်ား ဖြင့္လွစ္လ်က္ရွိပါသျဖင့္ မည္သူမဆို တက္ေရာက္ သင္ယူ ႏိုင္ပါေၾကာင္း သတင္းေကာင္း ပါးအပ္ပါသည္။</div>

  <div class="container container-fluid contact_about contact_aboutcb">#သင္​တန္​းရက္​ - စ​ေန ၊ တနဂၤ​ေႏြ (တစ္​ပတ္​ ႏွစ္​ရက္​)<br />
    #သင္​တန္​းအခ်ိန္​ - (၇း၀၀ - ၉း၀၀) ၊ (၉း၀၀ - ၁၁း၀၀) ၊ (၁၁း၀၀ - ၁း၀၀) ၊ (၁း၀၀ - ၃း၀၀) ၊ (၃း၀၀ - ၅း၀၀) =&gt;<br />
    ႀကိဳက္​ႏွစ္​သက္​ရာ အခ်ိန္​​ေရြးခ်ယ္​ တက္​​ေရာက္​ႏိုင္​ပါသည္​ ။<br />
    သင္တန္းတည္ေနရာ - သဒၶမၼေဇာတိကာရုံ ဘုန္းေတာ္ႀကီးသင္ ပညာေရးေက်ာင္း ၊ ကြမ္းၿခံကုန္းေက်းရြာ ၊ သန္လ်င္ၿမိဳ႕နယ္ ၊ ရန္ကုန္တုိင္းေဒသႀကီး။ (စစ္​စီး​ေတာမွတ္​တိုင္​)<br />
  ဆက္သြယ္ရန္ - ၀၉ ၄၂၅၀၂၇၅၃၅, ၀၉၄၄၁၅၃၇၄၉၅</div>
</div>

<div class="pro-whole-all">



</div>







<!-- profile for te and o -->
<div class="container">
  <div class="profilewholebox-a">
    <div class="whole-profile1">
      <div class="img-profile1">
        
      </div>
      <div class="detail-profile1 detail-profile1cb">
        <h2>Daw Khaing Mar Lar Phyo (-Teacher-)</h2>
        <p>No.300, Sein Pan Myaing Street, 17 wards, South Dagon Township, Yangon.</p>
        <div class="phone-box">
          <div class="phone-box1 phone-box1cb">
            Phone :
          </div>
          <div class="phone-box2  phone-box1cb">
            09 425027535
          </div>
        </div>

        <div class="phone-box">
          <div class="phone-box1 phone-box1cb">
            Email    :
          </div>
          <div class="phone-box2 phone-box1cb">
            angelbreeze10
          </div>
        </div>


      </div>
    </div>



    <div class="whole-profile1">
      <div class="img-profile1">
        
      </div>
      <div class="detail-profile1 detail-profile1cb">
        <h2>Daw Khaing Mar Lar Phyo (-Teacher-)</h2>
        <p>No.300, Sein Pan Myaing Street, 17 wards, South Dagon Township, Yangon.</p>
        <div class="phone-box">
          <div class="phone-box1 phone-box1cb">
            Phone :
          </div>
          <div class="phone-box2  phone-box1cb">
            09 425027535
          </div>
        </div>

        <div class="phone-box">
          <div class="phone-box1 phone-box1cb">
            Email    :
          </div>
          <div class="phone-box2 phone-box1cb">
            angelbreeze10
          </div>
        </div>


      </div>
    </div>

  </div>
</div>